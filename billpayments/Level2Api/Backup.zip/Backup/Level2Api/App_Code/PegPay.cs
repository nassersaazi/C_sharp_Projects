using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Net;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using Encryption;
using System.Net.Security;
using System.IO;
using System.Text;
using System.Globalization;
using UtilityReferences;
using UtilityReferences.NWSC;
using UtilityReferences.UMEME;
using UtilityReferences.URA;
//using UtilityReferences.Stanbic;
using UtilityReferences.KCCA;
using System.Collections.Generic;
using UtilityReferences.DSTVApi;
using System.Xml;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Messaging;
using UtilityReferences.WenrecoApi;
using Tester;

[WebService(Namespace = "http://PegPayPaymentsApi/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class PegPay : System.Web.Services.WebService
{
    public string othersUmemeQueue = @".\private$\OthersUmemeQueue";
    public string otherNwscQueue = @".\private$\OthersUmemeQueue";
    public string EodReconciliationQueue = @".\private$\EodReconciliationQueue";
    BusinessLogic bll = new BusinessLogic();
    public void SaveVendor(Vendor vendor)
    {
        try
        {
            DatabaseHandler dh = new DatabaseHandler();
            BusinessLogic bll = new BusinessLogic();
            vendor.Passwd = bll.EncryptString(vendor.Passwd);
            dh.SaveVendorDetails(vendor);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public string GetServerStatus()
    {
        string status = "";
        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            dp.SaveRequestlog("", "", "GETSERVERSTATUS", "", "");
            status = dp.GetServerStatus();
        }
        catch (Exception ex)
        {
            status = "ERROR CONNECTING TO SERVER DB";
        }
        return status;
    }

    [WebMethod]
    public DSTVQueryResponse QueryStartTimesCustomerDetails(string customerRef, string vendorCode, string password)
    {
        DSTVQueryResponse cust = new DSTVQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {
            dp.SaveRequestlog(vendorCode, "STARTIMES", "VERIFICATION", customerRef, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("STARTIMES", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                        UtilityReferences.StarTimes.StarTimesConnect serv = new UtilityReferences.StarTimes.StarTimesConnect();
                        UtilityReferences.StarTimes.SubscriberQueryResult resp = serv.GetStarTimesCustomerDetails(customerRef, creds.UtilityCode, creds.UtilityPassword);

                        if (resp.returnCode.Equals("0"))
                        {
                            //double bal = GetTotalBalance(cust);
                            cust.CustomerReference = resp.smartCardCode;
                            cust.CustomerName = resp.customerName;
                            cust.CustomerBalance = resp.balance + "";
                            cust.CustomerType = resp.orderedProductsDesc;
                            cust.Area = resp.subscriberStatus + "";//.ToString();
                            cust.CustType = resp.canOrderProductInfos.Length.Equals(4) ? "DTT" : "DTH"; 
                            cust.StatusCode = "0";
                            cust.StatusDescription = "SUCCESS";

                            Customer customer = new Customer();
                            customer.AgentCode = "STARTIMES";
                            customer.CustomerName = cust.CustomerName;
                            customer.CustomerRef = cust.CustomerReference;
                            customer.CustomerType = cust.CustomerType;
                            customer.Balance = cust.CustomerBalance.ToString();
                            customer.TIN = cust.CustType;

                            saveUmemeCustomerDetails(customer);
                        }
                        else
                        {
                            cust.CustomerReference = "";
                            cust.CustomerName = "";
                            cust.CustomerType = "";
                            cust.OutstandingBalance = "";
                            cust.StatusCode = "100";
                            cust.StatusDescription = cust.StatusDescription;
                        }
                    }
                    else
                    {
                        cust.StatusCode = "29";
                        cust.StatusDescription = dp.GetStatusDescr(cust.StatusCode);
                    }
                }
                else
                {
                    cust.StatusCode = "11";
                    cust.StatusDescription = dp.GetStatusDescr(cust.StatusCode);
                }
            }
            else
            {
                cust.StatusCode = "2";
                cust.StatusDescription = dp.GetStatusDescr(cust.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            Customer custo = dp.GetCustomerDetails(customerRef, "", "STARTIMES");
            if (cust.StatusCode.Equals("0"))
            {
                cust.CustomerType = custo.CustomerType;
                cust.CustomerName = custo.CustomerName;
                cust.CustomerReference = custo.CustomerRef;
                cust.OutstandingBalance = "0";
                cust.StatusCode = "0";
                cust.StatusDescription = dp.GetStatusDescr(cust.StatusCode);
            }
            else
            {
                cust.StatusCode = "30";
                cust.StatusDescription = "UNABLE TO CONNECT TO STARTIMES";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "STARTIMES");
        }
        catch (SqlException sqlex)
        {
            cust.StatusCode = "31";
            cust.StatusDescription = dp.GetStatusDescr(cust.StatusCode);
        }
        catch (Exception ex)
        {
            Customer custo = dp.GetCustomerDetails(customerRef, "", "STARTIMES");
            if (custo.StatusCode.Equals("0"))
            {
                cust.CustomerType = custo.CustomerType;
                cust.CustomerName = custo.CustomerName;
                cust.CustomerReference = custo.CustomerRef;
                cust.OutstandingBalance = "0";
                cust.StatusCode = "0";
                cust.StatusDescription = dp.GetStatusDescr(cust.StatusCode);
            }
            else
            {
                cust.StatusCode = "100";
                cust.StatusDescription = "INVALID CUSTOMER REFERENCE";
            }
            //resp.StatusCode = "32";
            //resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "STARTIMES");
        }
        return cust;
    }

    [WebMethod]
    public ReversalResponse ReversePrepaidTransaction(ReversalRequest req)
    {
        ReversalResponse resp = new ReversalResponse();
        DatabaseHandler dh = new DatabaseHandler();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            //if it passes validation
            if (req.IsValid())
            {
                //log and return success
                string PegPayId = dh.LogReversalRequest(req);
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
                resp.ReversalID = PegPayId;
            }
            else
            {
                //return error message
                resp.StatusCode = "100";
                resp.StatusDescription = req.StatusDesc;
                resp.ReversalID = "";
            }
        }
        catch (Exception ex)
        {
            //log error 
            dh.LogError(ex.Message, req.VendorCode, DateTime.Now, req.OriginalTransactionId + "-REVERSAL");
            resp.StatusCode = "101";
            resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
            resp.ReversalID = "";
        }
        return resp;
    }


    [WebMethod]
    public URAQueryResponse QueryURACustomerDetails(string CustomerReference, string TypeOfPayment, string vendorCode, string password)
    {
        URAQueryResponse resp = new URAQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        UtilityCredentials creds;
        try
        {
            dp.SaveRequestlog(vendorCode, "URA", "VERIFICATION", CustomerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("URA", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        if (vendorCode.ToUpper().Equals("MTN"))
                        {
                            if (TypeOfPayment.ToUpper().Equals("REGISTERED"))
                            {
                                resp = QueryUraForRegisteredPayment(CustomerReference);
                            }
                            else if (TypeOfPayment.ToUpper().Equals("UNREGISTERED"))
                            {
                                resp = QueryUraForUnRegisteredPayment(CustomerReference);
                            }
                            else
                            {
                                resp.StatusCode = "100";
                                resp.StatusDescription = "UNKNOWN URA PAYMENT TYPE";
                            }
                        }
                        else if (vendorCode.ToUpper().Equals("CELL") || vendorCode.ToUpper().Equals("STANBIC_VAS"))
                        {
                            UraPmtService ura = new UraPmtService();
                            creds.UtilityPassword = bll.EncryptUraParameter(bll.DecryptString(creds.UtilityPassword));
                            PaymentRegEntity pre = ura.GetPRNDetails(creds.UtilityCode, creds.UtilityPassword, creds.UtilityCode, CustomerReference);
                            if (pre.AccessMsg == null || !pre.AccessMsg.Trim().ToUpper().Equals("ACCESS DENIED"))
                            {
                                if (pre.StatusCode.Trim() == "A")
                                {
                                    resp.CustomerReference = pre.Prn;
                                    resp.OutstandingBalance = int.Parse(pre.Amount).ToString("#,##0");
                                    resp.TIN = pre.Tin;
                                    resp.StatusCode = "0";
                                    resp.StatusDescription = "SUCCESS";
                                    resp.CustomerName = pre.TaxpayerName;
                                }
                                else
                                {
                                    resp.StatusCode = "100";
                                    resp.StatusDescription = pre.StatusDesc;
                                }
                            }
                            else
                            {
                                resp.StatusCode = "100";
                                resp.StatusDescription = pre.AccessMsg;
                            }
                        }
                        else if (vendorCode.ToUpper().Equals("EGOPAY"))
                        {
                            DataTable dt = new DataTable();
                            DatabaseHandler dh = new DatabaseHandler();
                            resp = dh.QueryURAcustomerDetails(CustomerReference);

                        }
                        else if (vendorCode.ToUpper().Equals("SMART"))
                        {
                            DataTable dt = new DataTable();
                            DatabaseHandler dh = new DatabaseHandler();
                            resp = dh.QueryURAcustomerDetails(CustomerReference);

                        }
                        //for other people without credentials at URA
                        else
                        {
                            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                            UtilityReferences.StanbicBankApi.PegPay pegpay = new UtilityReferences.StanbicBankApi.PegPay();
                            UtilityReferences.StanbicBankApi.QueryRequest stanbicbankuraqueryrequest = new UtilityReferences.StanbicBankApi.QueryRequest();
                            UtilityReferences.StanbicBankApi.Response stanbicbankuraresponse = new UtilityReferences.StanbicBankApi.Response();
                            stanbicbankuraqueryrequest.QueryField1 = CustomerReference;
                            stanbicbankuraqueryrequest.QueryField4 = "URA";
                            stanbicbankuraqueryrequest.QueryField5 = vendorCode;
                            stanbicbankuraqueryrequest.QueryField6 = password;

                            // pegpay.Timeout = 24000;
                            stanbicbankuraresponse = pegpay.QueryCustomerDetails(stanbicbankuraqueryrequest);


                            if (stanbicbankuraresponse.ResponseField6.Equals("0"))
                            {
                                resp.CustomerReference = stanbicbankuraresponse.ResponseField1;
                                resp.CustomerName = stanbicbankuraresponse.ResponseField2;
                                resp.TIN = stanbicbankuraresponse.ResponseField3;
                                resp.OutstandingBalance = stanbicbankuraresponse.ResponseField4;
                                resp.StatusCode = stanbicbankuraresponse.ResponseField6;
                                resp.StatusDescription = stanbicbankuraresponse.ResponseField7;
                                resp.PaymentRegistrationDate = stanbicbankuraresponse.ResponseField8;
                                resp.PrnStatus = stanbicbankuraresponse.ResponseField9;


                                Customer customer = new Customer();
                                customer.AgentCode = "URA";
                                customer.CustomerName = stanbicbankuraresponse.ResponseField2;
                                customer.CustomerRef = stanbicbankuraresponse.ResponseField1;
                                customer.Balance = stanbicbankuraresponse.ResponseField4;
                                customer.Area = stanbicbankuraresponse.ResponseField3;
                                customer.CustomerType = stanbicbankuraresponse.ResponseField3;
                                saveUmemeCustomerDetails(customer);
                                //cust.CustomerRef, cust.CustomerName, cust.CustomerType, "" + balance, cust.AgentCode
                            }
                            else
                            {
                                resp.CustomerReference = stanbicbankuraresponse.ResponseField1;
                                resp.CustomerName = stanbicbankuraresponse.ResponseField2;
                                resp.TIN = stanbicbankuraresponse.ResponseField3;
                                resp.OutstandingBalance = stanbicbankuraresponse.ResponseField4;
                                resp.StatusCode = stanbicbankuraresponse.ResponseField6;
                                resp.StatusDescription = stanbicbankuraresponse.ResponseField7;
                                resp.PaymentRegistrationDate = stanbicbankuraresponse.ResponseField8;
                                resp.PrnStatus = stanbicbankuraresponse.ResponseField9;
                            }

                            //Customer cust = dp.GetCustomerDetails(CustomerReference, "", "URA");
                            //if (cust.StatusCode.Equals("0"))
                            //{
                            //    resp.CustomerReference = cust.CustomerRef;
                            //    resp.CustomerName = cust.CustomerName;
                            //    resp.TIN = cust.TIN;
                            //    resp.OutstandingBalance = cust.Balance.Split('.')[0];
                            //    resp.StatusCode = "0";
                            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);

                            //}
                            //else
                            //{
                            //    resp.CustomerReference = "";
                            //    resp.CustomerName = "";
                            //    //resp.CustomerType = "";
                            //    resp.OutstandingBalance = "";
                            //    resp.StatusCode = "100";
                            //    resp.StatusDescription = "INVALID REFERENCE NUMBER";
                            //}
                        }

                    }
                    else
                    {
                        resp.StatusCode = "29";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            resp.StatusCode = "30";
            resp.StatusDescription = "UNABLE TO CONNECT TO URA";
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "URA");
            Customer cust = dp.GetCustomerDetails(CustomerReference, "", "URA");
            if (cust.StatusCode.Equals("0"))
            {
                resp.CustomerReference = cust.CustomerRef;
                resp.CustomerName = cust.CustomerName;
                resp.TIN = cust.TIN;
                resp.OutstandingBalance = cust.Balance.Split('.')[0];
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);

            }
            else
            {
                resp.CustomerReference = "";
                resp.CustomerName = "";
                //resp.CustomerType = "";
                resp.OutstandingBalance = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID REFERENCE NUMBER";
            }
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "URA");
        }
        return resp;
    }

    private URAQueryResponse QueryUraForUnRegisteredPayment(string CustomerReference)
    {
        URAQueryResponse resp = new URAQueryResponse();
        DatabaseHandler dh = new DatabaseHandler();
        LookupResp lookupResp = dh.GetDetailsByOffenceCode(CustomerReference);
        if (lookupResp.StatusCode.Equals("0"))
        {
            resp.CustomerReference = CustomerReference;
            resp.CustomerName = "";
            resp.OutstandingBalance = lookupResp.Amount;
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        else
        {
            resp.StatusCode = "100";
            resp.StatusDescription = lookupResp.StatusDescription;
        }
        return resp;
    }

    private URAQueryResponse QueryUraForRegisteredPayment(string CustomerReference)
    {
        URAQueryResponse resp = new URAQueryResponse();
        Process p = new Process();

        ProcessStartInfo startInfo = new ProcessStartInfo("C:\\Program Files\\Java\\jre7\\bin\\java.exe",
                  "-jar E:\\PePay\\UraTester\\ConsoleApplication\\LookUpConsole\\LookUpConsole\\dist\\LookUpConsole.jar PrnLookup:" + CustomerReference);
        startInfo.UseShellExecute = false;
        startInfo.CreateNoWindow = true;
        startInfo.RedirectStandardOutput = true;
        Process process = Process.Start(startInfo);

        string uraResp = process.StandardOutput.ReadToEnd();
        string[] details = Regex.Split(uraResp, "\r\n");

        //success at URA
        if (details[0] == "0")
        {
            resp.StatusCode = details[0];
            resp.StatusDescription = details[1];
            resp.CustomerReference = CustomerReference;
            resp.CustomerName = details[6];
            resp.OutstandingBalance = details[2].Split('.')[0];
            resp.TIN = details[7];
            resp.PaymentRegistrationDate = details[3];
            resp.PrnStatus = details[5];

            //save details
            string TypeOfPayment = "REGISTERED";
            Customer cust = new Customer();
            cust.CustomerName = resp.CustomerName;
            cust.AgentCode = "URA";
            cust.Area = details[5];
            cust.Balance = resp.OutstandingBalance;
            cust.CustomerRef = CustomerReference;
            cust.CustomerType = TypeOfPayment;
            cust.TIN = resp.TIN;
            cust.StatusCode = "0";
            cust.StatusDescription = "SUCCESS";

            DatabaseHandler dh = new DatabaseHandler();
            dh.SaveDstvCustomerDetails(cust);
        }
        else
        {
            resp.StatusCode = "100";
            resp.StatusDescription = details[1];
        }

        return resp;

    }

    [WebMethod]
    public UmemeQueryResponse QueryUmemeCustomerDetails(string customerReference, string vendorCode, string password)
    {
        UmemeQueryResponse resp = new UmemeQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {
            dp.SaveRequestlog(vendorCode, "UMEME", "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("UMEME", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                        EPayment umemeapi = new EPayment();


                        //UtilityReferences.UMEME.Customer cust = umemeapi.ValidateCustomer(customerReference, creds.UtilityCode, creds.UtilityPassword);

                        // cust.StatusCode = "0";
                        Customer cust = dp.GetCustomerDetails(customerReference, "", "UMEME");


                        if (cust.StatusCode.Equals("0"))
                        {
                            //  double bal = GetTotalBalance(cust);
                            resp.CustomerReference = cust.CustomerRef;
                            resp.CustomerName = cust.CustomerName;
                            resp.CustomerType = cust.CustomerType;
                            resp.OutstandingBalance = cust.Balance.ToString();
                            resp.StatusCode = cust.StatusCode;
                            resp.StatusDescription = cust.StatusDescription;
                            Customer customer = new Customer();
                            customer.AgentCode = "UMEME";
                            customer.CustomerName = resp.CustomerName;
                            customer.CustomerRef = resp.CustomerReference;
                            customer.CustomerType = resp.CustomerType;
                            customer.Balance = cust.Balance.ToString();



                            //double bal = 19107.44;//GetTotalBalance(cust);
                            //resp.CustomerReference ="203451218";// cust.CustomerRef;
                            //resp.CustomerName = "TUMUSIIME SHARON";// cust.CustomerName;
                            //resp.CustomerType = "POSTPAID";// cust.CustomerType;
                            //resp.OutstandingBalance = bal.ToString();
                            //resp.StatusCode = "0";// cust.StatusCode;
                            //resp.StatusDescription = "POSTPAID UMEME PAYMENT";///cust.StatusDescription;
                            //Customer customer = new Customer();
                            //customer.AgentCode = "UMEME";
                            //customer.CustomerName = resp.CustomerName;
                            //customer.CustomerRef = resp.CustomerReference;
                            //customer.CustomerType = resp.CustomerType;
                            //customer.Balance = cust.Balance.ToString();




                            saveUmemeCustomerDetails(customer);
                        }
                        else
                        {
                            resp.CustomerReference = "";
                            resp.CustomerName = "";
                            resp.CustomerType = "";
                            resp.OutstandingBalance = "";
                            resp.StatusCode = "100";
                            resp.StatusDescription = cust.StatusDescription;
                        }
                    }
                    else
                    {
                        resp.StatusCode = "29";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, "", "UMEME");
            if (cust.StatusCode.Equals("0"))
            {
                resp.CustomerType = cust.CustomerType;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerReference = cust.CustomerRef;
                resp.OutstandingBalance = "0";
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "UMEME");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, "", "UMEME");
            if (cust.StatusCode.Equals("0"))
            {
                resp.CustomerType = cust.CustomerType;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerReference = cust.CustomerRef;
                resp.OutstandingBalance = "0";
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID CUSTOMER REFERENCE";
            }
            //resp.StatusCode = "32";
            //resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "UMEME");
        }
        return resp;
    }

    [WebMethod]
    public DSTVQueryResponse QueryDSTVCustomerDetails(string smartCardNumber, string PayTvCode, string bouquetCode, string vendorCode, string password)
    {
        DSTVQueryResponse resp = new DSTVQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {
            dp.SaveRequestlog(vendorCode, "DSTV", "VERIFICATION", smartCardNumber, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("DSTV", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        resp = CheckInDBForCustomer(smartCardNumber, PayTvCode, bouquetCode);
                        //if DB search results indicate that we should go directly to multichoice 
                        if (resp.StatusCode.Equals("200"))
                        {
                            resp = QueryMultichoiceDirectly(smartCardNumber, PayTvCode, bouquetCode, vendorCode, password);
                            //if multichoice query is a success
                            if (resp.StatusCode.Equals("0"))
                            {
                                Customer cust = GetDSTVCustomer(resp, bouquetCode);
                                dp.SaveDstvCustomerDetails(cust);
                            }
                        }



                    }
                    else
                    {
                        resp.StatusCode = "29";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            resp = CheckInDBForCustomer(smartCardNumber, PayTvCode, bouquetCode);
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "DSTV");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "DSTV");
        }
        return resp;
    }

    private DSTVQueryResponse QueryMultichoiceDirectly(string smartCardNumber, string PayTvCode, string bouquetCode, string vendorCode, string password)
    {

        DSTVQueryResponse resp = new DSTVQueryResponse();
        //we try querying using the smart card method first
        resp = QueryUsingSmartCardNumber(smartCardNumber, bouquetCode, vendorCode, PayTvCode);
        if (resp.StatusCode.Equals("100"))
        {
            //then we try querying using the customer number method next
            resp = QueryUsingCustomerNumber(smartCardNumber, bouquetCode, vendorCode, PayTvCode);
        }
        return resp;
    }

    private DSTVQueryResponse CheckInDBForCustomer(string smartCardNumber, string PayTvCode, string bouquetCode)
    {
        //so you have a smart card number
        //and a paytvcode
        //and bouquetcode
        //we check in db for that smartcard
        //if customer exists in db
        //we get the customer type i.e(Gotv or dstv)
        //then we make sure the bouquet he wants to pay for is for that customer type
        //
        DSTVQueryResponse resp = new DSTVQueryResponse();
        DatabaseHandler dh = new DatabaseHandler();
        Customer cust = dh.GetCustomerDetails(smartCardNumber, "", "DSTV");
        if (cust.StatusCode.Equals("0"))
        {
            //if he is a gotv guy
            //we make sure he picked a Gotv bouquet
            if (cust.CustomerType.ToUpper().Equals("GOTV") && (bouquetCode != null))
            {
                if (bouquetCode == "")
                {
                    //do nothing
                }
                else if (!bouquetCode.StartsWith("GO"))
                {
                    resp.bouquetDetails = null;
                    resp.Area = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID BOUQUET FOR GOTV";
                    return resp;
                }
            }
            //this is most likely a dstv guy
            //we make sure he picked a dstv bouquet
            else if (cust.CustomerType.ToUpper().Equals("DSTV") && (bouquetCode != null))
            {
                if (bouquetCode == "")
                {
                    //do nothing
                }
                else if (bouquetCode.StartsWith("GO"))
                {
                    resp.bouquetDetails = null;
                    resp.Area = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID BOUQUET FOR DSTV";
                    return resp;
                }
            }
            //we dont know if this is dstv or gotv guy
            //so to be safe we return error
            else
            {
                resp.bouquetDetails = null;
                resp.Area = "";
                resp.StatusCode = "200";
                resp.StatusDescription = "INVALID CUSTOMER REFERENCE";
                return resp;
            }

            //this is valid customer of either dstv or gotv
            //we build a success response object with the details
            resp.Area = cust.Area;
            resp.CustomerType = cust.CustomerType;
            resp.bouquetDetails = dh.GetBouquetDetailsFromDB(bouquetCode, cust.CustomerType)[0];
            resp.CurrentBouquet = dh.GetBouquetDetailsFromDB(bouquetCode, cust.CustomerType)[0].BouquetName;
            resp.CustomerName = cust.CustomerName;
            resp.DstvCustomerNo = cust.TIN;
            resp.CustomerReference = cust.CustomerRef;
            resp.OutstandingBalance = string.IsNullOrEmpty(cust.Balance) ? "0" : cust.Balance;
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        //this guy doesnt exist in our database
        else
        {
            resp.Area = "";
            resp.CustomerName = "";
            resp.CustomerReference = "";
            resp.CustomerType = "";
            resp.OutstandingBalance = "";
            resp.StatusCode = "200";
            resp.StatusDescription = "INVALID SMART CARD NUMBER";
        }
        return resp;

    }

    private Customer GetDSTVCustomer(DSTVQueryResponse resp, string bouquetCode)
    {
        Customer cust = new Customer();
        cust.AgentCode = "DSTV";
        cust.Area = resp.CurrentBouquet;
        cust.Balance = resp.OutstandingBalance;
        cust.CustomerName = resp.CustomerName;
        cust.CustomerRef = resp.CustomerReference;
        cust.CustomerType = resp.CustomerType;
        cust.TIN = resp.DstvCustomerNo;
        cust.StatusCode = "0";
        cust.StatusDescription = "SUCCESS";
        return cust;
    }

    private DSTVQueryResponse QueryUsingCustomerNumber(string smartCardNumber, string bouquetCode, string vendorCode, string utility)
    {

        DSTVQueryResponse resp = new DSTVQueryResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            DatabaseHandler dp = new DatabaseHandler();
            UtilityCredentials creds = dp.GetUtilityCreds("DSTV", vendorCode);
            SelfCareService dstv = new SelfCareService();
            GetBalanceByCustomerNumberResponse dstvResp = new GetBalanceByCustomerNumberResponse();
            string language = "English";//should be picked from DB
            string datasource = "Uganda_UAT";//should be picked from DB
            uint customerNumber = 0;

            try
            {
                customerNumber = uint.Parse(smartCardNumber);
            }
            catch (Exception e)
            {
                //we cant parse the number so this is definitely not a valid customer number
                resp.CustomerReference = smartCardNumber;
                resp.OutstandingBalance = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID SMART CARD NUMBER";
                return resp;
            }

            string currencycode = "UGS";
            string bussinesUnit = "dstv";
            string vendorC = creds.UtilityCode;
            string passwd = creds.UtilityPassword;
            string IpAddress = "41.190.130.222";

            dstvResp = dstv.GetCustomerDetailsByCustomerNumber(datasource, customerNumber, true, currencycode, bussinesUnit, passwd, language, IpAddress);


            resp.CustomerType = GetDSTVCustomerType(dstvResp.customerDetails.typeName);

            //go tv customer has chosen wrong bouquet
            if (resp.CustomerType.Equals("GOTV") && (bouquetCode != null))
            {
                if (bouquetCode == "")
                {
                    //do nothing
                }
                else if (!bouquetCode.StartsWith("GO"))
                {
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID BOUQUET FOR GOYV";
                    return resp;
                }
            }
            //dstv customer has chosen go tv bouquet
            else if (resp.CustomerType.Equals("GOTV") && (bouquetCode != null))
            {
                if (bouquetCode == "")
                {
                    //do nothing
                }
                else if (bouquetCode.StartsWith("GO"))
                {
                    resp.bouquetDetails = null;
                    resp.Area = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID BOUQUET FOR DSTV";
                    return resp;
                }
            }
            else
            {
                resp.bouquetDetails = null;
                resp.Area = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID SMART CARD NUMBER";
                return resp;
            }

            resp.CustomerName = dstvResp.customerDetails.salutation + " " + dstvResp.customerDetails.surname + " " + dstvResp.customerDetails.initials;
            resp.CustomerReference = smartCardNumber;
            resp.DstvCustomerNo = "" + dstvResp.customerDetails.number;
            resp.bouquetDetails = GetBouquetDetails(bouquetCode, resp.CustomerType, "", "")[0];
            resp.OutstandingBalance = dstvResp.accounts.Length > 0 ? "" + dstvResp.accounts[0].totalBalance : "0";
            resp.OutstandingBalance = string.IsNullOrEmpty(resp.OutstandingBalance) ? "0" : resp.OutstandingBalance;
            resp.CurrentBouquet = GetCurrentBouquetName(dstvResp.customerDetails.number, resp.CustomerType, "", "");
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        //this is how multichoice communicate errors
        catch (SoapException ex)
        {
            resp.CustomerReference = smartCardNumber;
            resp.OutstandingBalance = "";
            resp.StatusCode = "100";
            resp.StatusDescription = "INAVLID CUSTOMER NUMBER";
        }
        //something has gone wrong
        catch (Exception ex)
        {
            //we cant reach dstv
            if (ex.Message.ToUpper().Contains("UNABLE TO CONNECT") || ex.Message.ToUpper().Contains("TIMED OUT"))
            {
                resp.StatusCode = "100";
                resp.StatusDescription = "UNABLE TO REACH MULTCHOICE";
            }
            else
            {
                resp.StatusCode = "101";
                resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
            }
        }

        return resp;
    }

    private DSTVQueryResponse QueryUsingSmartCardNumber(string smartCardNumber, string bouquetCode, string vendorCode, string PayTvCode)
    {
        DSTVQueryResponse resp = new DSTVQueryResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            SelfCareService dstv = new SelfCareService();
            GetBalanceByDeviceNumberResponse dstvResp = new GetBalanceByDeviceNumberResponse();
            GetBalanceByCustomerNumberResponse custRep = new GetBalanceByCustomerNumberResponse();
            string datasource = "Uganda_UAT";
            string devicenumber = smartCardNumber;//"4261353579"; //"2017607397";//"2015897761";
            string currencycode = "UGS";
            string bussinesUnit = "dstv";
            string VendorCode = "PegasusDstv";
            string language = "English";
            string IpAddress = "41.190.130.222";

            dstvResp = dstv.GetCustomerDetailsByDeviceNumber(datasource, devicenumber, currencycode, bussinesUnit, VendorCode, language, IpAddress);

            resp.CustomerType = GetDSTVCustomerType(dstvResp.customerDetails.typeName);
            //make sure gotv guy has choosen gotv bouquet
            if (resp.CustomerType.ToUpper().Equals("GOTV") && (bouquetCode != null))
            {
                if (bouquetCode == "")
                {
                    //do nothing
                }
                else if (!bouquetCode.StartsWith("GO"))
                {
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID BOUQUET FOR GOTV";
                    return resp;
                }
            }
            //make sure dstv customer has chosen dstv Tv Bouquet
            else if (resp.CustomerType.ToUpper().Equals("DSTV") && (bouquetCode != null))
            {
                if (bouquetCode == "")
                {
                    //do nothing
                }
                else if (bouquetCode.StartsWith("GO"))
                {
                    resp.bouquetDetails = null;
                    resp.Area = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID BOUQUET FOR DSTV";
                    return resp;
                }
            }
            //we fail this query here because we cant determine if he is gotv or dstv
            else
            {
                resp.bouquetDetails = null;
                resp.Area = "";
                resp.StatusCode = "200";
                resp.StatusDescription = "INVALID SMART CARD NUMBER";
                return resp;
            }

            //if we reach here
            //we are sure that this is a valid multichoice customer
            //so we build a success response object
            resp.CustomerName = dstvResp.customerDetails.salutation + " " + dstvResp.customerDetails.surname + " " + dstvResp.customerDetails.initials;
            resp.CustomerReference = smartCardNumber;
            resp.DstvCustomerNo = "" + dstvResp.customerDetails.number;
            resp.bouquetDetails = GetBouquetDetails(bouquetCode, resp.CustomerType, "", "")[0];
            resp.OutstandingBalance = dstvResp.accounts.Length > 0 ? "" + dstvResp.accounts[0].totalBalance : "0";
            resp.OutstandingBalance = string.IsNullOrEmpty(resp.OutstandingBalance) ? "0" : resp.OutstandingBalance;
            resp.CurrentBouquet = GetCurrentBouquetName(dstvResp.customerDetails.number, resp.CustomerType, "", "");
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        //this is how mutlichoice communicate errors
        catch (SoapException ex)
        {
            resp.CustomerReference = smartCardNumber;
            resp.OutstandingBalance = "";
            resp.StatusCode = "100";
            resp.StatusDescription = "INVALID SMART CARD NUMBER";
        }
        //something has gone wrong
        catch (Exception ex)
        {
            //we cant reach dstv
            if (ex.Message.ToUpper().Contains("UNABLE TO CONNECT") || ex.Message.ToUpper().Contains("TIMED OUT"))
            {
                resp.StatusCode = "100";
                resp.StatusDescription = "UNABLE TO REACH MULTCHOICE";
            }
            else
            {
                resp.StatusCode = "101";
                resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
            }
        }

        return resp;

    }

    private DSTVQueryResponse QueryFromGoTvUsingSmartCard(string smartCardNumber, string bouquetCode)
    {
        DSTVQueryResponse resp = new DSTVQueryResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            SelfCareService dstv = new SelfCareService();
            GetBalanceByDeviceNumberResponse dstvResp = new GetBalanceByDeviceNumberResponse();
            GetBalanceByCustomerNumberResponse custRep = new GetBalanceByCustomerNumberResponse();
            string datasource = "Uganda_UAT";
            string devicenumber = smartCardNumber;//"4261353579"; //"2017607397";//"2015897761";
            string currencycode = "UGS";
            string bussinesUnit = "Gotv";
            string vendorCode = "PegasusGOtv";
            string language = "English";
            string IpAddress = "41.190.130.222";

            dstvResp = dstv.GetCustomerDetailsByDeviceNumber(datasource, devicenumber, currencycode, bussinesUnit, vendorCode, language, IpAddress);

            resp.bouquetDetails = GetBouquetDetails(bouquetCode, "GOTV", "", "")[0];
            resp.CustomerName = dstvResp.customerDetails.salutation + " " + dstvResp.customerDetails.surname;
            resp.CustomerReference = smartCardNumber;
            resp.OutstandingBalance = dstvResp.accounts.Length > 0 ? "" + dstvResp.accounts[0].currentAmount : "";
            resp.CurrentBouquet = GetCurrentBouquetName(dstvResp.customerDetails.number, "GOTV", "", "");
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        catch (SoapException ex)
        {
            resp.StatusCode = "100";
            resp.StatusDescription = "INVALID SMART CARD NUMBER";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "101";
            resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
        }

        return resp;

    }

    private DSTVQueryResponse QueryFromDSTVUsingSmartCard(string smartCardNumber, string bouquetCode)
    {
        DSTVQueryResponse resp = new DSTVQueryResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            SelfCareService dstv = new SelfCareService();
            GetBalanceByDeviceNumberResponse dstvResp = new GetBalanceByDeviceNumberResponse();
            GetBalanceByCustomerNumberResponse custRep = new GetBalanceByCustomerNumberResponse();
            string datasource = "Uganda_UAT";
            string devicenumber = smartCardNumber;//"4261353579"; //"2017607397";//"2015897761";
            string currencycode = "UGS";
            string bussinesUnit = "dstv";
            string vendorCode = "PegasusDstv";
            string language = "English";
            string IpAddress = "41.190.130.222";

            dstvResp = dstv.GetCustomerDetailsByDeviceNumber(datasource, devicenumber, currencycode, bussinesUnit, vendorCode, language, IpAddress);


            resp.CustomerName = dstvResp.customerDetails.salutation + " " + dstvResp.customerDetails.surname + " " + dstvResp.customerDetails.initials;
            resp.CustomerType = GetDSTVCustomerType(dstvResp.customerDetails.typeName);
            resp.CustomerReference = smartCardNumber;
            resp.DstvCustomerNo = "" + dstvResp.customerDetails.number;
            resp.bouquetDetails = GetBouquetDetails(bouquetCode, resp.CustomerType, "", "")[0];
            resp.OutstandingBalance = dstvResp.accounts.Length > 0 ? "" + dstvResp.accounts[0].currentAmount : "";
            resp.CurrentBouquet = GetCurrentBouquetName(dstvResp.customerDetails.number, resp.CustomerType, "", "");
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        catch (SoapException ex)
        {
            resp.StatusCode = "100";
            resp.StatusDescription = "INVALID SMART CARD NUMBER";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "101";
            resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
        }

        return resp;
    }

    private string GetCurrentBouquetName(uint customerNumber, string customerType, string vendorCode, string passowrd)
    {
        try
        {
            if (customerType.Equals("DSTV"))
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                SelfCareService dstv = new SelfCareService();
                Hardware[] resp = { };
                string datasource = "Uganda_UAT";
                string currencycode = "UGS";
                string bussinesUnit = "dstv";
                vendorCode = "PegasusDStv";
                string language = "English";
                string IpAddress = "41.190.130.222";
                resp = dstv.GetProducts(datasource, customerNumber, true, vendorCode, language, IpAddress, bussinesUnit);
                return resp[0].Services[0].ProductDescription;
            }
            else
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                SelfCareService dstv = new SelfCareService();
                Hardware[] resp = { };
                string datasource = "Uganda_UAT";
                string currencycode = "UGS";
                string bussinesUnit = "Gotv";
                vendorCode = "PegasusGotv";
                string language = "English";
                string IpAddress = "41.190.130.222";
                resp = dstv.GetProducts(datasource, customerNumber, true, vendorCode, language, IpAddress, bussinesUnit);
                return resp[0].Services[0].ProductDescription;
            }
        }
        catch (Exception e)
        {
            return "";
        }
    }

    private string GetDSTVCustomerType(string type)
    {
        if (string.IsNullOrEmpty(type))
        {
            return "";
        }
        else
        {
            if (type.Trim().ToUpper().Contains("GOTV"))
            {
                return "GOTV";
            }
            else if (type.Trim().ToUpper() == "SUD")
            {
                return "DSTV";
            }
            else
            {
                return type;
            }
        }
    }


    //private string GetTotalBalance(Customer cust)
    //{
    //    try
    //    {
    //        string total = 0;
    //        double PercentVAT = 18;
    //        double Percentcredit = 50;
    //        if (cust.Balance.Equals(0))
    //        {
    //            total = cust.Balance;
    //        }
    //        else
    //        {
    //            double calculatedcredit = (Percentcredit / 100) * cust.Credit;
    //            double bal = cust.Balance + calculatedcredit;
    //            double calculatedVAT = (PercentVAT / 100) * bal;
    //            total = bal + calculatedVAT;
    //        }
    //        return total;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}





    private double GetTotalBalance(UtilityReferences.UMEME.Customer cust)
    {
        try
        {
            double total = 0;
            double PercentVAT = 18;
            double Percentcredit = 50;
            if (cust.Credit.Equals(0))
            {
                total = cust.Balance;
            }
            else
            {
                double calculatedcredit = (Percentcredit / 100) * cust.Credit;
                double bal = cust.Balance + calculatedcredit;
                double calculatedVAT = (PercentVAT / 100) * bal;
                total = bal + calculatedVAT;
            }
            return total;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public BouquetDetails[] GetBouquetDetails(string BouquetCode, string PayTvCode, string VendorCode, string Password)
    {
        DatabaseHandler dh = new DatabaseHandler();
        BouquetDetails[] allBouquets = { };
        try
        {
            //QueryBouquetsFromPayTv("", "GOTV", "", "");
            allBouquets = dh.GetBouquetDetailsFromDB(BouquetCode, PayTvCode);
        }
        catch (Exception e)
        {
            BouquetDetails bd = new BouquetDetails();
            bd.StatusCode = "100";
            bd.StatusDescription = "FAILED TO GET BOUQUET DETAILS";
            allBouquets[0] = bd;
        }
        return allBouquets;
    }

    private BouquetDetails[] QueryBouquetsFromPayTv(string BouquetCode, string PayTvCode, string VendorCode, string Password)
    {
        DatabaseHandler dh = new DatabaseHandler();
        List<BouquetDetails> allBouquets = new List<BouquetDetails>();
        BouquetDetails bouq = new BouquetDetails();
        try
        {
            if (string.IsNullOrEmpty(PayTvCode))
            {
                bouq.StatusCode = "100";
                bouq.StatusDescription = "Please Supply A Pay TV Code";
                allBouquets.Add(bouq);
                return allBouquets.ToArray();
            }

            //BouquetDetails[] bouquets = dh.GetBouquetDetailsFromDB(BouquetCode, PayTvCode);


            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            SelfCareService dstv = new SelfCareService();
            ProductwithoutChannel[] resp ={ };
            string[] Products ={ };
            string country = "Uganda";
            string vendorCode = "pegasusGotv";
            string IpAddress = "41.190.131.222";
            string bussinessUnit = "gotv";
            string interfaceType = "Gotv Facebook And Mobi";
            string language = "English";
            bool visibleForPayment = true;
            bool visibleForPaymentSpecified = true;
            bool visibleForView = true;
            bool visibleForViewSpecified = true;
            resp = dstv.GetAvailableProductsWithoutChannels(country, bussinessUnit, language, vendorCode, interfaceType, visibleForPayment, visibleForPaymentSpecified, visibleForView, visibleForViewSpecified, IpAddress);

            if (string.IsNullOrEmpty(BouquetCode))
            {
                foreach (ProductwithoutChannel pdt in resp)
                {
                    BouquetDetails abouquet = new BouquetDetails();
                    abouquet.BouquetCode = pdt.Product_Key;
                    abouquet.BouquetName = pdt.Product_Name;
                    abouquet.BouquetDescription = pdt.Description;
                    abouquet.BouquetPrice = pdt.CustomPrice;
                    abouquet.PayTvCode = PayTvCode;
                    abouquet.StatusDescription = "SUCCESS";
                    abouquet.StatusCode = "0";
                    dh.SaveBouquetDetails(abouquet);
                    allBouquets.Add(abouquet);
                }
            }
            else
            {
                foreach (ProductwithoutChannel pdt in resp)
                {
                    if (pdt.Product_Key.Equals(BouquetCode) || pdt.Product_Name.Equals(BouquetCode))
                    {
                        BouquetDetails abouquet = new BouquetDetails();
                        abouquet.BouquetCode = pdt.Product_Key;
                        abouquet.BouquetName = pdt.Product_Name;
                        abouquet.BouquetDescription = pdt.Description;
                        abouquet.BouquetPrice = pdt.CustomPrice;
                        abouquet.StatusDescription = "SUCCESS";
                        abouquet.StatusCode = "0";

                        allBouquets.Add(abouquet);
                        break;
                    }
                }
            }
        }
        catch (SoapException ex)
        {
            allBouquets = new List<BouquetDetails>();
            bouq.StatusCode = "100";
            bouq.StatusDescription = ex.Message;
            allBouquets.Add(bouq);
            return allBouquets.ToArray();
        }
        catch (Exception ex)
        {
            allBouquets.Clear();
            bouq.StatusCode = "100";
            bouq.StatusDescription = "GENERAL ERROR AT PEGASUS";
            allBouquets.Add(bouq);
            return allBouquets.ToArray();
        }
        return allBouquets.ToArray();

    }


    private SchoolsQueryResponse QueryUMUCustomerDetails(string utilityCode, string customerReference, string vendorCode)
    {
        SchoolsQueryResponse resp = new SchoolsQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {

            creds = dp.GetUtilityCreds(utilityCode, vendorCode);
            if (!creds.UtilityCode.Equals(""))
            {
                string stdno = customerReference;
                System.Net.ServicePointManager.Expect100Continue = false;
                string myUrl = "http://eis.umu.ac.ug:84/test/ebank?";
                string urlParams1 = "act=INQ&stno=" + stdno;
                myUrl = myUrl + urlParams1;
                HttpWebRequest r = (HttpWebRequest)System.Net.WebRequest.Create(myUrl);
                r.Headers.Clear();
                r.AllowAutoRedirect = true;
                r.PreAuthenticate = true;
                r.ContentType = "application / x - www - form - urlencoded";
                r.Credentials = CredentialCache.DefaultCredentials;
                r.UserAgent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
                r.Timeout = 150000;
                Encoding byteArray = Encoding.GetEncoding("utf-8");

                Stream dataStream;
                WebResponse response = (HttpWebResponse)r.GetResponse();
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                dataStream = response.GetResponseStream();
                StreamReader rdr = new StreamReader(dataStream);
                string feedback = rdr.ReadToEnd();
                string ErrorCode = "";
                string[] array = feedback.Split(',');
                if (array.Length == 5)
                {
                    ErrorCode = array[0].ToString().Replace("\n", "");
                    string Name = GetDetail(array[1].ToString());
                    string RegNo = GetDetail(array[2].ToString());
                    string StdNo = GetDetail(array[3].ToString());
                    string Program = GetDetail(array[4].ToString());

                    resp.StatusCode = "0";
                    resp.CustomerName = Name;
                    resp.CustomerReference = StdNo;
                    resp.OutstandingBalance = "0";
                    resp.StatusDescription = "SUCCESS";

                    Customer customer = new Customer();
                    customer.AgentCode = utilityCode;
                    customer.CustomerName = resp.CustomerName;
                    customer.CustomerRef = resp.CustomerReference;
                    customer.CustomerType = "";
                    saveCustomerDetails(customer);

                }
                else
                {
                    //E,,The Student No 20000 Does not Exist
                    if (array.Length == 2)
                    {
                        string errorCode = array[0].ToString().Replace(",", "");
                        string errorMessage = array[1].ToString().Replace(",", "");
                        string Error = errorMessage;
                        ErrorCode = errorCode;
                        resp.StatusCode = errorCode;
                        resp.StatusDescription = Error;
                    }
                    else
                    {
                        string errorCode = "F";
                        string errorMessage = "UN Known Error from Utility Database at" + utilityCode;
                        string Error = errorMessage;
                        ErrorCode = errorCode;
                        resp.StatusCode = errorCode;
                        resp.StatusDescription = Error;
                    }
                }
            }
            else
            {
                resp.StatusCode = "29";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return resp;
    }

    private SchoolsQueryResponse QueryCemasDetails(string utilityCode, string customerReference, string vendorCode)
    {
        SchoolsQueryResponse student = new SchoolsQueryResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            UtilityReferences.StanbicCemasApi.PegPay pegpay = new UtilityReferences.StanbicCemasApi.PegPay();
            pegpay.Url = "https://196.8.208.145:9444/testleveloneapi/pegpay.asmx?WSDL";
            UtilityReferences.StanbicCemasApi.QueryRequest query = new UtilityReferences.StanbicCemasApi.QueryRequest();
            UtilityReferences.StanbicCemasApi.Response resp = new UtilityReferences.StanbicCemasApi.Response();
            query.QueryField4 = utilityCode;
            query.QueryField1 = customerReference;
            query.QueryField5 = "PEGASUS";
            query.QueryField6 = "PEGASUS";

            //query.QueryField1 = "203016921";// "P170000000086";//"2142995";//"01454392760";// "04230081848";
            //query.QueryField2 = "";///area //ACSSW4
            //query.QueryField4 = "UMEME";// "UMEME";// "STB_SCHOOL";//utilitycode//"URA";
            //query.QueryField5 = VendorCode;//vendorcode//"Micropay";//"STN";
            //query.QueryField6 = Password;//passowrd//"41L12FF504";//"C1bn@t5#739";  na8wj0SGmEm3WsFCuC6MZA=

            resp = pegpay.QueryCustomerDetails(query);
            if (resp.ResponseField6 == "0")
            {
                //student.Amount = "";
                student.CustomerBalance = resp.ResponseField4;
                student.CustomerName = resp.ResponseField2;
                student.CustomerReference = resp.ResponseField1;
                student.StatusCode = resp.ResponseField6;
                student.StatusDescription = resp.ResponseField7;
                student.OutstandingBalance = resp.ResponseField4;
            }
            else
            {
                student.CustomerBalance = "";
                student.CustomerName = "";
                student.CustomerReference = "";
                student.StatusCode = resp.ResponseField6;
                student.StatusDescription = resp.ResponseField7;
            }

        }
        catch (Exception ee)
        {

            throw;
        }

        return student;
    }
    private SchoolsQueryResponse QueryMUBSCustomerDetails(string utilityCode, string customerReference, string vendorCode)
    {
        SchoolsQueryResponse resp = new SchoolsQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {

            creds = dp.GetUtilityCreds(utilityCode, vendorCode);
            if (vendorCode == "MTN")
            {
                creds.UtilityCode = "MTN";
            }
            if (!creds.UtilityPassword.Equals(""))
            {
                string stdno = customerReference;
                System.Net.ServicePointManager.Expect100Continue = false;
                string myUrl = "http://eis.mubs.ac.ug/test/ebank?";
                string urlParams1 = "act=INQ&stno=" + stdno;
                myUrl = myUrl + urlParams1;
                HttpWebRequest r = (HttpWebRequest)System.Net.WebRequest.Create(myUrl);
                r.Headers.Clear();
                r.AllowAutoRedirect = true;
                r.PreAuthenticate = true;
                r.ContentType = "application / x - www - form - urlencoded";
                r.Credentials = CredentialCache.DefaultCredentials;
                r.UserAgent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
                r.Timeout = 150000;
                Encoding byteArray = Encoding.GetEncoding("utf-8");

                Stream dataStream;
                WebResponse response = (HttpWebResponse)r.GetResponse();
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                dataStream = response.GetResponseStream();
                StreamReader rdr = new StreamReader(dataStream);
                string feedback = rdr.ReadToEnd();
                string ErrorCode = "";
                string[] array = feedback.Split(',');
                if (array.Length == 5)
                {
                    ErrorCode = array[0].ToString().Replace("\n", "");
                    string Name = GetDetail(array[1].ToString());
                    string RegNo = GetDetail(array[2].ToString());
                    string StdNo = GetDetail(array[3].ToString());
                    string Program = GetDetail(array[4].ToString());

                    resp.StatusCode = "0";
                    resp.CustomerName = Name;
                    resp.CustomerReference = StdNo;
                    resp.OutstandingBalance = "0";
                    resp.StatusDescription = "SUCCESS";

                    Customer customer = new Customer();
                    customer.AgentCode = utilityCode;
                    customer.CustomerName = resp.CustomerName;
                    customer.CustomerRef = resp.CustomerReference;
                    customer.CustomerType = "";
                    saveCustomerDetails(customer);
                }
                else
                {
                    //E,,The Student No 20000 Does not Exist
                    if (array.Length == 2)
                    {
                        string errorCode = array[0].ToString().Replace(",", "");
                        string errorMessage = array[1].ToString().Replace(",", "");
                        string Error = errorMessage;
                        ErrorCode = errorCode;
                        resp.StatusCode = errorCode;
                        resp.StatusDescription = Error;
                    }
                    else
                    {
                        string errorCode = "F";
                        string errorMessage = "UN Known Error from Utility Database at" + utilityCode;
                        string Error = errorMessage;
                        ErrorCode = errorCode;
                        resp.StatusCode = errorCode;
                        resp.StatusDescription = Error;
                    }
                }
            }
            else
            {
                resp.StatusCode = "29";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

        }
        catch (Exception ex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, "", "MUBS");
            if (cust.StatusCode.Equals("0"))
            {
                resp.CustomerReference = cust.CustomerRef;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerType = cust.CustomerType;
                resp.OutstandingBalance = "0";

                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.CustomerReference = "";
                resp.CustomerName = "";
                resp.CustomerType = "";
                resp.OutstandingBalance = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID STUDENT NUMBER";

            }
        }
        return resp;
    }


    [WebMethod]
    public QueryResponse QueryCustomerDetialsGeneric(string customerReference, string utilityCode, string vendorCode, string password)
    {//amwine
        QueryResponse resp = new QueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        BusinessLogic bll = new BusinessLogic();
        //DatabaseHandler dh = new DatabaseHandler();
        dataAccess dha = new dataAccess();

        try
        {
            if (string.IsNullOrEmpty(utilityCode))
            {
                resp.CustomerReference = "";
                resp.StatusCode = "133";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                return resp;
            }
            dp.SaveRequestlog(vendorCode, utilityCode, "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds(utilityCode, vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {

                        if (utilityCode == "WENRECO")
                        {
                            resp = VerifyWenrecoCustomer(customerReference, creds.UtilityCode, creds.UtilityPassword);
                        }
                        //resp = VerifyTuckSeePrn(customerReference, respresp.SessionKey, creds.Key);
                        if (resp.StatusCode != "0")
                        {
                            Customer cust = dp.GetCustomerDetails(customerReference, "", utilityCode);


                            //resp.CustomerReference = customerReference;
                            resp.CustomerReference = customerReference;
                            resp.CustomerName = cust.CustomerName;

                            resp.CustomerBalance = cust.Balance.Split('.')[0];
                            resp.StatusCode = "0";
                            resp.StatusDescription = "SUCCESS";

                        }

                    }

                }
            }
        }

        catch (System.Net.WebException wex)
        {
            if (wex.Message.ToUpper().Contains("TIMEOUT"))
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "CONNECTION TO KCCA TIMED OUT";
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO TUCKSEE";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "TUCKSEE");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = "PEGPAY DB UNAVAILABLE";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, utilityCode);
        }
        return resp;
    }

    [WebMethod]
    public PostResponse MakeWenrecoPayment(Transaction trans)
    {//amwine
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //log incoming Details
        //dp.logKCCAPostHit(trans);
        try
        {
            if (string.IsNullOrEmpty(trans.UtilityCode))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "133";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                return resp;
            }
            dp.SaveRequestlog(trans.VendorCode, trans.UtilityCode, "POSTING", trans.CustRef, trans.Password);

            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (string.IsNullOrEmpty(trans.TransactionType))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (string.IsNullOrEmpty(trans.VendorTransactionRef))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.Teller))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.DigitalSignature))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (!IsValidCustType(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "28";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds(trans.UtilityCode, trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                //Token token = ProcessWenrecoToken(trans);
                                                                string receipt = dp.PostTransactionObject(trans, "WENRECO");
                                                                resp.PegPayPostId = receipt;
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                            else
                                                            {
                                                                //resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            //resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        //     resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    //      resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                //    resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            //  resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        //resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    /// resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                //resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            //   resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        // resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    //resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            //if (resp.StatusCode.Equals("2"))
            //{
            //    DataTable dt = dp.GetVendorDetails(vendorCode);
            //    if (dt.Rows.Count != 0)
            //    {
            //        string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            //        string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
            //        int loginCount = int.Parse(strLoginCount);
            //        loginCount = loginCount + 1;
            //        if (loginCount == 3)
            //        {
            //            dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
            //            dp.DeactivateVendor(vendorCode, ipAddress);
            //        }
            //        {
            //            dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
            //        }
            //    }
            //}
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                ///resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, trans.UtilityCode);
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "KCCA");

        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }
    public Token ProcessWenrecoToken(Transaction trans)
    {
        Token token = new Token();
        string msgId = "", msgDateTime = "";
        try
        {

            XMLVendService client = new XMLVendService();
            CreditVendReq request = new CreditVendReq();
            CreditVendResp response = new CreditVendResp();
            // set the operator auth credentials of the message
            request.authCred = new AuthCred();
            request.authCred.opName = "PPAY";
            request.authCred.password = "123";
            // set the client ID
            EANDeviceID clientID = new EANDeviceID();
            clientID.ean = "PPAY";
            request.clientID = clientID;
            // set the terminal ID
            EANDeviceID terminalID = new EANDeviceID();
            terminalID.ean = "0000000000001";
            request.terminalID = terminalID;
            // set the msg ID
            request.msgID = GenerateMsgID();// MsgIDGenerator.Generate();
            msgId = request.msgID.uniqueNumber;
            msgDateTime = request.msgID.dateTime;
            // set the purchase amount
            PurchaseValueCurrency purchaseValue = new
            PurchaseValueCurrency();
            purchaseValue.amt = new UtilityReferences.WenrecoApi.Currency();
            purchaseValue.amt.symbol = "UGX";
            decimal tranAmount = decimal.Parse(trans.TransactionAmount);
            purchaseValue.amt.value = tranAmount;
            request.purchaseValue = purchaseValue;
            // set the meter identifier
            request.idMethod = new VendIDMethod();
            MeterNumber meterNumber = new MeterNumber();
            meterNumber.msno = trans.CustRef;
            request.idMethod.meterIdentifier = meterNumber;
            //set the resource type to electricity
            UtilityReferences.WenrecoApi.Electricity electricity = new Electricity();
            request.resource = electricity;
            //set the paytype to cash
            UtilityReferences.WenrecoApi.Cash cash = new UtilityReferences.WenrecoApi.Cash();
            cash.tenderAmt = new UtilityReferences.WenrecoApi.Currency();
            cash.tenderAmt.symbol = "UGX";
            cash.tenderAmt.value = tranAmount;
            request.payType = cash;
            //log request before vending
            //dh.LogPrepaymentRequests(merchant, vendorCode, meterNo, amount, msgId, msgDateTime, currency,tranId);
            // finally, perform the request, ensuring that possible exceptions are catered for
            token.DebtRecovery = "0";
            client.Timeout = 99999999;
            response = client.CreditVendRequest(request);
            //token.MsgIdDate = response.reqMsgID.dateTime;
            //token.MsgIdNumber = response.reqMsgID.uniqueNumber;
            //token.RemainingCredit = response.clientStatus.availCredit.value;
            List<TranCharges> chargeList = new List<TranCharges>();
            foreach (Tx tx in response.creditVendReceipt.transactions.tx)
            {
                Transaction vendTrans = new Transaction();
                if (tx.GetType() == typeof(CreditVendTx))
                {
                    CreditVendTx creditVendTx = (CreditVendTx)tx;
                    token.TokenValue = creditVendTx.amt.value.ToString();
                    STS1Token sts1Token = (STS1Token)creditVendTx.creditTokenIssue.token;

                    token.PrepaidToken = sts1Token.stsCipher;
                    /////////////////////////
                    StepTariffBreakdown tbreak = (StepTariffBreakdown)creditVendTx.tariffBreakdown;
                    string lifeMsg = "Purchased as";
                    //string lifeMsg = "";
                    string otherLifeMsg = "";
                    //foreach (Step chargeStep in tbreak.steps)
                    //{
                    //    otherLifeMsg = otherLifeMsg + " " + chargeStep.units.value + " " + chargeStep.units.siUnit + " at " + cash.tenderAmt.symbol + " " + chargeStep.rate.value + " per " + chargeStep.units.siUnit + ",";
                    //}
                    token.LifeLine = lifeMsg + otherLifeMsg;
                    if (token.LifeLine.EndsWith(","))
                    {
                        token.LifeLine = token.LifeLine.Remove((token.LifeLine.Length - 1));
                    }
                    /////////////////////////
                    if (token.PrepaidToken.Trim().Length == 20)
                    {
                        token.StatusCode = "SUCCESS";
                        token.MeterNumber = trans.CustRef;
                        //token.TerminalId = "0000000000001";
                        //token.VendorCode = vendorCode;
                        token.TotalAmount = tranAmount.ToString();
                        //token.MeterNumber = meterNo;

                    }
                    token.Units = creditVendTx.creditTokenIssue.units.value.ToString();
                }
                else if (tx.GetType() == typeof(DebtRecoveryTx))
                {
                    DebtRecoveryTx debtRecoveryTx = (DebtRecoveryTx)tx;
                    //token.DebtRecovery = token.DebtRecovery + debtRecoveryTx.amt.value;
                    token.DebtRecovery = token.DebtRecovery + debtRecoveryTx.amt.value;
                    TranCharges charge = new TranCharges();
                    charge.ChargeName = debtRecoveryTx.accDesc;
                    charge.Charge = debtRecoveryTx.amt.value + "";
                    charge.AccountNumber = debtRecoveryTx.accNo;
                    charge.MeterNumber = trans.CustRef;
                    charge.Balance = debtRecoveryTx.balance.value + "";
                    charge.TranId = trans.transactionID;
                    chargeList.Add(charge);
                }
                else if (tx.GetType() == typeof(PayAccTx))
                {
                    PayAccTx payAccountTx = (PayAccTx)tx;
                    token.PayAccount = payAccountTx.amt.value.ToString();
                }
                else if (tx.GetType() == typeof(ServiceChrgTx))
                {
                    ServiceChrgTx serviceChrgTx = (ServiceChrgTx)tx;
                    if (serviceChrgTx.accDesc.Trim().ToUpper().Equals("TAX"))
                    {
                        token.Tax = serviceChrgTx.amt.value.ToString();
                    }
                    else if (serviceChrgTx.accDesc.Trim().ToUpper().Equals("INFLATION ADJUSTMENT"))
                    {
                        token.Inflation = serviceChrgTx.amt.value.ToString();
                    }
                    else if (serviceChrgTx.accDesc.Trim().ToUpper().Equals("FUEL ADJUSTMENT"))
                    {
                        token.Fuel = serviceChrgTx.amt.value.ToString();
                    }
                    else if (serviceChrgTx.accDesc.Trim().ToUpper().Equals("FOREX ADJUSTMENT"))
                    {
                        token.Fx = serviceChrgTx.amt.value.ToString();
                    }
                    //else if (serviceChrgTx.accDesc.Trim().ToUpper().Equals("FIXED FEE"))
                    //{
                    //    token.ServiceFee = serviceChrgTx.amt.value.ToString();
                    //}
                }
                else
                {
                    //vendTransaction.TransactionType = VendTransactionType.Failure;
                    //vendTransaction.Description = "Unexcpected transaction type - see log";
                    //Console.WriteLine("Unexcpected transaction type - see log. Recieved " + tx.GetType().ToString());
                }
            }
            //Console.WriteLine("Token: " + token.Token);
            //Console.WriteLine("Units: " + Convert.ToString(token.Units));
            //Console.WriteLine("TokenValue: " + token.TokenValue);
            //Console.WriteLine("Tax: " + token.Tax);
            //Console.WriteLine("Inflation: " + token.Inflation);
            //Console.WriteLine("Fuel: " + token.Fuel);
            //Console.WriteLine("FX: " + token.Fx);
            //Console.WriteLine("DebtRecovery: " + token.DebtRecovery);
            //token.TransactionsCharges = chargeList;

        }
        catch (SoapException soapException)
        {
            token.StatusCode = "35";
            token.StatusDescription = soapException.InnerException.ToString();
            //XMLVendFaultResp xmlVendFaultResp = XMLDeserialize.Deserialize(soapException.Detail);
            //token.ErrorMessage = xmlVendFaultResp.fault.desc.ToUpper();
        }
        catch (Exception ex)
        {
            token.StatusCode = "100";
            token.StatusDescription = ex.Message;
            //token.ErrorMessage = "A SERIOUS ERROR OCCURED WHILE TRYING TO VEND A TOKEN";
        }

        return token;
    }
    public static MsgID GenerateMsgID()
    {
        MsgID msgID = new MsgID();
        msgID.dateTime = DateTime.Now.ToString("yyyyMMddhhmmss");

        Random random = new Random(DateTime.Now.Millisecond);
        int randomNumber = random.Next(1000000);

        msgID.uniqueNumber = randomNumber.ToString();

        return msgID;
    }
    [WebMethod]
    public QueryResponse VerifyWenrecoCustomer(string custRef, string vendorCode, string password)
    {
        QueryResponse resp = new QueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        try
        {

            dp.SaveRequestlog(vendorCode, "WENRECO", "VERIFICATION", custRef, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    UtilityCredentials creds = dp.GetUtilityCreds("WENRECO", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        UtilityReferences.WenrecoApi.XMLVendService service = new UtilityReferences.WenrecoApi.XMLVendService();
                        UtilityReferences.WenrecoApi.ConfirmCustomerReq request = new UtilityReferences.WenrecoApi.ConfirmCustomerReq();
                        UtilityReferences.WenrecoApi.ConfirmCustomerResp resps = new UtilityReferences.WenrecoApi.ConfirmCustomerResp();
                        request.authCred = new AuthCred();
                        request.authCred.opName = creds.UtilityCode;
                        request.authCred.password = creds.UtilityPassword;
                        request.authCred.newPassword = creds.UtilityPassword;
                        // set the client ID
                        EANDeviceID clientID = new EANDeviceID();
                        clientID.ean = creds.UtilityCode;
                        request.clientID = clientID;
                        // set the terminal ID
                        EANDeviceID terminalID = new EANDeviceID();
                        terminalID.ean = "0000000000001";
                        request.terminalID = terminalID;
                        // set the msg ID
                        request.msgID = Generate();
                        string msgId = request.msgID.uniqueNumber;
                        string msgDateTime = request.msgID.dateTime;
                        // set the meter identifier
                        MeterNumber meterNumber = new MeterNumber();
                        meterNumber.msno = custRef;// "04040406672";
                        VendIDMethod meth = new VendIDMethod();
                        meth.meterIdentifier = meterNumber;
                        request.idMethod = meth;
                        resps = service.ConfirmCustomerRequest(request);

                        //UtilityReferences.WenrecoApi.XMLVendService service = new UtilityReferences.WenrecoApi.XMLVendService();
                        //UtilityReferences.WenrecoApi.ConfirmCustomerReq request = new UtilityReferences.WenrecoApi.ConfirmCustomerReq();
                        //UtilityReferences.WenrecoApi.ConfirmCustomerResp resps = new UtilityReferences.WenrecoApi.ConfirmCustomerResp();
                        //request.authCred = new UtilityReferences.WenrecoApi.AuthCred();
                        //request.authCred.opName = "PPAY";
                        //request.authCred.password = creds.UtilityPassword;
                        //request.authCred.newPassword = creds.UtilityPassword;
                        //// set the client ID
                        //UtilityReferences.WenrecoApi.EANDeviceID clientID = new UtilityReferences.WenrecoApi.EANDeviceID();
                        //clientID.ean = "PPAY";
                        //request.clientID = clientID;
                        //// set the terminal ID
                        //UtilityReferences.WenrecoApi.EANDeviceID terminalID = new UtilityReferences.WenrecoApi.EANDeviceID();
                        //terminalID.ean = "0000000000001";
                        //request.terminalID = terminalID;
                        //// set the msg ID
                        //request.msgID = Generate();
                        //string msgId = request.msgID.uniqueNumber;
                        //string msgDateTime = request.msgID.dateTime;
                        //// set the meter identifier
                        //UtilityReferences.WenrecoApi.MeterNumber meterNumber = new UtilityReferences.WenrecoApi.MeterNumber();
                        //meterNumber.msno = custRef;
                        //UtilityReferences.WenrecoApi.VendIDMethod meth = new UtilityReferences.WenrecoApi.VendIDMethod();
                        //meth.meterIdentifier = meterNumber;
                        //request.idMethod = meth;
                        //service.Timeout = 24000000;
                        //resps = service.ConfirmCustomerRequest(request);
                        //if (resps.confirmCustResult.Length > 0)

                        if (false)
                        {
                            foreach (UtilityReferences.WenrecoApi.ConfirmCustResult cv in resps.confirmCustResult)
                            {
                                resp.CustomerName = cv.custVendDetail.name;
                                resp.CustomerReference = cv.meterDetail.msno;
                                resp.CustomerBalance = cv.custVendConfig.minVendAmt.value + "";
                                resp.StatusCode = "0";
                                resp.StatusDescription = "100";

                                Customer customer = new Customer();
                                customer.AgentCode = "WENRECO";
                                customer.CustomerName = resp.CustomerName;
                                customer.CustomerRef = resp.CustomerReference;
                                customer.CustomerType = "PREPAID";
                                customer.Balance = resp.CustomerBalance;

                                saveUmemeCustomerDetails(customer);

                            }
                        }
                        else
                        {
                            Customer cust = dp.GetCustomerDetails(custRef, "", "WENRECO");
                            if (cust.StatusCode == "0")
                            {
                                //  double bal = GetTotalBalance(cust);
                                resp.CustomerReference = cust.CustomerRef;
                                resp.CustomerName = cust.CustomerName;
                                resp.CustomerBalance = cust.Balance.ToString();
                                resp.StatusCode = cust.StatusCode;
                                resp.StatusDescription = cust.StatusDescription;
                                resp.StatusCode = "0";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                            else
                            {
                                resp.StatusCode = "100";
                                resp.StatusDescription = "CUSTOMER DETAILS NOT FOUND";
                            }
                        }
                    }
                    else
                    {
                        resp.StatusCode = "29";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (SoapException soapException)
        {
            XMLVendFaultResp xmlVendFaultResp = XMLDeserialize.Deserialize(soapException.Detail);

            if (xmlVendFaultResp.fault.GetType() == typeof(UnknownMeterEx))
            {
                resp.StatusCode = "100";
                resp.StatusDescription = "Unknown Meter Serial Number!";
            }
            else
            {
                resp.StatusCode = "100";
                resp.StatusDescription = "Unexpected XMLVend Fault Response    received: (" + xmlVendFaultResp.fault.GetType().ToString() + ")" + xmlVendFaultResp.fault.desc;
                //Console.WriteLine("Unexpected XMLVend Fault Response    received: (" + xmlVendFaultResp.fault.GetType().ToString() + ")" + xmlVendFaultResp.fault.desc);
            }
        }
        catch (Exception ex)
        {
            resp.StatusCode = "100";
            resp.StatusDescription = "GENERAL ERROR " + ex.Message;
            Console.WriteLine("A serious exception has occurred: (" + ex.GetType().ToString() + ") " + ex.Message);
        }

        return resp;
    }
    public UtilityReferences.WenrecoApi.MsgID Generate()
    {
        UtilityReferences.WenrecoApi.MsgID msgID = new UtilityReferences.WenrecoApi.MsgID();
        msgID.dateTime = DateTime.Now.ToString("yyyyMMddhhmmss");

        Random random = new Random(DateTime.Now.Millisecond);
        int randomNumber = random.Next(1000000);

        msgID.uniqueNumber = randomNumber.ToString();

        return msgID;
    }
    [WebMethod]
    public KCCAResponse QueryTuckSeeCustomerDetails(string customerReference, string vendorCode, string password)
    {//amwine
        KCCAResponse resp = new KCCAResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        BusinessLogic bll = new BusinessLogic();
        //DatabaseHandler dh = new DatabaseHandler();
        dataAccess dha = new dataAccess();

        try
        {
            dp.SaveRequestlog(vendorCode, "TUCKSEE", "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("TUCKSEE", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        KCCAResponse respresp = TuckSeeAuthenticate(creds);
                        if (respresp.ErrorCode != "0")
                        {
                            resp.ErrorCode = "100";
                            resp.ErrorDescription = resp.ErrorDescription + " AT TUCKSEE".ToUpper();
                            return resp;
                        }
                        resp = VerifyTuckSeePrn(customerReference, respresp.SessionKey, creds.Key);
                        string message = resp.ErrorDescription.ToLower();
                        if (resp.ErrorCode != "1" && resp.ErrorDescription.ToLower().Contains("available"))
                        {
                            resp.Success = "0";
                            resp.ErrorCode = "0";
                            resp.Status = "0";
                            //string message = resp.ErrorDescription.ToLower();

                            resp.ErrorDescription = "SUCCESS";


                            Customer customer = new Customer();
                            customer.AgentCode = "TUCKSEE";
                            customer.CustomerName = resp.CustomerName;
                            customer.CustomerRef = resp.PaymentReference;
                            customer.CustomerType = resp.SessionKey;
                            customer.Balance = resp.PaymentAmount.ToString();
                            customer.Area = resp.SystemCode;
                            customer.TIN = resp.SystemName;
                            customer.SessionKey = resp.AllowPartialPayment;
                            dp.SaveTuckseeCustomerDetails(customer);
                            //saveCustomerDetails(customer);
                        }
                        //else if (message.Contains("expired") || message.Contains("already") || message.Contains("cancelled "))
                        //{

                        //}
                        else
                        {
                            resp.Success = "100";
                            resp.PaymentReference = "";
                            resp.CustomerName = "";
                            resp.PaymentType = "";
                            resp.ErrorCode = "100";
                            resp.ErrorDescription = resp.ErrorDescription;

                            //Customer cust = dp.GetCustomerDetails(customerReference, "", "TUCKSEE");
                            //if (cust.CustomerType.ToUpper().Equals("ACTIVEPRN"))
                            //{
                            //    resp.Success = "1";
                            //    //resp.CustomerReference = customerReference;
                            //    resp.PaymentReference = customerReference;
                            //    resp.CustomerName = cust.CustomerName;
                            //    resp.SystemName = cust.AgentCode;
                            //    //resp.CustomerType = cust.CustomerType;
                            //    //resp.OutstandingBalance = cust.Balance.Split('.')[0];
                            //    resp.PaymentAmount = cust.Balance.Split('.')[0];
                            //    resp.ErrorCode = "0";
                            //    resp.ErrorDescription = "SUCCESS";




                            //}
                            //else
                            //{
                            //    resp.Success = "100";
                            //    resp.PaymentReference = "";
                            //    resp.CustomerName = "";
                            //    resp.PaymentType = "";
                            //    //resp.OutstandingBalance = "";
                            //    resp.ErrorCode = "100";
                            //    resp.ErrorDescription = "NOT FOUND";

                            //}

                        }

                    }

                }
            }
        }

        catch (System.Net.WebException wex)
        {
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "TUCKSEE");

            Customer cust = dp.GetCustomerDetails(customerReference, "", "TUCKSEE");
            if (cust.StatusCode.Equals("0"))
            {
                resp.PaymentReference = cust.CustomerRef;
                resp.CustomerName = cust.CustomerName;
                resp.SessionKey = cust.TIN;
                resp.PaymentAmount = cust.Balance.Split('.')[0];
                resp.ErrorCode = "0";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);

            }
            else
            {
                if (wex.Message.ToUpper().Contains("TIMEOUT"))
                {
                    resp.ErrorCode = "30";
                    resp.ErrorDescription = "CONNECTION TO TUCKSEE TIMED OUT";
                }
                else
                {
                    resp.ErrorCode = "30";
                    resp.ErrorDescription = "UNABLE TO CONNECT TO TUCKSEE";
                }
                //resp.CustomerReference = "";
                //resp.CustomerName = "";
                //resp.CustomerType = "";
                //resp.OutstandingBalance = "";
                //resp.StatusCode = "100";
                //resp.StatusDescription = "INVALID REFERENCE NUMBER";
            }
        }
        catch (SqlException sqlex)
        {
            resp.ErrorCode = "31";
            resp.ErrorDescription = "PEGPAY DB UNAVAILABLE";
        }
        catch (Exception ex)
        {
            resp.ErrorCode = "32";
            resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "TUCKSEE");
        }
        return resp;
    }


    private KCCAResponse TuckSeeAuthenticate(UtilityCredentials creds)
    {
        //, string sessionKey
        //string api_key = "DCF70D06664503BB44890EDDE279A506";
        //string api_username = "UIDMTNBETAACCOUNT";
        //string api_password = "$w%CvvBbxIyuniJn7*%+7j1o4YKRxT1q";
        //string backref = "";
        //string key = "5C91E23DA785D78F8C2804D2680AC220";
        KCCAResponse resp = new KCCAResponse();
        string datastring = creds.SecretKey + creds.UtilityCode + creds.UtilityPassword + creds.Key;
        string hash = MD5Hash(datastring);
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            UtilityReferences.Tucksee.PaymentNotificationService serv = new UtilityReferences.Tucksee.PaymentNotificationService();
            object obj = serv.authenticate(creds.SecretKey, creds.UtilityCode, creds.UtilityPassword, hash, "");

            resp = ParseTuskseeXmlResponse(obj.ToString(), "AUTH");

        }
        catch (Exception ee)
        {
            resp.Status = "100";
            resp.Success = ee.Message;
        }
        return resp;
    }
    internal KCCAResponse ParseTuskseeXmlResponse(string resp, string Action)
    {
        try
        {
            KCCAResponse authresp = new KCCAResponse();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(resp);

            if (Action.Trim().ToUpper().Equals("AUTH"))
            {
                foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                {
                    string nodeName = node.Name.ToUpper();
                    switch (nodeName)
                    {

                        case "SUCCESS":
                            authresp.ErrorCode = node.InnerText;
                            authresp.Status = node.InnerText;
                            if (authresp.ErrorCode == "1")

                                authresp.ErrorCode = "0";
                            break;
                        case "SESSIONKEY":
                            authresp.SessionKey = node.InnerText;
                            break;
                        case "MESSAGE":
                            authresp.Status = node.InnerText;
                            break;

                    }
                }


            }
            else if (Action.Trim().ToUpper().Equals("VERIFICATION"))
            {
                foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                {
                    string nodeName = node.Name.ToLower();
                    switch (nodeName)
                    {
                        case "success":
                            authresp.ErrorCode = node.InnerText;
                            if (authresp.ErrorCode == "1")
                                authresp.ErrorCode = "0";
                            break;
                        case "message":
                            authresp.ErrorDescription = node.InnerText;

                            break;
                        case "tpgoreference":
                            authresp.TpgoReference = node.InnerText;
                            break;
                        case "customername":
                            authresp.CustomerName = node.InnerText;
                            break;
                        case "systemcode":
                            authresp.SystemCode = node.InnerText;
                            break;
                        case "systemname":
                            authresp.SystemName = node.InnerText;
                            break;
                        case "prn":
                            authresp.PaymentReference = node.InnerText;
                            break;
                        case "prndate":
                            authresp.PaymentDate = node.InnerText;

                            break;
                        case "sessionkey":
                            authresp.SessionKey = node.InnerText;

                            break;
                        case "expirydate":
                            authresp.ExpiryDate = node.InnerText;
                            break;
                        case "paymentamount":
                            authresp.PaymentAmount = node.InnerText;
                            break;
                        case "paymentcurrency":
                            authresp.PaymentCurrency = node.InnerText;
                            break;
                        case "allowpartial":
                            authresp.AllowPartialPayment = node.InnerText;
                            break;
                    }
                }

            }
            else if (Action.Trim().ToUpper().Equals("TRANSACT"))
            {
                XmlNode message = doc.DocumentElement.SelectSingleNode("/transactResponse/message");
                authresp.Success = message.Attributes["success"].Value;
                if (authresp.Success.Equals("1"))
                {
                    authresp.SessionKey = message.Attributes["session_key"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.TransactionID = message.Attributes["transactionID"].Value;
                    authresp.PaymentReference = message.Attributes["PRN"].Value;
                    //authresp.PaymentReference = message.Attributes["paymentReference"].Value;
                    //authresp.PaymentDate = message.Attributes["paymentDate"].Value;
                    //authresp.TrackingID = message.Attributes["trackingID"].Value;
                }
                else
                {
                    authresp.ErrorCode = message.Attributes["error_code"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.ErrorDescription = message.InnerText.ToString();
                }
            }
            else if (Action.Trim().ToUpper().Equals("CLOSETRANSACT"))
            {
                XmlNode message = doc.DocumentElement.SelectSingleNode("/closeTransactionResponse/message");
                authresp.Success = message.Attributes["success"].Value;
                if (authresp.Success.Equals("1"))
                {
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.TransactionID = message.Attributes["transactionID"].Value;
                    authresp.PaymentReference = message.Attributes["paymentReference"].Value;
                }
                else
                {
                    authresp.ErrorCode = message.Attributes["error_code"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.ErrorDescription = message.InnerText.ToString();
                }
            }

            return authresp;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public string MD5Hash(string input)
    {
        StringBuilder hash = new StringBuilder();
        MD5CryptoServiceProvider md5provider = new MD5CryptoServiceProvider();
        byte[] bytes = md5provider.ComputeHash(new UTF8Encoding().GetBytes(input));

        for (int i = 0; i < bytes.Length; i++)
        {
            hash.Append(bytes[i].ToString("x2"));
        }
        return hash.ToString();
    }
    //private TuckSeeResponse TuckSeeAuthenticate(UtilityCredentials creds)
    //{
    //    string api_key = "DCF70D06664503BB44890EDDE279A506";
    //    string api_username = "UIDMTNBETAACCOUNT";
    //    string api_password = "$w%CvvBbxIyuniJn7*%+7j1o4YKRxT1q";
    //    string backref = "";
    //    string key = "5C91E23DA785D78F8C2804D2680AC220";
    //    TuckSeeResponse resp = new TuckSeeResponse();
    //    string datastring = api_key + api_username + api_password + key;
    //    string hash = MD5Hash(datastring);
    //    try
    //    {
    //        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
    //        Tusksee.PaymentNotificationService serv = new Tester.Tusksee.PaymentNotificationService();
    //        object obj = serv.authenticate(creds.Key, creds.UtilityCode, creds.UtilityPassword, hash, "");

    //        resp = ParseTuskseeXmlResponse(obj.ToString(), "AUTH");

    //    }
    //    catch (Exception ee)
    //    {
    //        resp.Status = "100";
    //        resp.Success = ee.Message;
    //    }
    //    return resp;
    //}

    private KCCAResponse VerifyTuckSeePrn(string prnReference, string sessionKey, string apiKey)
    {
        KCCAResponse resp = new KCCAResponse();
        try
        {

            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;

            string datastring = sessionKey + prnReference + apiKey;
            string hash = MD5Hash(datastring);

            UtilityReferences.Tucksee.PaymentNotificationService serv = new UtilityReferences.Tucksee.PaymentNotificationService();

            object obj = serv.verifyReference(sessionKey, prnReference, hash, "");
            resp = ParseTuskseeXmlResponse(obj.ToString(), "VERIFICATION");



        }
        catch (Exception ee)
        {
            resp.ErrorCode = "0";
            resp.ErrorDescription = ee.Message;
        }
        return resp;
    }
    [WebMethod]
    public KCCAQueryResponse QueryKCCACustomerDetails(string customerReference, string vendorCode, string password)
    {//amwine
        KCCAQueryResponse resp = new KCCAQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        BusinessLogic bll = new BusinessLogic();
        //DatabaseHandler dh = new DatabaseHandler();
        dataAccess dha = new dataAccess();

        try
        {
            dp.SaveRequestlog(vendorCode, "KCCA", "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("KCCA", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        //Query TEST KCCA
                        resp = GetKCCADetails(customerReference, vendorCode, creds);

                        if (resp.StatusDescription.ToUpper() == "PRN TRANSACTION ALREADY COMPLETED")
                        {
                            string MtnID = dha.GetMtnTransactionId(customerReference);
                            resp.StatusDescription = "PRN TRANSACTION ALREADY COMPLETED." +
                                                    " Transaction ID: " + MtnID;
                            return resp;
                        }
                        else if (resp.StatusCode.Equals("100"))
                        {
                            //Query Customers' Table
                            Customer cust = dp.GetCustomerDetails(customerReference, "", "KCCA");
                            if (cust.CustomerType.ToUpper().Equals("ACTIVEPRN"))
                            {
                                resp.Success = "1";
                                resp.CustomerReference = customerReference;
                                resp.PaymentReference = customerReference;
                                resp.CustomerName = cust.CustomerName;
                                resp.CustomerType = cust.CustomerType;
                                resp.OutstandingBalance = cust.Balance.Split('.')[0];
                                resp.PaymentAmount = cust.Balance.Split('.')[0];
                                resp.StatusCode = "0";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                resp.ErrorCode = resp.StatusCode;
                                resp.ErrorDescription = resp.StatusDescription;
                                return resp;
                            }
                            else
                            {
                                resp.Success = "0";
                                resp.CustomerReference = "";
                                resp.PaymentReference = "";
                                resp.CustomerName = "";
                                resp.CustomerType = "";
                                resp.OutstandingBalance = "";
                                resp.StatusCode = "100";
                                resp.StatusDescription = "INVALID KCCA PRN REFERENCE NUMBER";
                                resp.ErrorCode = resp.StatusCode;
                                resp.ErrorDescription = resp.StatusDescription;
                                return resp;
                            }
                        }
                        else
                        {
                            return resp;
                        }
                    }
                    else
                    {
                        Customer cust = dp.GetCustomerDetails(customerReference, "", "KCCA");
                        if (cust.StatusCode.Equals("0"))
                        {
                            resp.Success = "1";
                            resp.Status = "A";
                            resp.CustomerReference = cust.CustomerRef;
                            resp.CustomerName = cust.CustomerName;
                            resp.CustomerType = cust.CustomerType;
                            resp.OutstandingBalance = cust.Balance;
                            resp.PaymentAmount = cust.Balance;
                            resp.StatusCode = "0";

                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            resp.ErrorCode = resp.StatusCode;
                            resp.ErrorDescription = resp.StatusDescription;
                        }
                        else
                        {
                            resp.Success = "0";
                            resp.Status = "D";
                            resp.CustomerReference = "";
                            resp.CustomerName = "";
                            resp.CustomerType = "";
                            resp.OutstandingBalance = "";
                            resp.StatusCode = "100";
                            resp.StatusDescription = "INVALID REFERENCE NUMBER";
                            resp.ErrorCode = resp.StatusCode;
                            resp.ErrorDescription = resp.StatusDescription;
                        }
                    }
                }
            }
        }

        catch (System.Net.WebException wex)
        {
            if (wex.Message.ToUpper().Contains("TIMEOUT"))
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "CONNECTION TO KCCA TIMED OUT";
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO KCCA";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "KCCA");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = "PEGPAY DB UNAVAILABLE";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }

    public KCCAQueryResponse GetKCCADetails(string custRef, string VendorCode, UtilityCredentials creds)
    {

        KCCAQueryResponse Queryresp = new KCCAQueryResponse();
        try
        {
            if (creds.BankCode == "DTB")
            {
                Queryresp = QueryKccaBanksApi(custRef, VendorCode);
            }
            else
            {
                Queryresp = QueryKccaTelecomsApi(custRef, VendorCode);
            }
        }
        catch (Exception ex)
        {
            Queryresp.PaymentAmount = "";
            Queryresp.CustomerName = "";
            Queryresp.StatusCode = "100";
            Queryresp.StatusDescription = "UNABLE TO CONNECT TO KCCA";
        }
        return Queryresp;
    }

    private string GetNewSessionKey(string vendor, bool isBank)
    {
        DatabaseHandler dh = new DatabaseHandler();
        UtilityCredentials creds = dh.GetUtilityCreds("KCCA", vendor);
        string response = "";
        string ap_key = "";
        string ap_username = "";
        string ap_passord = "";
        string ap_backCheck = "";
        string ap_hash = "";

        ap_key = creds.Key;
        ap_username = creds.UtilityCode;
        ap_passord = creds.UtilityPassword;

        if (isBank)
        {
            response = GetKccaAuthentication2(ap_key, ap_username, ap_passord, ap_hash, ap_backCheck);
        }
        else
        {
            response = GetKccaAuthentication(ap_key, ap_username, ap_passord, ap_hash, ap_backCheck);
        }

        KCCAResponse resp = ParseXmlResponse(response, "AUTH");
        return resp.SessionKey;
    }

    private KCCAQueryResponse QueryKccaBanksApi(string custRef, string vendor)
    {
        KCCAQueryResponse Queryresp = new KCCAQueryResponse();
        KCCAResponse resp = new KCCAResponse();
        //get Authentication details
        string ap_backCheck = "";
        string ap_hash = "";

        DatabaseHandler dh = new DatabaseHandler();

        string SessionKey = GetNewSessionKey(vendor, true);

        string response = "";

        response = VerifyKccaPRN2(SessionKey, custRef, ap_hash, ap_backCheck);

        resp = ParseXmlResponse(response, "VERIFICATION");

        if (resp.Success.Equals("1") && resp.Status.Equals("A"))
        {
            string amount2 = resp.PaymentAmount.Split('.')[0];
            Queryresp.PaymentAmount = amount2;
            Queryresp.CustomerName = resp.CustomerName;
            Queryresp.PaymentReference = resp.PaymentReference;
            Queryresp.SessionKey = resp.SessionKey;
            Queryresp.Coin = resp.Coin;
            Queryresp.StatusCode = "0";
            Queryresp.StatusDescription = "SUCCESS";
            Queryresp.Success = "SUCCESS";

            //Save Customer in the Customer Table
            Customer cust = new Customer();
            cust.CustomerName = resp.CustomerName;
            cust.CustomerRef = resp.PaymentReference;
            cust.CustomerType = resp.Status == "A" ? "ActivePRN" : "TransactedPRN";
            cust.Balance = resp.PaymentAmount;
            cust.AgentCode = "KCCA";

            saveKCCACustomerDetails(cust);
        }
        else
        {
            Console.WriteLine("Failed to Create Authentication Details\nError: " + resp.ErrorDescription);
            Queryresp.PaymentAmount = "";
            Queryresp.CustomerName = "";
            Queryresp.StatusCode = "100";
            Queryresp.StatusDescription = resp.ErrorDescription;
        }
        return Queryresp;
    }

    private KCCAQueryResponse QueryKccaTelecomsApi(string custRef, string vendor)
    {
        KCCAQueryResponse Queryresp = new KCCAQueryResponse();
        KCCAResponse resp = new KCCAResponse();
        //get Authentication details
        string ap_backCheck = "";
        string ap_hash = "";

        DatabaseHandler dh = new DatabaseHandler();
        string SessionKey = GetNewSessionKey(vendor, false);
        if (string.IsNullOrEmpty(SessionKey))
        {
            SessionKey = dh.GetSystemSettings2("8", "4");
        }

        string response = VerifyKccaPRN(SessionKey, custRef, ap_hash, ap_backCheck);
        resp = ParseXmlResponse(response, "VERIFICATION");

        if (resp.Success.Equals("1") && resp.Status.Equals("A"))
        {
            string amount2 = resp.PaymentAmount.Split('.')[0];
            Queryresp.PaymentAmount = amount2;
            Queryresp.CustomerName = resp.CustomerName;
            Queryresp.PaymentReference = resp.PaymentReference;
            Queryresp.SessionKey = resp.SessionKey;
            Queryresp.Coin = resp.Coin;
            Queryresp.StatusCode = "0";
            Queryresp.StatusDescription = "SUCCESS";
            Queryresp.Success = "SUCCESS";

            //Save Customer in the Customer Table
            Customer cust = new Customer();
            cust.CustomerName = resp.CustomerName;
            cust.CustomerRef = resp.PaymentReference;
            cust.CustomerType = resp.Status == "A" ? "ActivePRN" : "TransactedPRN";
            cust.Balance = resp.PaymentAmount;        //resp.PaymentAmount;
            cust.AgentCode = "KCCA";

            saveKCCACustomerDetails(cust);
        }
        else
        {
            Console.WriteLine("Failed to Create Authentication Details\nError: " + resp.ErrorDescription);
            Queryresp.PaymentAmount = "";
            Queryresp.CustomerName = "";
            Queryresp.StatusCode = "100";
            Queryresp.StatusDescription = resp.ErrorDescription;

        }
        return Queryresp;
    }

    private string GetVendorType(string vendor)
    {
        throw new Exception("The method or operation is not implemented.");
    }

    public KCCAQueryResponse GetKCCADetails_old(string custRef, UtilityCredentials creds)
    {
        KCCAQueryResponse Queryresp = new KCCAQueryResponse();
        try
        {
            KCCAResponse resp = new KCCAResponse();
            //get Authentication details
            string ap_backCheck = "";
            string ap_hash = "";

            DatabaseHandler dh = new DatabaseHandler();

            string SessionKey = dh.GetSystemSettings2("8", "4");

            //string respons = bll.GetKccaAuthentication(creds.Key, creds.UtilityCode, creds.UtilityPassword, ap_hash, ap_backCheck);
            //KCCAQueryResponse resp1 = bll.ParseXmlResponse(respons, "AUTH");

            string ap_key = "C9773BB7F8D0AD7F94609B3A5A0A15C1";
            string ap_username = "UIDDiamondTrustBank";
            string ap_passord = "63cz1_j7EzFCsGNmhSNi21r6zN5Kl$IO";

            string respons = bll.GetKccaAuthentication(ap_key, ap_username, ap_passord, ap_hash, ap_backCheck);
            KCCAQueryResponse resp1 = bll.ParseXmlResponse(respons, "AUTH");

            string response = VerifyKccaPRN(resp1.SessionKey, custRef, ap_hash, ap_backCheck);
            resp = ParseXmlResponse(response, "VERIFICATION");

            if (resp.Success.Equals("1") && resp.Status.Equals("A"))
            {
                string amount2 = resp.PaymentAmount.Split('.')[0];
                Queryresp.PaymentAmount = amount2;
                Queryresp.CustomerName = resp.CustomerName;
                Queryresp.PaymentReference = resp.PaymentReference;
                Queryresp.SessionKey = resp.SessionKey;
                Queryresp.Coin = resp.Coin;
                Queryresp.StatusCode = "0";
                Queryresp.StatusDescription = "SUCCESS";
                Queryresp.Success = "SUCCESS";

                //Save Customer in the Customer Table
                Customer cust = new Customer();
                cust.CustomerName = resp.CustomerName;
                cust.CustomerRef = resp.PaymentReference;
                cust.CustomerType = resp.Status == "A" ? "ActivePRN" : "TransactedPRN";
                cust.Balance = resp.PaymentAmount;        //resp.PaymentAmount;
                cust.AgentCode = "KCCA";

                saveKCCACustomerDetails(cust);
            }
            else
            {
                Console.WriteLine("Failed to Create Authentication Details\nError: " + resp.ErrorDescription);
                Queryresp.PaymentAmount = "";
                Queryresp.CustomerName = "";
                Queryresp.StatusCode = "100";
                Queryresp.StatusDescription = resp.ErrorDescription;

            }
        }
        catch (Exception ex)
        {
            Queryresp.PaymentAmount = "";
            Queryresp.CustomerName = "";
            Queryresp.StatusCode = "100";
            Queryresp.StatusDescription = "UNABLE TO CONNECT TO KCCA";
        }
        return Queryresp;
    }

    internal string GetKccaAuthentication(string ap_key, string ap_username, string ap_passord, string hash, string backref)
    {
        try
        {
            // KCCA.BankPaymentService payment = new KCCA.BankPaymentService();
            UtilityReferences.KCCA.TelecomPaymentService payment = new UtilityReferences.KCCA.TelecomPaymentService();
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertValidation;
            string resp = payment.authenticate(ap_key, ap_username, ap_passord, hash, backref);
            return resp;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    internal string GetKccaAuthentication2(string ap_key, string ap_username, string ap_passord, string hash, string backref)
    {
        try
        {
            UtilityReferences.KCCA2.BankPaymentService payment = new UtilityReferences.KCCA2.BankPaymentService();
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertValidation;
            string resp = payment.authenticate(ap_key, ap_username, ap_passord, hash, backref);
            return resp;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    internal string VerifyKccaPRN(string SessionKey, string custRef, string Hash, string ap_backCheck)
    {
        try
        {
            //KCCA.BankPaymentService payment = new KCCA.BankPaymentService();
            UtilityReferences.KCCA.TelecomPaymentService payment = new UtilityReferences.KCCA.TelecomPaymentService();
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertValidation;
            string resp = payment.verifyReference(SessionKey, custRef, Hash, ap_backCheck);
            return resp;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    internal string VerifyKccaPRN2(string SessionKey, string custRef, string Hash, string ap_backCheck)
    {
        try
        {
            UtilityReferences.KCCA2.BankPaymentService payment = new UtilityReferences.KCCA2.BankPaymentService();
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertValidation;
            string resp = payment.verifyReference(SessionKey, custRef, Hash, ap_backCheck);
            return resp;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    internal KCCAResponse ParseXmlResponse(string resp, string Action)
    {
        try
        {
            KCCAResponse authresp = new KCCAResponse();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(resp);

            if (Action.Trim().ToUpper().Equals("AUTH"))
            {
                XmlNode message = doc.DocumentElement.SelectSingleNode("/authenticateResponse/message");
                authresp.Success = message.Attributes["success"].Value;
                if (authresp.Success.Equals("1"))
                {
                    authresp.SessionKey = message.Attributes["session_key"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                }
                else
                {
                    authresp.ErrorCode = message.Attributes["error_code"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.ErrorDescription = message.InnerText.ToString();
                }
            }
            else if (Action.Trim().ToUpper().Equals("VERIFICATION"))
            {
                XmlNode message = doc.DocumentElement.SelectSingleNode("/verifyReferenceResponse/message");
                authresp.Success = message.Attributes["success"].Value;
                if (authresp.Success.Equals("1"))
                {
                    authresp.SessionKey = message.Attributes["session_key"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.PaymentReference = message.Attributes["PRN"].Value;
                    authresp.CustomerName = message.Attributes["customerName"].Value;
                    authresp.CustomerPhone = message.Attributes["customerPhone"].Value;
                    authresp.PaymentAmount = message.Attributes["paymentAmount"].Value;
                    authresp.PaymentCurrency = message.Attributes["paymentCurrency"].Value;
                    authresp.Status = message.Attributes["status"].Value;
                    authresp.Coin = message.Attributes["COIN"].Value;
                    authresp.PrnDate = message.Attributes["prnDate"].Value;
                    authresp.ExpiryDate = message.Attributes["expiryDate"].Value;
                    // authresp.PaymentReference = message.Attributes["paymentReference"].Value;
                    //authresp.PaymentType = message.Attributes["paymentType"].Value;
                }
                else
                {
                    authresp.ErrorCode = message.Attributes["error_code"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.ErrorDescription = message.InnerText.ToString();
                }
            }
            else if (Action.Trim().ToUpper().Equals("TRANSACT"))
            {
                XmlNode message = doc.DocumentElement.SelectSingleNode("/transactResponse/message");
                authresp.Success = message.Attributes["success"].Value;
                if (authresp.Success.Equals("1"))
                {
                    authresp.SessionKey = message.Attributes["session_key"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.TransactionID = message.Attributes["transactionID"].Value;
                    authresp.PaymentReference = message.Attributes["PRN"].Value;
                    //authresp.PaymentReference = message.Attributes["paymentReference"].Value;
                    //authresp.PaymentDate = message.Attributes["paymentDate"].Value;
                    //authresp.TrackingID = message.Attributes["trackingID"].Value;
                }
                else
                {
                    authresp.ErrorCode = message.Attributes["error_code"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.ErrorDescription = message.InnerText.ToString();
                }
            }
            else if (Action.Trim().ToUpper().Equals("CLOSETRANSACT"))
            {
                XmlNode message = doc.DocumentElement.SelectSingleNode("/closeTransactionResponse/message");
                authresp.Success = message.Attributes["success"].Value;
                if (authresp.Success.Equals("1"))
                {
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.TransactionID = message.Attributes["transactionID"].Value;
                    authresp.PaymentReference = message.Attributes["paymentReference"].Value;
                }
                else
                {
                    authresp.ErrorCode = message.Attributes["error_code"].Value;
                    authresp.RefCheck = message.Attributes["refcheck"].Value;
                    authresp.ErrorDescription = message.InnerText.ToString();
                }
            }

            return authresp;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //[WebMethod]
    //public KCCAQueryResponse QueryStarTimesCustomerDetails(string customerReference, string vendorCode, string password)
    //{//amwine
    //    KCCAQueryResponse resp = new KCCAQueryResponse();
    //    DatabaseHandler dp = new DatabaseHandler();
    //    UtilityCredentials creds;
    //    try
    //    {
    //        dp.SaveRequestlog(vendorCode, "STARTIMES", "VERIFICATION", customerReference, password);
    //        DataTable vendorData = dp.GetVendorDetails(vendorCode);
    //        if (isValidVendorCredentials(vendorCode, password, vendorData))
    //        {
    //            if (isActiveVendor(vendorCode, vendorData))
    //            {
    //                string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
    //                int loginCount = int.Parse(strLoginCount);
    //                if (loginCount > 0)
    //                {
    //                    dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
    //                }
    //                creds = dp.GetUtilityCreds("KCCA", vendorCode);
    //                if (!creds.UtilityCode.Equals(""))
    //                {
    //                    System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
    //                    UtilityReferences.KCCA.EPayment kccaapi = new UtilityReferences.KCCA.EPayment();
    //                    UtilityReferences.KCCA.Customer cust = kccaapi.QueryKccaCustomer(customerReference, creds.UtilityCode, creds.UtilityPassword);
    //                    if (cust.StatusCode.Equals("0"))
    //                    {
    //                        resp.CustomerReference = cust.CustomerRef;
    //                        resp.CustomerName = cust.CustomerName;
    //                        resp.CustomerType = cust.CustomerType;
    //                        resp.OutstandingBalance = cust.Balance.ToString();
    //                        resp.StatusCode = cust.StatusCode;
    //                        resp.StatusDescription = cust.StatusDescription;
    //                        Customer customer = new Customer();
    //                        customer.AgentCode = "KCCA";
    //                        customer.CustomerName = resp.CustomerName;
    //                        customer.CustomerRef = resp.CustomerReference;
    //                        customer.CustomerType = resp.CustomerType;
    //                        saveCustomerDetails(customer);
    //                    }
    //                    else
    //                    {
    //                        resp.CustomerReference = "";
    //                        resp.CustomerName = "";
    //                        resp.CustomerType = "";
    //                        resp.OutstandingBalance = "";
    //                        resp.StatusCode = "100";
    //                        resp.StatusDescription = cust.StatusDescription;
    //                    }
    //                }
    //                else
    //                {
    //                    resp.StatusCode = "29";
    //                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
    //                }
    //            }
    //            else
    //            {
    //                resp.StatusCode = "11";
    //                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
    //            }
    //        }
    //        else
    //        {
    //            resp.StatusCode = "2";
    //            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
    //        }
    //    }
    //    catch (System.Net.WebException wex)
    //    {
    //        Customer cust = dp.GetCustomerDetails(customerReference, "", "KCCA");
    //        if (cust.StatusCode.Equals("0"))
    //        {
    //            resp.CustomerType = cust.CustomerType;
    //            resp.CustomerName = cust.CustomerName;
    //            resp.CustomerReference = cust.CustomerRef;
    //            resp.OutstandingBalance = "0";
    //            resp.StatusCode = "0";
    //            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
    //        }
    //        else
    //        {
    //            resp.StatusCode = "30";
    //            resp.StatusDescription = "UNABLE TO CONNECT TO KCCA";
    //        }
    //        dp.LogError(wex.Message, vendorCode, DateTime.Now, "KCCA");
    //    }
    //    catch (SqlException sqlex)
    //    {
    //        resp.StatusCode = "31";
    //        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
    //    }
    //    catch (Exception ex)
    //    {
    //        resp.StatusCode = "32";
    //        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
    //        dp.LogError(ex.Message, vendorCode, DateTime.Now, "KCCA");
    //    }
    //    return resp;
    //}

    // [WebMethod]
    //public KCCAQueryResponse NewQueryKCCACustomerDetails(string CustomerRef, string vendorCode, string password)
    //{
    //    DataTable dt = new DataTable();
    //    BusinessLogic bll = new BusinessLogic();
    //    DatabaseHandler dh = new DatabaseHandler();
    //    PhoneValidator pv = new PhoneValidator();
    //    KCCAQueryResponse resp = new KCCAQueryResponse();
    //    UtilityCredentials creds;
    //    try
    //    {
    //        dh.SaveRequestlog(vendorCode, "KCCA", "VERIFICATION", CustomerRef, password);
    //        DataTable vendorData = dh.GetVendorDetails(vendorCode);
    //        if (isValidVendorCredentials(vendorCode, password, vendorData))
    //        {
    //            if (isActiveVendor(vendorCode, vendorData))
    //            {
    //                string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
    //                int loginCount = int.Parse(strLoginCount);
    //                if (loginCount > 0)
    //                {
    //                    dh.UpdateVendorInvalidLoginCount(vendorCode, 0);
    //                }
    //                creds = dh.GetUtilityCreds("KCCA", vendorCode);
    //                if (!creds.UtilityCode.Equals(""))
    //                {
    //                    dt = dh.GetSystemSettings("7", "5");
    //                    string api_key = dt.Rows[0]["ValueVarriable"].ToString();//"GGSAIUHJUY5GFFDFFGWES5436MTN678";
    //                    dt = dh.GetSystemSettings("8", "5");
    //                    string backRef = dt.Rows[0]["ValueVarriable"].ToString();
    //                    dt = dh.GetSystemSettings("9", "5");
    //                    string hash = dt.Rows[0]["ValueVarriable"].ToString();
    //                    if (CustomerRef != null)
    //                    {
    //                        UtilityReferences.KCCA1.TelecomPaymentService service = new UtilityReferences.KCCA1.TelecomPaymentService();
    //                        string authentication = service.authenticate(api_key, creds.UtilityCode, creds.UtilityPassword, "", backRef);
    //                        resp = bll.ParserXML(authentication);

    //                        if (resp.status.Equals("1"))
    //                        {
    //                            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
    //                            string verification = service.verifyReference(resp.sessionKey, CustomerRef, "", "");
    //                            resp = bll.verifyXml(verification);
    //                            Customer customer = new Customer();
    //                            if (resp.status.Equals("1"))
    //                            {
    //                                resp.StatusCode = "0";
    //                                resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //                                customer.CustomerRef = resp.PaymentReference;
    //                                customer.CustomerName = resp.CustomerName;
    //                                customer.Balance = resp.PaymentAmount;
    //                                customer.SessionKey = resp.sessionKey;
    //                                customer.Area = "";
    //                                customer.AgentCode = "KCCA";
    //                                customer.StatusCode = resp.StatusCode;
    //                                customer.StatusDescription = resp.StatusDescription;
    //                                dh.SaveCustomerDetails(customer);
    //                            }
    //                            else
    //                            {
    //                                resp.CustomerReference = "";
    //                                resp.CustomerName = "";
    //                                resp.CustomerType = "";
    //                                resp.OutstandingBalance = "";
    //                                resp.StatusCode = resp.StatusCode;
    //                                resp.StatusDescription = resp.StatusDescription;
    //                            }

    //                        }
    //                        else
    //                        {

    //                            resp.StatusDescription = "ERROR OCCURED DURING THE VERIFICATION OF CUSTOMER";
    //                        }


    //                    }
    //                    else
    //                    {
    //                        resp.StatusCode = "1";
    //                        resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //                    }

    //                }
    //            }
    //            else
    //            {
    //                resp.StatusCode = "11";
    //                resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //            }
    //        }
    //        else
    //        {
    //            resp.StatusCode = "2";
    //            resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //        }
    //    }
    //    catch (System.Net.WebException wex)
    //    {
    //        Customer cust = dh.GetCustomerDetails(CustomerRef, "", "KCCA");
    //        if (cust.StatusCode.Equals("0"))
    //        {
    //            resp.CustomerName = cust.CustomerName;
    //            resp.CustomerReference = cust.CustomerRef;
    //            resp.OutstandingBalance = "0";
    //            resp.StatusCode = "0";
    //            resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //        }
    //        else
    //        {
    //            resp.StatusCode = "30";
    //            resp.StatusDescription = "UNABLE TO CONNECT TO KCCA";
    //        }

    //        dh.LogError(wex.Message, vendorCode, DateTime.Now, "KCCA");
    //    }
    //    catch (SqlException sqlex)
    //    {
    //        resp.StatusCode = "31";
    //        resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //    }
    //    catch (Exception ex)
    //    {

    //        resp.StatusCode = "32";
    //        resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
    //        dh.LogError(ex.Message, vendorCode, DateTime.Now, "KCCA");
    //    }
    //    return resp;
    //}
    [WebMethod]
    public SolarCustomer ValidateSolarCustomer(string utilityCode, string meternumber, string vendorCode, string password)
    {
        SolarCustomer customer = new SolarCustomer();
        if (utilityCode == "SOLAR")
        {
            DatabaseHandler dp = new DatabaseHandler();
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    SolarHandler handler = new SolarHandler();
                    customer = handler.ValidateMeterNumber(meternumber);
                }
                else
                {
                    //86X61RS004
                    customer.StatusCode = "99";
                    customer.StatusDescription = "Deactivated vendor. Access denied".ToUpper();
                }
            }
            else
            {
                customer.StatusCode = "99";
                customer.StatusDescription = "Invalid vendor Credentials. Access denied".ToUpper();
            }
        }
        else
        {
            customer.StatusCode = "99";
            customer.StatusDescription = "Deamon! Unknown utility".ToUpper();
        }
        return customer;
    }
    [WebMethod]
    public SchoolsQueryResponse ValidateStudentDetails(string utilityCode, string customerReference, string vendorCode, string password)
    {
        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
        UtilityReferences.SchoolsApi.SchoolApi schapi = new UtilityReferences.SchoolsApi.SchoolApi();
        UtilityReferences.SchoolsApi.ApiResponse resp = new UtilityReferences.SchoolsApi.ApiResponse();
        SchoolsQueryResponse schresp = new SchoolsQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        dp.SaveRequestlog(vendorCode, "NWSC", "VERIFICATION", customerReference, password);
        DataTable vendorData = dp.GetVendorDetails(vendorCode);
        if (string.IsNullOrEmpty(customerReference))
        {
            schresp.StatusCode = "99";
            schresp.StatusDescription = "Please provide a student number".ToUpper();
        }
        else if (string.IsNullOrEmpty(utilityCode))
        {
            schresp.StatusCode = "99";
            schresp.StatusDescription = "Please provide a school code".ToUpper();
        }
        else if (string.IsNullOrEmpty(vendorCode) || string.IsNullOrEmpty(password))
        {
            schresp.StatusCode = "99";
            schresp.StatusDescription = "Incomplete credentials".ToUpper();
        }

        if (!isValidVendorCredentials(vendorCode, password, vendorData))
        {
            schresp.StatusCode = "2";
            schresp.StatusDescription = dp.GetStatusDescr(schresp.StatusCode);

        }
        else
        {
            UtilityCredentials creds = dp.GetUtilityCreds("FLEXIPAY", vendorCode);
            if (!creds.UtilityCode.Equals(""))
            {
                resp = schapi.GetStudent(customerReference, utilityCode, creds.UtilityCode, creds.UtilityPassword);

                if (resp.ErrorCode == "0")
                {
                    UtilityReferences.SchoolsApi.Student student = new UtilityReferences.SchoolsApi.Student();
                    student = resp.Student;
                    schresp.CustomerName = student.StdName;
                    schresp.CustomerReference = student.StdNumber;
                    schresp.School = student.School;
                    schresp.Level = student.Level;
                    schresp.Amount = student.AmountToPay;
                    schresp.AccountNumber = student.SchoolAccount;
                }
                schresp.StatusCode = resp.ErrorCode;
                schresp.StatusDescription = resp.ErrorDescription;
            }
            else
            {
                schresp.StatusCode = "29";
                schresp.StatusDescription = dp.GetStatusDescr(schresp.StatusCode);
            }

        }
        return schresp;
    }
    [WebMethod]
    public SchoolsQueryResponse ValidateSchoolCode(string schoolcode)
    {
        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
        UtilityReferences.SchoolsApi.SchoolApi schapi = new UtilityReferences.SchoolsApi.SchoolApi();
        UtilityReferences.SchoolsApi.ApiResponse resp = new UtilityReferences.SchoolsApi.ApiResponse();
        SchoolsQueryResponse schresp = new SchoolsQueryResponse();
        if (string.IsNullOrEmpty(schoolcode))
        {
            schresp.StatusCode = "99";
            schresp.StatusDescription = "Please provide a school code";
            return schresp;
        }
        try
        {
            resp = schapi.ValidateSchoolCode(schoolcode);
            if (resp.ErrorCode == "0")
            {
                schresp.School = resp.ReceiptNumber;
            }
            schresp.StatusCode = resp.ErrorCode;
            schresp.StatusDescription = resp.ErrorDescription;
        }
        catch (Exception ee)
        {
            schresp.StatusCode = "100";
            schresp.StatusDescription = ee.Message.ToUpper();
        }
        return schresp;
    }

    [WebMethod]
    public SchoolsQueryResponse QuerySchoolStudentDetails(string utilityCode, string customerReference, string vendorCode, string password)
    {//method1
        SchoolsQueryResponse resp = new SchoolsQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        string groupCode = "";
        try
        {
            dp.SaveRequestlog(vendorCode, utilityCode, "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);

            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds(utilityCode, vendorCode);

                    if (!creds.UtilityCode.Equals(""))
                    {
                        if (utilityCode.Equals("UMU"))
                        {
                            resp = QueryUMUCustomerDetails(utilityCode, customerReference, vendorCode);
                        }
                        else if (utilityCode.Equals("MUBS") || utilityCode.Equals("MUST") || utilityCode.Equals(""))
                        {
                            resp = QueryCemasDetails(utilityCode, customerReference, vendorCode);
                        }
                        //else if (utilityCode.Equals("KYU"))
                        //{
                        //    resp = QueryKyuCustomerDetails(customerReference, vendorCode, password);
                        //}
                        //else if (utilityCode.Equals("MAK"))
                        //{
                        //    resp = QueryMAKCustomerDetails(creds, customerReference, vendorCode);
                        //}
                        else
                        {
                            DataTable StudentDetails = dp.GetStudentDetails(utilityCode, customerReference);
                            if (StudentDetails.Rows.Count > 0)
                            {
                                resp.CustomerReference = StudentDetails.Rows[0]["CustomerRef"].ToString();
                                resp.CustomerName = StudentDetails.Rows[0]["CustomerName"].ToString();
                                resp.CustomerType = StudentDetails.Rows[0]["CustomerType"].ToString();
                                resp.OutstandingBalance = StudentDetails.Rows[0]["AccountBal"].ToString().Split('.')[0];
                                if (string.IsNullOrEmpty(resp.OutstandingBalance)) { resp.OutstandingBalance = "0"; }
                                resp.StatusCode = "0";
                                resp.StatusDescription = "SUCCESS";
                            }
                            else
                            {
                                resp.CustomerReference = "";
                                resp.CustomerName = "";
                                resp.CustomerType = "";
                                resp.OutstandingBalance = "";
                                resp.StatusCode = "100";
                                resp.StatusDescription = "INVALID STUDENT REFERENCE NUMBER";
                            }
                        }
                    }
                    else
                    {
                        resp.StatusCode = "29";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, "", utilityCode);
            if (cust.StatusCode.Equals("0"))
            {
                resp.CustomerType = cust.CustomerType;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerReference = cust.CustomerRef;
                resp.OutstandingBalance = "0";
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO " + utilityCode;
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, utilityCode);
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, utilityCode);
        }
        return resp;
    }

    private SchoolsQueryResponse QueryKyuCustomerDetails(string studentNo, string vendorcode, string vendorPassword)
    {
        SchoolsQueryResponse queryResp = new SchoolsQueryResponse();
        try
        {
            System.Net.ServicePointManager.Expect100Continue = false;
            System.Net.ServicePointManager.Expect100Continue = false;
            UtilityReferences.NkumbaPayInterface.EPayment nku = new UtilityReferences.NkumbaPayInterface.EPayment();
            UtilityReferences.NkumbaPayInterface.ValidateResponse NkumbaResponse = new UtilityReferences.NkumbaPayInterface.ValidateResponse();
            string RequestState = "1";
            string APIUsername = "1482963BBEF5";
            string ApiPassword = "c7ca173be871b939e15bd48be94412";
            string ReferenceNumber = studentNo;
            string BankCode = "STANBIC";
            string datatodigest = "ref=" + ReferenceNumber + "&bank_code=" + BankCode;
            string datatosign = "ref=" + ReferenceNumber + "&api_user=" + APIUsername + "&api_pwd=" + ApiPassword;
            string RequestDigest = bll.GetRequestDigest(datatodigest, ApiPassword);
            string RequestSignature = bll.GetRequestSignature(datatosign);

            NkumbaResponse = nku.ValidateRequest(BankCode, ReferenceNumber.Trim(), RequestState, RequestSignature, RequestDigest);

            Console.WriteLine("******************************************************************");
            Console.WriteLine("Testing KYU Validate Request");
            Console.WriteLine("******************************************************************");
            Console.WriteLine("Message = " + NkumbaResponse.ResponseStatus);
            if (NkumbaResponse.ResponseStatus.Equals("200"))
            {
                queryResp.CustomerName = NkumbaResponse.EntityName;
                queryResp.CustomerReference = NkumbaResponse.ReferenceNo;
                queryResp.OutstandingBalance = NkumbaResponse.Amount;
                queryResp.CustomerType = NkumbaResponse.AuthToken;
                queryResp.StatusCode = "0";
                queryResp.StatusDescription = "SUCCESS";

                Customer customer = new Customer();
                string Utility = "KYU";
                customer.AgentCode = Utility;
                customer.CustomerName = NkumbaResponse.EntityName;
                customer.CustomerRef = NkumbaResponse.ReferenceNo;
                customer.CustomerType = NkumbaResponse.AuthToken;
                customer.Balance = NkumbaResponse.Amount;
                saveCustomerDetails(customer);
            }
            else if (NkumbaResponse.ResponseStatus.Equals("404"))
            {

                queryResp.StatusCode = "100";
                queryResp.StatusDescription = "INVALID STUDENT REFERENCE";

            }
            else
            {
                queryResp.StatusCode = "100";
                queryResp.StatusDescription = NkumbaResponse.ResponseStatus;
            }
            return queryResp;
        }
        catch (WebException ex)
        {
            queryResp.StatusCode = "100";
            queryResp.StatusDescription = "UNABLE TO CONNECT TO KYAMBOGO UNIVERSITY";
        }
        catch (Exception ex)
        {
            queryResp.StatusCode = "101";
            queryResp.StatusDescription = "GENERAL ERROR AT PEGASUS";
        }

        return queryResp;

    }

    private SchoolsQueryResponse QueryKyuCustomerDetailsOld(string studentNo, string vendorcode, string vendorPassword)
    {
        SchoolsQueryResponse queryResp = new SchoolsQueryResponse();
        try
        {
            System.Net.ServicePointManager.Expect100Continue = false;
            UtilityReferences.KYU.ValidateResponse response = new UtilityReferences.KYU.ValidateResponse();
            UtilityReferences.KYU.EPayment epayment = new UtilityReferences.KYU.EPayment();
            string ReferenceNo = studentNo;

            string State = "1";
            string password = "126e8ad746c7a0f1e325589974696263303751349081f49673";
            //string dataToSign = "ref=" +studentNo;
            string dataToSign = "ref=" + studentNo;
            string Signature = GetKyuDigitalSignature(password, dataToSign); ;

            string SourceId = "AB5BD455A7D4";
            response = epayment.ValidateRequest(ReferenceNo, State, Signature, SourceId);

            Console.WriteLine("******************************************************************");
            Console.WriteLine("Testing KYU Validate Request");
            Console.WriteLine("******************************************************************");
            Console.WriteLine("Message = " + response.Message);
            if (response.Status.Equals("200"))
            {
                queryResp.CustomerName = response.EntityTitle;
                queryResp.CustomerReference = response.RequestReferenceNo;
                queryResp.OutstandingBalance = response.Amount;
                queryResp.CustomerType = response.AuthToken;
                queryResp.StatusCode = "0";
                queryResp.StatusDescription = "SUCCESS";
            }
            else
            {
                queryResp.StatusCode = "100";
                queryResp.StatusDescription = response.Message;
            }
            return queryResp;
        }
        catch (WebException ex)
        {
            queryResp.StatusCode = "100";
            queryResp.StatusDescription = "UNABLE TO CONNECT TO KYAMBOGO UNIVERSITY";
        }
        catch (Exception ex)
        {
            queryResp.StatusCode = "101";
            queryResp.StatusDescription = "GENERAL ERROR AT PEGASUS";
        }

        return queryResp;

    }
    public static string GetKyuDigitalSignature(string sign, string contentTosgin)
    {
        //current
        byte[] key = new Byte[64];
        byte[] content = new Byte[100];
        key = Encoding.ASCII.GetBytes(sign);
        content = Encoding.ASCII.GetBytes(contentTosgin);

        using (HMACSHA256 hmc = new HMACSHA256(key))
        {
            //byte[] hashvalue = hmc.ComputeHash(content);
            byte[] hashvalue = hmc.ComputeHash(content);
            //return hashvalue;
            StringBuilder hexValue = new StringBuilder(hashvalue.Length * 2);
            foreach (byte b in hashvalue)
            {
                hexValue.Append(b.ToString("X02"));

            }
            return hexValue.ToString().ToLower();
        }

    }

    [WebMethod]
    public PostResponse MakeDSTVPayment(DSTVTransaction trans)
    {
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "DSTV", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "1";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.CustRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "1";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //check for a bouquetCode
            else if (string.IsNullOrEmpty(trans.Area))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = "PLEASE SUPPLY A BOUQUET CODE";
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                            if (!(vendorType.Equals("PREPAID")))
                                                            {
                                                                UtilityCredentials creds = dp.GetUtilityCreds("DSTV", trans.VendorCode);
                                                                creds.UtilityCode = "DSTV";

                                                                if (!creds.UtilityCode.Equals(""))
                                                                {
                                                                    resp.PegPayPostId = dp.PostPayTvTransaction(trans, trans.UtilityCode);
                                                                    resp.StatusCode = "0";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                                else
                                                                {
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            //dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO URA");
            //resp.PegPayPostId = "";
            resp.StatusCode = "0";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "URA");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "URA");
        }
        return resp;
    }
    [WebMethod]
    public BETWAYPostResponse MakeBETWAYPayment(BETWAYTransaction trans)
    {
        BETWAYPostResponse resp = new BETWAYPostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //log incoming Details
        //dp.logKCCAPostHit(trans);
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "BETWAY", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds("BETWAY", trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                //post in pegpay
                                                                if (trans.PaymentType == null)
                                                                {
                                                                    trans.PaymentType = "";
                                                                }
                                                                if (trans.CustomerType == null)
                                                                {
                                                                    trans.CustomerType = "";

                                                                }

                                                                resp.PegPayPostId = dp.PostUmemeTransaction(trans, "BETWAY");
                                                                resp.ReceiptNumber = resp.PegPayPostId;
                                                                resp.StatusCode = "0";
                                                                resp.StatusDescription = "SUCCESS";


                                                            }
                                                            else
                                                            {
                                                                resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "BETWAY");
        }
        catch (SqlException sqlex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "BETWAY");

        }
        catch (Exception ex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "BETWAY");
        }
        return resp;
    }

    private string FormatPayWayTel(string toFormat)
    {
        if (toFormat.Length == 9)
        {
            toFormat = "0" + toFormat;
        }
        else if (toFormat.Length == 12)
        {
            toFormat = "0" + toFormat.Substring(3);
        }
        return toFormat;
    }



    private SchoolsQueryResponse QueryMAKCustomerDetails(UtilityCredentials creds, string customerReference, string vendorCode)
    {
        SchoolsQueryResponse resp = new SchoolsQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        try
        {

            if (!creds.UtilityCode.Equals(""))
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                UtilityReferences.Makerere.EPayment makapi = new UtilityReferences.Makerere.EPayment();
                UtilityReferences.Makerere.Student cust = makapi.QueryMukStudent(customerReference, creds.UtilityCode, creds.UtilityPassword);
                if (cust.StatusCode.Equals("0"))
                {
                    resp.CustomerReference = cust.StudentNumber;
                    resp.CustomerName = cust.StudentName;
                    resp.CustomerType = cust.Course;
                    resp.OutstandingBalance = "0";
                    resp.StatusCode = cust.StatusCode;
                    resp.StatusDescription = cust.StatusDescription;
                    Customer customer = new Customer();
                    customer.AgentCode = "MAK";
                    customer.CustomerName = resp.CustomerName;
                    customer.CustomerRef = resp.CustomerReference;
                    customer.CustomerType = resp.CustomerType;
                    customer.Balance = cust.Balance.ToString();
                    saveUmemeCustomerDetails(customer);
                }
                else
                {
                    resp.CustomerReference = "";
                    resp.CustomerName = "";
                    resp.CustomerType = "";
                    resp.OutstandingBalance = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = cust.StatusDescription;
                }
            }
            else
            {
                resp.StatusCode = "29";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

        }
        catch (System.Net.WebException wex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, "", "MAK");
            if (cust.StatusCode.Equals("0"))
            {
                resp.CustomerType = cust.CustomerType;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerReference = cust.CustomerRef;
                resp.OutstandingBalance = "0";
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO MAKERERE";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "MAK");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "MAK");
        }
        return resp;
    }

    [WebMethod]
    public NWSCQueryResponse QueryNWSCCustomerDetails(string customerReference, string area, string vendorCode, string password)
    {
        NWSCQueryResponse resp = new NWSCQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {
            dp.SaveRequestlog(vendorCode, "NWSC", "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("NWSC", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                        NWSCBillingInterface nwscapi = new NWSCBillingInterface();
                        UtilityReferences.NWSC.Customer cust = nwscapi.verifyCustomerDetailsWithArea(customerReference, area, creds.UtilityCode, creds.UtilityPassword);
                        if (cust.CustomerError.Equals("NONE"))
                        {
                            resp.Area = cust.Area;
                            resp.CustomerName = cust.CustName;
                            resp.CustomerReference = cust.CustRef;
                            resp.OutstandingBalance = cust.OutstandingBal.ToString();
                            resp.StatusCode = "0";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            Customer customer = new Customer();
                            customer.AgentCode = "NWSC";
                            customer.CustomerName = resp.CustomerName;
                            customer.CustomerRef = customerReference;
                            customer.Area = resp.Area;
                            //customer.Balance=
                            saveCustomerDetails(customer);
                        }
                        else
                        {
                            Customer cust2 = dp.GetCustomerDetails(customerReference, area, "NWSC");
                            if (cust2.StatusCode.Equals("0"))
                            {
                                resp.Area = cust2.Area;
                                resp.CustomerName = cust2.CustomerName;
                                resp.CustomerReference = cust2.CustomerRef;
                                resp.OutstandingBalance = "0";
                                resp.StatusCode = "0";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                            else
                            {
                                resp.Area = "";
                                resp.CustomerName = "";
                                resp.CustomerReference = "";
                                resp.StatusCode = "100";
                                resp.StatusDescription = cust.CustomerError;
                            }
                        }
                    }
                    else
                    {
                        resp.StatusCode = "29";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, area, "NWSC");
            if (cust.StatusCode.Equals("0"))
            {
                resp.Area = cust.Area;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerReference = cust.CustomerRef;
                resp.OutstandingBalance = "0";
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO NWSC";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "NWSC");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "NWSC");
        }
        return resp;
    }
    [WebMethod]
    public NSSFQueryResponse QueryNSSFCustomerDetails(string utilityCode, string customerReference, string vendorCode, string Password)
    {
        NSSFQueryResponse nssfqueryresponse = new NSSFQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {
            dp.SaveRequestlog(vendorCode, "NSSF", "VERIFICATION", customerReference, Password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, Password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }
                    creds = dp.GetUtilityCreds("NSSF", vendorCode);
                    if (!creds.UtilityCode.Equals(""))
                    {
                        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                        UtilityReferences.StanbicBankApi.PegPay pegpay = new UtilityReferences.StanbicBankApi.PegPay();
                        UtilityReferences.StanbicBankApi.QueryRequest stanbicbanknssfqueryrequest = new UtilityReferences.StanbicBankApi.QueryRequest();
                        UtilityReferences.StanbicBankApi.Response stanbicbanknssfresponse = new UtilityReferences.StanbicBankApi.Response();
                        stanbicbanknssfqueryrequest.QueryField1 = customerReference;
                        stanbicbanknssfqueryrequest.QueryField4 = "NSSF";
                        stanbicbanknssfqueryrequest.QueryField5 = creds.UtilityCode;
                        stanbicbanknssfqueryrequest.QueryField6 = creds.UtilityPassword;


                        stanbicbanknssfresponse = pegpay.QueryCustomerDetails(stanbicbanknssfqueryrequest);


                        if (stanbicbanknssfresponse.ResponseField6.Equals("0"))
                        {
                            nssfqueryresponse.CustomerReference = stanbicbanknssfresponse.ResponseField1;
                            nssfqueryresponse.EmployerNo = stanbicbanknssfresponse.ResponseField2;
                            nssfqueryresponse.Employer = stanbicbanknssfresponse.ResponseField3;
                            nssfqueryresponse.OutstandingBalance = stanbicbanknssfresponse.ResponseField4;
                            nssfqueryresponse.Period = stanbicbanknssfresponse.ResponseField5;
                            nssfqueryresponse.StatusCode = stanbicbanknssfresponse.ResponseField6;
                            nssfqueryresponse.StatusDescription = stanbicbanknssfresponse.ResponseField7;
                            nssfqueryresponse.PaymentMethod = stanbicbanknssfresponse.ResponseField8;


                            Customer customer = new Customer();
                            customer.AgentCode = "NSSF";
                            customer.CustomerName = nssfqueryresponse.Employer;
                            customer.CustomerRef = nssfqueryresponse.CustomerReference;
                            customer.Balance = nssfqueryresponse.OutstandingBalance;
                            customer.Area = nssfqueryresponse.EmployerNo;
                            customer.CustomerType = nssfqueryresponse.PaymentMethod;
                            saveUmemeCustomerDetails(customer);
                            //cust.CustomerRef, cust.CustomerName, cust.CustomerType, "" + balance, cust.AgentCode
                        }
                        else
                        {
                            nssfqueryresponse.CustomerReference = "";
                            nssfqueryresponse.EmployerNo = "";
                            nssfqueryresponse.Employer = "";
                            nssfqueryresponse.OutstandingBalance = "";
                            nssfqueryresponse.Period = stanbicbanknssfresponse.ResponseField5;
                            nssfqueryresponse.StatusCode = stanbicbanknssfresponse.ResponseField6;
                            nssfqueryresponse.StatusDescription = stanbicbanknssfresponse.ResponseField7;
                            nssfqueryresponse.PaymentMethod = "";
                        }
                    }
                    else
                    {
                        nssfqueryresponse.StatusCode = "29";
                        nssfqueryresponse.StatusDescription = dp.GetStatusDescr(nssfqueryresponse.StatusCode);
                    }
                }
                else
                {
                    nssfqueryresponse.StatusCode = "11";
                    nssfqueryresponse.StatusDescription = dp.GetStatusDescr(nssfqueryresponse.StatusCode);
                }
            }
            else
            {
                nssfqueryresponse.StatusCode = "2";
                nssfqueryresponse.StatusDescription = dp.GetStatusDescr(nssfqueryresponse.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, "", "NSSF");
            if (cust.StatusCode.Equals("0"))
            {
                //nssfqueryresponse.Area = cust.Area;
                nssfqueryresponse.CustomerName = cust.CustomerName;
                nssfqueryresponse.CustomerReference = cust.CustomerRef;
                nssfqueryresponse.OutstandingBalance = "0";
                nssfqueryresponse.StatusCode = "0";
                nssfqueryresponse.StatusDescription = dp.GetStatusDescr(nssfqueryresponse.StatusCode);
            }
            else
            {
                nssfqueryresponse.StatusCode = "30";
                nssfqueryresponse.StatusDescription = "UNABLE TO CONNECT TO NSSF";
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, "NSSF");
        }
        catch (SqlException sqlex)
        {
            nssfqueryresponse.StatusCode = "31";
            nssfqueryresponse.StatusDescription = dp.GetStatusDescr(nssfqueryresponse.StatusCode);
        }
        catch (Exception ex)
        {
            nssfqueryresponse.StatusCode = "32";
            nssfqueryresponse.StatusDescription = dp.GetStatusDescr(nssfqueryresponse.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, "NSSF");
        }
        return nssfqueryresponse;
    }

    [WebMethod]
    public PostResponse MakeURAPayment(URATransaction trans)
    {
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "URA", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "1";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.CustRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "1";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TIN == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "34";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.TIN.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "34";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                            if (!(vendorType.Equals("PREPAID")))
                                                            {
                                                                UtilityCredentials creds = dp.GetUtilityCreds("URA", trans.VendorCode);
                                                                if (!creds.UtilityCode.Equals(""))
                                                                {

                                                                    if (trans.VendorCode.Equals("CELL"))
                                                                    {
                                                                        resp.PegPayPostId = dp.PostURATransaction(trans, "URA");
                                                                        BankResponse resp1 = SendTransactionToBank(trans);
                                                                        if (resp1.IsSuccessfullAtBank())
                                                                        {
                                                                            dp.UpdateSentTransaction(resp.PegPayPostId, resp1.BankId, "1");
                                                                            resp.StatusCode = "0";
                                                                            resp.StatusDescription = "SUCCESS";
                                                                        }
                                                                        else
                                                                        {
                                                                            dp.deleteTransaction(trans.VendorTransactionRef, resp1.StatusDescription
                                                                             );
                                                                            resp.StatusCode = "100";
                                                                            resp.StatusDescription = resp1.StatusDescription;
                                                                        }
                                                                        //resp.PegPayPostId = dp.PostURATransaction(trans, "URA");
                                                                        //UraPmtService ura = new UraPmtService();
                                                                        //TransactionEntity uraTrans = GetUraTrans(trans, creds);
                                                                        //TransactionEntity[] arr = { uraTrans };
                                                                        //string[] RetStr = ura.NotifyUraPayment(creds.UtilityCode, creds.UtilityPassword, arr);
                                                                        //URA uraSender = new URA();
                                                                        //string[] RetStr = uraSender.makePaymentUraNewImplementation(trans, creds);
                                                                        //string uraResp = RetStr[0];

                                                                        //if (uraResp.Equals("<ResponseCode>" + trans.CustRef + "||T</ResponseCode>"))
                                                                        //{
                                                                        //    resp.StatusCode = "0";
                                                                        //    resp.StatusDescription = "SUCCESS";
                                                                        //}
                                                                        //else if (uraResp.Equals("<ResponseCode>" + trans.CustRef + "|DBG004|T</ResponseCode>"))
                                                                        //{
                                                                        //    resp.StatusCode = "0";
                                                                        //    resp.StatusDescription = "SUCCESS";
                                                                        //}
                                                                        //else if (uraResp.Equals("<ResponseCode>" + trans.CustRef + "|E001|SUCCESS</ResponseCode>"))
                                                                        //{
                                                                        //    resp.StatusCode = "0";
                                                                        //    resp.StatusDescription = "SUCCESS";
                                                                        //}
                                                                        //else if (uraResp.Equals("<ResponseCode>" + trans.CustRef + "|E000|SUCCESS</ResponseCode>"))
                                                                        //{
                                                                        //    resp.StatusCode = "0";
                                                                        //    resp.StatusDescription = "SUCCESS";
                                                                        //}
                                                                        //else if (uraResp.Trim().Contains("SUCCESS".ToUpper()))
                                                                        //{
                                                                        //    resp.StatusCode = "0";
                                                                        //    resp.StatusDescription = "SUCCESS";

                                                                        //}
                                                                        //else
                                                                        //{
                                                                        //    string msg1 = uraResp;
                                                                        //    msg1 = msg1.Replace("<ResponseCode>", "");
                                                                        //    msg1 = msg1.Replace("</ResponseCode>", "");
                                                                        //    dp.deleteTransaction(resp.PegPayPostId, msg1 + " AT URA");
                                                                        //    resp.StatusCode = "100";
                                                                        //    resp.StatusDescription = msg1;
                                                                        //}
                                                                    }
                                                                    else
                                                                    {
                                                                        resp.PegPayPostId = dp.PostURATransaction(trans, "URA");
                                                                        resp.StatusCode = "0";
                                                                        resp.StatusDescription = "SUCCESS";
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            //dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO URA");
            //resp.PegPayPostId = "";
            resp.StatusCode = "0";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "URA");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "URA");
        }
        return resp;
    }

    private UtilityReferences.StanbicBankApi.TransactionRequest GetStanbicFmbURATranDetails(URATransaction trans)
    {
        try
        {
            UtilityReferences.StanbicBankApi.TransactionRequest tran = new UtilityReferences.StanbicBankApi.TransactionRequest();
            tran.PostField1 = trans.CustRef;
            tran.PostField2 = trans.CustName;// CustomerName
            tran.PostField3 = "";
            tran.PostField4 = "MBURA";//for Financle Mpbile Banking URA code is MBURA
            tran.PostField5 = trans.PaymentDate;
            tran.PostField6 = "";//CustomerType;
            tran.PostField7 = trans.TransactionAmount;
            tran.PostField8 = "CASH";
            tran.PostField9 = "";//VendorCode
            tran.PostField10 = "";//Password
            tran.PostField11 = trans.CustomerTel;
            tran.PostField12 = "0";
            tran.PostField13 = "";
            tran.PostField14 = trans.CustomerTel;
            tran.PostField15 = "0";
            tran.PostField18 = "";
            tran.PostField20 = trans.VendorTransactionRef;
            tran.PostField21 = "CASH"; //Payment Type;
            string dataToSign = tran.PostField1 + tran.PostField2 + tran.PostField11 + tran.PostField20 + tran.PostField9 + tran.PostField10 + tran.PostField5 + tran.PostField14 + tran.PostField7 + tran.PostField18 + tran.PostField8;
            tran.PostField16 = dataToSign;// SignCertificate(dataToSign);
            return tran;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }



    private BankResponse SendTransactionToBank(URATransaction trans)
    {
        BankResponse bankResp = new BankResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
            UtilityReferences.StanbicBankApi.PegPay pegpay = new UtilityReferences.StanbicBankApi.PegPay();
            UtilityReferences.StanbicBankApi.TransactionRequest tran = new UtilityReferences.StanbicBankApi.TransactionRequest();
            UtilityReferences.StanbicBankApi.Response resp = new UtilityReferences.StanbicBankApi.Response();
            UtilityReferences.StanbicBankApi.QueryRequest query = new UtilityReferences.StanbicBankApi.QueryRequest();
            tran = GetStanbicFmbURATranDetails(trans);
            resp = pegpay.PostTransaction(tran);

            //success
            if (resp.ResponseField6.Equals("0") || resp.ResponseField6.Equals("21"))
            {
                bankResp.StatusCode = resp.ResponseField6;
                bankResp.StatusDescription = resp.ResponseField7;
                bankResp.BankId = resp.ResponseField8;
                bankResp.BankBranch = "";
            }
            else
            {
                bankResp.StatusCode = resp.ResponseField6;
                bankResp.StatusDescription = resp.ResponseField7;
                bankResp.BankBranch = "";
            }
        }
        catch (WebException ex)
        {
            bankResp.StatusCode = "100";
            bankResp.StatusDescription = "TIMEOUT";
        }
        catch (Exception ex)
        {
            bankResp.StatusCode = "100";
            bankResp.StatusDescription = ex.Message;
        }

        return bankResp;
    }


    //[WebMethod]
    //public UmemePostResponse MakeUmemePayment(UmemeTransaction trans)
    //{
    //    UmemePostResponse postResp = new UmemePostResponse();
    //    //Log Transaction as is in MSMQ
    //    if (!trans.VendorCode.Equals("MTN"))
    //    {
    //        bool success= SendTransactionToQueue(othersUmemeQueue, trans);
    //        postResp.
    //    }
    //    else
    //    {
    //        postResp = MakeUmemePaymentOld(trans);
    //    }


    //}


    private static void WriteToErrorLog(Transaction trans, string Message)
    {
        File.WriteAllText(@"C:\" + trans.VendorTransactionRef + "ErrorLog.txt", Message);
    }


    [WebMethod]
    public UmemePostResponse MakeUmemePayment(UmemeTransaction trans)
    {
        UmemePostResponse resp = new UmemePostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //DateTime timeIn = DateTime.Now;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "UMEME", "POSTING", trans.CustRef, trans.Password);

            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidPayCode(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "27";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidCustType(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "28";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds("UMEME", trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                                if (!(vendorType.Equals("PREPAID")))
                                                                {
                                                                    if (trans.CustomerType.ToUpper().Equals("PREPAID"))
                                                                    {
                                                                        if (trans.VendorCode.ToUpper().Equals("ORANGE") || (trans.VendorCode.ToUpper().Equals("MTN") && trans.Narration.Contains("POS PAYMENT")))
                                                                        {
                                                                            //check balance
                                                                            Customer cust = new Customer();
                                                                            cust = dp.GetCustomerDetails(trans.CustRef, "", creds.Utility);
                                                                            double balance = Convert.ToDouble(cust.Balance.Trim());
                                                                            double amt = Convert.ToDouble(trans.TransactionAmount.Trim());
                                                                            if (amt > balance)
                                                                            {
                                                                                resp.PegPayPostId = dp.PostUmemeTransaction(trans, "UMEME");//post in pegpay db
                                                                                System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                                                                                EPayment umemeapi = new EPayment();
                                                                                umemeapi.Timeout = 39000;
                                                                                UtilityReferences.UMEME.Transaction umemeTrans = GetUmemeTrans(trans, creds);

                                                                                UtilityReferences.UMEME.Response umemeResp = umemeapi.PostBankUmemePayment(umemeTrans);
                                                                                if (umemeResp.StatusCode.Equals("0"))
                                                                                {
                                                                                    dp.UpdateSentTransaction(resp.PegPayPostId, umemeResp.ReceiptNumber, "SUCCESS");
                                                                                    resp.ReceiptNumber = umemeResp.ReceiptNumber;
                                                                                    resp.StatusCode = "0";
                                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                                }
                                                                                else
                                                                                {
                                                                                    dp.deleteTransaction(resp.PegPayPostId, umemeResp.StatusDescription + " AT UMEME");
                                                                                    resp.ReceiptNumber = "";
                                                                                    resp.PegPayPostId = "";
                                                                                    resp.StatusCode = "100";
                                                                                    resp.StatusDescription = umemeResp.StatusDescription + " AT UMEME";
                                                                                }
                                                                            }

                                                                        }
                                                                        //if its an MTN UMEME transaction
                                                                        else if (trans.VendorCode.Equals("MTN"))
                                                                        {
                                                                            //MTN expect pending in the response 
                                                                            //and status code 1000
                                                                            resp.PegPayPostId = dp.PostUmemeTransaction(trans, "UMEME");//post in pegpay db
                                                                            resp.ReceiptNumber = resp.PegPayPostId;
                                                                            resp.StatusCode = "0";
                                                                            resp.StatusDescription = "SUCCESS";//dp.GetStatusDescr(resp.StatusCode);
                                                                        }
                                                                        else
                                                                        {
                                                                            //check balance
                                                                            Customer cust = new Customer();
                                                                            cust = dp.GetCustomerDetails(trans.CustRef, "", creds.Utility);
                                                                            double balance = Convert.ToDouble(cust.Balance.Trim());
                                                                            double amt = Convert.ToDouble(trans.TransactionAmount.Trim());
                                                                            if (amt > balance)
                                                                            {

                                                                                if (VendorHasBlackListedAccounts(trans.VendorCode))
                                                                                {
                                                                                    //NB:For Orange We insert into 
                                                                                    //Recieved Transactions                                                                                                           //later becoz the umeme api may be down
                                                                                    //and user has a debt
                                                                                    //e.g user pays 20000 and debt is 10000
                                                                                    //we should only insert 10000 in the recieved
                                                                                    //if umeme is down so when its back on we can 
                                                                                    //send thru only that amount and not the 20k he
                                                                                    //paid...think abt it

                                                                                    resp = DoOrangeMoneyUMEMETransaction(trans);
                                                                                }
                                                                                else
                                                                                {
                                                                                    resp.PegPayPostId = dp.PostUmemeTransaction(trans, "UMEME");//post in pegpay db
                                                                                    resp.ReceiptNumber = resp.PegPayPostId;
                                                                                    resp.StatusCode = "0";
                                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                //insufficent amount to cover basic charges
                                                                                resp.ReceiptNumber = "";
                                                                                resp.PegPayPostId = "";
                                                                                resp.StatusCode = "36";
                                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                                dp.LogError(resp.StatusDescription, trans.VendorCode, DateTime.Now, "UMEME");
                                                                            }

                                                                        }
                                                                    }
                                                                    //This is a post paid customer
                                                                    else
                                                                    {
                                                                        if (trans.VendorCode.Equals("MTN") && !trans.Narration.Equals("POS PAYMENT"))
                                                                        {
                                                                            resp.PegPayPostId = dp.PostUmemeTransaction(trans, "UMEME");//post in pegpay db
                                                                            resp.ReceiptNumber = resp.PegPayPostId;
                                                                            resp.StatusCode = "0";
                                                                            resp.StatusDescription = "SUCCESS";//dp.GetStatusDescr(resp.StatusCode);
                                                                        }
                                                                        else
                                                                        {
                                                                            resp.PegPayPostId = dp.PostUmemeTransaction(trans, "UMEME");//post in pegpay db
                                                                            resp.ReceiptNumber = resp.PegPayPostId;
                                                                            resp.StatusCode = "0";
                                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                        }
                                                                    }
                                                                }
                                                                //This is a PrePaid Vendor
                                                                else
                                                                {
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "20";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }//Uncomment Me including else below
                                else
                                {
                                    resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }

        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                if (wex.Message.ToUpper().Contains("UNABLE TO CONNECT TO THE REMOTE SERVER"))
                {
                    dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "30";
                    resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
                }
                else
                {
                    UtilityCredentials creds2 = dp.GetUtilityCreds("UMEME", trans.VendorCode);
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                    EPayment umemeapi2 = new EPayment();
                    UtilityReferences.UMEME.Response umemeResp2 = umemeapi2.GetTransactionDetails(trans.VendorTransactionRef, creds2.UtilityCode, creds2.UtilityPassword);
                    if (umemeResp2.StatusCode.Equals("0"))
                    {
                        if (trans.CustomerType.ToUpper().Equals("PREPAID"))
                        {
                            dp.UpdateSentTransaction(resp.PegPayPostId, umemeResp2.Token, "SUCCESS");
                            resp.ReceiptNumber = umemeResp2.Token;
                        }
                        else
                        {
                            dp.UpdateSentTransaction(resp.PegPayPostId, umemeResp2.ReceiptNumber, "SUCCESS");
                            resp.ReceiptNumber = resp.PegPayPostId;
                        }

                    }
                    else
                    {

                        dp.UpdateSentTransaction(resp.PegPayPostId, umemeResp2.ReceiptNumber, "SUCCESS");
                        resp.ReceiptNumber = resp.PegPayPostId;
                    }
                    resp.StatusCode = "0";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    dp.LogError(wex.Message + " - " + trans.VendorTransactionRef, trans.VendorCode, DateTime.Now, "UMEME");
                }
            }
            else
            {
                resp.ReceiptNumber = resp.PegPayPostId;
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "UMEME");
        }
        catch (SqlException sqlex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "UMEME");
        }
        //DateTime timeOut = DateTime.Now;
        //CSVFile.WriteToLogFile(timeIn, timeOut, trans);
        return resp;
    }

    [WebMethod]
    public Token MakeYakaPayment(UmemeTransaction trans)
    {
        Token resp = new Token();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "UMEME", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidPayCode(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "27";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidCustType(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "28";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                            if (!(vendorType.Equals("PREPAID")))
                                                            {
                                                                UtilityCredentials creds = dp.GetUtilityCreds("UMEME", trans.VendorCode);
                                                                if (!creds.UtilityCode.Equals(""))
                                                                {

                                                                    if (trans.CustomerType.ToUpper().Equals("PREPAID"))
                                                                    {
                                                                        resp.PegPayPostId = dp.InsertIntoReceivedTransactions(trans, "UMEME");
                                                                        System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                                                                        EPayment umemeapi = new EPayment();
                                                                        UtilityReferences.UMEME.Transaction umemeTrans = GetUmemeTrans(trans, creds);
                                                                        UtilityReferences.UMEME.Token token = umemeapi.PostYakaPayment(umemeTrans);
                                                                        if (token.StatusCode.Equals("0"))
                                                                        {
                                                                            resp = GetToken(token, resp.PegPayPostId);
                                                                            dp.UpdateSentTransaction(resp.PegPayPostId, token.PrepaidToken, "SUCCESS");
                                                                            resp.ReceiptNumber = token.ReceiptNumber;
                                                                            resp.StatusCode = "0";
                                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                        }
                                                                        else
                                                                        {
                                                                            dp.deleteTransaction(resp.PegPayPostId, token.StatusDescription + " AT UMEME");
                                                                            resp.ReceiptNumber = "";
                                                                            resp.PegPayPostId = "";
                                                                            resp.StatusCode = "100";
                                                                            resp.StatusDescription = token.StatusDescription + " AT UMEME";
                                                                        }

                                                                    }
                                                                    else
                                                                    {
                                                                        resp.ReceiptNumber = resp.PegPayPostId;
                                                                        resp.StatusCode = "0";
                                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    resp.ReceiptNumber = "";
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (wex.Message.ToUpper().Contains("UNABLE TO CONNECT TO REMOTE SERVER"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
                dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "UMEME");
            }
            else
            {
                resp.ReceiptNumber = resp.PegPayPostId;
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                dp.UpdateSentTransaction(resp.PegPayPostId, "", "PENDING");
                dp.LogError(wex.Message + " - " + trans.VendorTransactionRef, trans.VendorCode, DateTime.Now, "UMEME");

            }
        }
        catch (SqlException sqlex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "UMEME");
        }
        return resp;
    }

    public bool VendorHasBlackListedAccounts(string vendorCode)
    {
        DatabaseHandler dataAccessor = new DatabaseHandler();
        DataTable table = dataAccessor.CheckIfVendorHasBlacklistedAccounts(vendorCode);
        foreach (DataRow row in table.Rows)
        {
            if (row["Blacklisted"].ToString().Equals("1"))
            {
                return true;
            }
            break;
        }
        return false;
    }

    private UmemePostResponse DoOrangeMoneyUMEMETransaction(UmemeTransaction trans)
    {
        DatabaseHandler dp = new DatabaseHandler();
        UmemePostResponse umemeResponse = new UmemePostResponse();

        //meter Number = is in blacklisted accounts Table
        if (AccountIsBlackListed(trans))
        {
            //cash > amount due
            if (AmountIsGreaterThanDebt(trans))
            {
                string[] deductionDetails = DeductFromDebt(ref trans);
                LogAmountPaidByCustomer(trans, deductionDetails[0], deductionDetails[1]);

                //insert it into recieved transactions at this point because incase UMEME is down
                //the posting will fail. Later when its back we should send only the amount
                //that was left after deducting oranges debt
                umemeResponse.PegPayPostId = dp.InsertIntoReceivedTransactions(trans, "UMEME");
                umemeResponse.ReceiptNumber = "";
                umemeResponse.StatusCode = "0";
                umemeResponse.StatusDescription = dp.GetStatusDescr(umemeResponse.PegPayPostId);
                NotifyOrangeToCallCustomer(trans, deductionDetails[1]);
            }
            //cash == amount due
            else if (AmountIsEqualToDebt(trans))
            {
                string[] deductionDetails = DeductFromDebt(ref trans);
                string PegPayId = LogAmountPaidByCustomer(trans, deductionDetails[0], deductionDetails[1]);
                umemeResponse.ReceiptNumber = "";
                umemeResponse.PegPayPostId = PegPayId;
                umemeResponse.StatusCode = "0"; //still not sure what error code to use here...
                umemeResponse.StatusDescription = "Your Outstanding Balance Has Been Cleared.";

                NotifyOrangeToCallCustomer(trans, deductionDetails[1]);
            }
            //cash < amount due
            else
            {
                string[] deductionDetails = DeductFromDebt(ref trans);
                string PegPayId = LogAmountPaidByCustomer(trans, deductionDetails[0], deductionDetails[1]);
                umemeResponse.ReceiptNumber = "";
                umemeResponse.PegPayPostId = PegPayId;
                umemeResponse.StatusCode = "0"; //still not sure what error code to use here...
                umemeResponse.StatusDescription = "Your Account Is In Debt Recovery Mode. Current Debt = " + deductionDetails[2] + ". Call 100 for more info.";

                NotifyOrangeToCallCustomer(trans, deductionDetails[1]);
            }
        }
        //customer is not blacklisted
        else
        {
            //insert it into recieved transactions at this point because incase UMEME is down
            //the posting will fail. Later on... when its back we should send only the amount
            //that was left after deducting oranges debt
            umemeResponse.PegPayPostId = dp.InsertIntoReceivedTransactions(trans, "UMEME");
            umemeResponse.ReceiptNumber = "";
            umemeResponse.StatusCode = "0";
            umemeResponse.StatusDescription = dp.GetStatusDescr(umemeResponse.StatusCode);
        }

        return umemeResponse;
    }

    private bool AmountIsEqualToDebt(UmemeTransaction trans)
    {
        string meterNumber = trans.CustRef;
        int transactionAmount = Convert.ToInt32(trans.TransactionAmount);
        DatabaseHandler dataAccessor = new DatabaseHandler();
        DataTable dataTable = dataAccessor.GetBlacklistedAccountsDebt(meterNumber);

        //this should loop once
        foreach (DataRow row in dataTable.Rows)
        {
            int debtAmount = Convert.ToInt32(row["Debt"].ToString());

            //and if the cash == amount due
            if (transactionAmount == debtAmount)
            {
                return true;
            }

            break;
        }
        return false;
    }


    private string[] DeductFromDebt(ref UmemeTransaction trans)
    {
        string meterNumber = trans.CustRef;
        int transactionAmount = Convert.ToInt32(trans.TransactionAmount);
        string amountPaid = trans.TransactionAmount;
        string amountTaken = "0";
        DatabaseHandler dataAccessor = new DatabaseHandler();
        DataTable dataTable = dataAccessor.GetBlacklistedAccountsDebt(meterNumber);
        int debtAmount = 0;
        //This for loop will loop once
        foreach (DataRow row in dataTable.Rows)
        {
            //e.g cash > debt
            //user pays 20,000
            //debt is 10,000
            //difference=debt-tranAmount;
            //difference=10,000-20,000;
            //difference=-10,000
            //we set debt=0 and transactionAmount to 10,000 
            //however if
            // cash <= debt
            //debt = 10,000
            //user pays 5000
            //difference=debt-tranAmount;
            //difference=10,000-5,000
            //difference=5000;
            //we set debt=5000;
            //we set transactionAmount=0;

            debtAmount = Convert.ToInt32(row["Debt"].ToString());
            if (debtAmount > 0)
            {

                int difference;
                difference = debtAmount - transactionAmount;

                //he has paid more
                if (difference < 0)
                {
                    amountTaken = "" + debtAmount;
                    trans.TransactionAmount = "" + (transactionAmount - debtAmount);
                    debtAmount = 0;
                }
                //he has paid less
                else
                {
                    amountTaken = trans.TransactionAmount;
                    debtAmount = difference;
                    trans.TransactionAmount = "0";
                }
                dataAccessor.UpdateBlacklistedAccountDebt(meterNumber, debtAmount);

            }
            break;
        }
        return new string[] { amountPaid, amountTaken, "" + debtAmount };
    }


    private string LogAmountPaidByCustomer(UmemeTransaction trans, string AmountPaid, string AmountTaken)
    {
        DatabaseHandler databaseHandler = new DatabaseHandler();
        string id = databaseHandler.InsertIntoBlackListedAccountLogs(trans, AmountPaid, AmountTaken);
        return id;
    }


    private void NotifyOrangeToCallCustomer(UmemeTransaction trans, string amountTaken)
    {
        if (Convert.ToInt32(amountTaken) > 0)
        {
            Email orangeEmails = new Email(trans, amountTaken);
            orangeEmails.StartSendingEmails();
        }
    }

    private bool AmountIsGreaterThanDebt(UmemeTransaction trans)
    {

        string meterNumber = trans.CustRef;
        int transactionAmount = Convert.ToInt32(trans.TransactionAmount);
        DatabaseHandler dataAccessor = new DatabaseHandler();
        DataTable dataTable = dataAccessor.GetBlacklistedAccountsDebt(meterNumber);

        //this should loop once
        foreach (DataRow row in dataTable.Rows)
        {
            int debtAmount = Convert.ToInt32(row["Debt"].ToString());

            //and if the cash > amount due
            if (transactionAmount > debtAmount)
            {
                return true;
            }

            break;
        }
        return false;
    }

    private bool AccountIsBlackListed(UmemeTransaction trans)
    {
        //for an account to be blacklisted
        //it be in the blacklitsed umeme accounts table
        //and must have a debt > 0
        string meterNumber = trans.CustRef;
        DatabaseHandler dataAccessor = new DatabaseHandler();
        DataTable dataTable = dataAccessor.CheckIfMeterNumberIsBlacklisted(meterNumber);

        //if any data is recieved 
        if (dataTable.Rows.Count > 0)
        {
            //and the customer actually has a debt to pay off then return true
            if (DebtIsGreaterThanZero(dataTable))
            {
                return true;
            }
        }
        return false;
    }

    public bool DebtIsGreaterThanZero(DataTable table)
    {
        //this should loop once
        foreach (DataRow row in table.Rows)
        {
            string debt = row["Debt"].ToString();
            if (Convert.ToInt32(debt) > 0)
            {
                return true;
            }
            break;
        }
        return false;
    }
    [WebMethod]
    public AirtimeResponseObj MakeAirtimePayment(Transaction trans)
    {
        AirtimeResponseObj resp = new AirtimeResponseObj();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "NWSC", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Area == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "35";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Area.Trim().Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "35";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.ResponseId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.ResponseId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.ResponseId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.ResponseId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {

                                                            string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                            if (!(vendorType.Equals("PREPAID")))
                                                            {
                                                                UtilityCredentials creds = dp.GetUtilityCreds("NWSC", trans.VendorCode);
                                                                if (!creds.UtilityCode.Equals(""))
                                                                {
                                                                    if (string.IsNullOrEmpty(trans.CustomerType))
                                                                    {
                                                                        trans.CustomerType = "";
                                                                    }
                                                                    resp.ResponseId = dp.PostTransactionObject(trans, "NWSC");
                                                                    resp.StatusCode = "0";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                                else
                                                                {
                                                                    resp.ResponseId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.ResponseId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ResponseId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ResponseId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ResponseId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.ResponseId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.ResponseId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.ResponseId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }//Uncomment me including the else below
                                else
                                {
                                    resp.ResponseId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.ResponseId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ResponseId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ResponseId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ResponseId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            //dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO NWSC");
            //resp.PegPayPostId = "";
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "NWSC");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.ResponseId, resp.StatusDescription);
            resp.ResponseId = "";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.ResponseId, resp.StatusDescription);
            resp.ResponseId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "NWSC");
        }
        return resp;
    }


    [WebMethod]
    public PostResponse MakeStartTimesPayment(Transaction trans)
    {
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        List<string> payCategories = new List<string>();
        payCategories.Add("RECHARGE");//RECHAR
        payCategories.Add("PAYMENT");
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "STARTIMES", "POSTING", trans.CustRef, trans.Password);
            if (string.IsNullOrEmpty(trans.CustName))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.Area.Trim()))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "35";
                resp.StatusDescription = "PLEASE PROVIDE BOUQUET";
            }
            else if (string.IsNullOrEmpty(trans.TransactionType))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.VendorTransactionRef))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.Teller))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.DigitalSignature))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.Tin))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "39";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!payCategories.Contains(trans.Tin.ToUpper()))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "111";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount) || trans.Tin.Equals("RECHARGE"))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                //assuming recharges are never reversed
                                                trans.Reversal = trans.Tin.Equals("RECHARGE") ? "0" : GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {

                                                            string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                            if (!(vendorType.Equals("PREPAID")))
                                                            {
                                                                UtilityCredentials creds = dp.GetUtilityCreds("STARTIMES", trans.VendorCode);
                                                                if (!creds.UtilityCode.Equals(""))
                                                                {
                                                                    if (string.IsNullOrEmpty(trans.CustomerType))
                                                                    {
                                                                        trans.CustomerType = "";
                                                                    }
                                                                    
                                                                    resp.PegPayPostId = dp.PostPayTvTransaction(trans, "STARTIMES");
                                                                    resp.StatusCode = "0";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                                else
                                                                {
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }//Uncomment me including the else below
                                else
                                {
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            //dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO STARTIMES");
            //resp.PegPayPostId = "";
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "STARTIMES");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "STARTIMES");
        }
        return resp;
    }


    [WebMethod]
    public PostResponse MakeNWSCPayment(NWSCTransaction trans)
    {
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "NWSC", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Area == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "35";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Area.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "35";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {

                                                            string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                                                            if (!(vendorType.Equals("PREPAID")))
                                                            {
                                                                UtilityCredentials creds = dp.GetUtilityCreds("NWSC", trans.VendorCode);
                                                                if (!creds.UtilityCode.Equals(""))
                                                                {
                                                                    if (string.IsNullOrEmpty(trans.CustomerType))
                                                                    {
                                                                        trans.CustomerType = "";
                                                                    }
                                                                    resp.PegPayPostId = dp.PostTransaction(trans, "NWSC");
                                                                    resp.StatusCode = "0";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);

                                                                    //SMS sms = new SMS();
                                                                    //sms.Phone = trans.CustomerTel;
                                                                    //sms.Message = "Dear " + trans.CustName + ", " +
                                                                    //              "payment of " + trans.TransactionAmount + " for a/c " + trans.CustRef + " recieved by NWSC. Your account will be credited within 24 hours. Thank you for paying.";
                                                                    //sms.Reference = trans.VendorTransactionRef;
                                                                    //sms.Sender = "GENERIC API";
                                                                    //sms.VendorTranId = trans.VendorTransactionRef;
                                                                    //sms.Mask = "NWSC";
                                                                    //bll.SendToSmsMSQ(sms);
                                                                    //System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                                                                    //NWSCBillingInterface nwscapi = new NWSCBillingInterface();
                                                                    //string format = "dd/MM/yyyy";
                                                                    //DateTime payDate = DateTime.ParseExact(trans.PaymentDate, format, CultureInfo.InvariantCulture);
                                                                    //UtilityReferences.NWSC.PostResponse waterResp = nwscapi.postCustomerTransactionsWithArea(trans.CustRef, trans.CustName, trans.Area, trans.CustomerTel, payDate, int.Parse(trans.TransactionAmount), trans.VendorTransactionRef, trans.TransactionType, creds.UtilityCode, creds.UtilityPassword);
                                                                    //if (waterResp.PostError.Equals("NONE"))
                                                                    //{
                                                                    //    dp.UpdateSentTransaction(resp.PegPayPostId, "", "1");
                                                                    //    resp.StatusCode = "0";
                                                                    //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                    //}
                                                                    //else
                                                                    //{
                                                                    //    dp.deleteTransaction(resp.PegPayPostId, waterResp.PostError);
                                                                    //    resp.PegPayPostId = "";
                                                                    //    resp.StatusCode = "100";
                                                                    //    resp.StatusDescription = waterResp.PostError + " AT NWSC";
                                                                    //}
                                                                }
                                                                else
                                                                {
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "29";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = "NOT ENABLED FOR PREPAID VENDORS";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }//Uncomment me including the else below
                                else
                                {
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            //dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO NWSC");
            //resp.PegPayPostId = "";
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "NWSC");
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "NWSC");
        }
        return resp;
    }

    //[WebMethod]
    //public KCCAPostResponse MakeKCCAPayment(KCCATransaction trans)
    //{
    //    KCCAPostResponse resp = new KCCAPostResponse();
    //    System.Collections.ArrayList a = new System.Collections.ArrayList();
    //    a.Add("2150000000015");
    //    a.Add("2140000000163");
    //    a.Add("2140000000164");
    //    a.Add("2140000000165");
    //    if (a.Contains(trans.CustRef))
    //    {
    //        Random rnd = new Random();
    //        int receiptNumber = rnd.Next(100000, 1000000);
    //        resp.StatusCode = "0";
    //        resp.StatusDescription = "SUCESS";
    //        resp.VendorTransactionRef = receiptNumber.ToString();
    //    }
    //    else
    //    {
    //        resp.StatusCode = "1";
    //        resp.StatusDescription = "INVALID CUSTOMER REFERENCE";
    //        resp.VendorTransactionRef = "";
    //    }
    //    return resp;
    //}

    [WebMethod]
    public KCCAPostResponse MakeKCCAPayment(KCCATransaction trans)
    {
        KCCAPostResponse resp = new KCCAPostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //log incoming Details
        //dp.logKCCAPostHit(trans);
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "KCCA", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (trans.CustName.Trim().Equals(""))
            //{
            //    DatabaseHandler dh = new DatabaseHandler();
            //    if (trans.VendorCode.ToUpper().Contains("MTN"))
            //    {
            //        Customer cust = dh.GetCustomerDetails(trans.CustRef, "", "KCCA");
            //        if (cust.StatusCode.Equals("0"))
            //        {
            //            trans.CustName = cust.CustomerName;
            //        }
            //        else
            //        {
            //            resp.PegPayPostId = "";
            //            resp.StatusCode = "13";
            //            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //        }
            //    }
            //    else
            //    {
            //        resp.PegPayPostId = "";
            //        resp.StatusCode = "13";
            //        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //    }
            //}
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (!IsValidCustType(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "28";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds("KCCA", trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                //post in pegpay
                                                                if (trans.PaymentType == null)
                                                                {
                                                                    trans.PaymentType = "";
                                                                }
                                                                if (trans.CustomerType == null)
                                                                {
                                                                    trans.CustomerType = "";

                                                                }
                                                                DatabaseHandler dh = new DatabaseHandler();
                                                                Customer cust = dh.GetCustomerDetails(trans.CustRef, "", "KCCA");
                                                                if (cust.StatusCode.Equals("0"))
                                                                {
                                                                    if (trans.CustName.Equals(""))
                                                                    {
                                                                        trans.CustName = cust.CustomerName;
                                                                    }
                                                                    double balance = Convert.ToDouble(cust.Balance.Trim());
                                                                    double amt = Convert.ToDouble(trans.TransactionAmount.Trim());
                                                                    if (amt == balance)
                                                                    {
                                                                        resp.PegPayPostId = dp.PostUmemeTransaction(trans, "KCCA");
                                                                        resp.ReceiptNumber = resp.PegPayPostId;
                                                                        resp.StatusCode = "0";
                                                                        resp.StatusDescription = "SUCCESS";
                                                                    }
                                                                    else
                                                                    {
                                                                        resp.ReceiptNumber = "";
                                                                        resp.PegPayPostId = "";
                                                                        resp.StatusCode = "38";
                                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    resp.ReceiptNumber = "";
                                                                    resp.PegPayPostId = "";
                                                                    resp.StatusCode = "38";
                                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                }

                                                                // do posting to kcca

                                                                //KCCAQueryResponse kccaResp = bll.MakeKccaPayment(trans);


                                                                //if (kccaResp.Success.Equals("1"))
                                                                //{
                                                                //    dp.UpdateSentTransaction(resp.PegPayPostId, kccaResp.PaymentReference, "SUCCESS");
                                                                //    resp.ReceiptNumber = kccaResp.PaymentReference;
                                                                //    resp.StatusCode = "0";
                                                                //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                //}
                                                                //else
                                                                //{
                                                                //    if (kccaResp.ErrorCode.Equals("2111"))
                                                                //    {
                                                                //        dp.UpdateSentTransaction(resp.PegPayPostId, kccaResp.PaymentReference, "SUCCESS");
                                                                //        resp.ReceiptNumber = kccaResp.PaymentReference;
                                                                //        resp.StatusCode = "0";
                                                                //        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                //    }
                                                                //    else
                                                                //    {
                                                                //        dp.deleteTransaction(resp.PegPayPostId, kccaResp.ErrorDescription + " AT KCCA");
                                                                //        resp.ReceiptNumber = "";
                                                                //        resp.PegPayPostId = "";
                                                                //        resp.StatusCode = "100";
                                                                //        resp.StatusDescription = kccaResp.ErrorDescription + " AT KCCA";
                                                                //    }
                                                                //}
                                                            }
                                                            else
                                                            {
                                                                resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        catch (SqlException sqlex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "KCCA");

        }
        catch (Exception ex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }
    [WebMethod]
    public KCCAResponse MakeTuckSeePayment(KCCATransaction trans)
    {
        KCCAResponse resp = new KCCAResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //log incoming Details
        //dp.logKCCAPostHit(trans);
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "TUCKSEE", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "13";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }

            else if (trans.TransactionType == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "14";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.TransactionID = "";
                resp.ErrorCode = "14";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }

            else if (trans.VendorTransactionRef == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "16";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.TransactionID = "";
                resp.ErrorCode = "16";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.Teller == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "17";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.TransactionID = "";
                resp.ErrorCode = "17";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "19";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "19";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.TransactionID = "";
                resp.ErrorCode = "25";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "22";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.TransactionID = "";
                resp.ErrorCode = "22";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.TransactionID = "";
                resp.ErrorCode = "23";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.TransactionID = "";
                resp.ErrorCode = "23";
                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            }
            //else if (!IsValidCustType(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "28";
            //    resp.ErrorDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds("TUCKSEE", trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                //post in pegpay
                                                                if (trans.PaymentType == null)
                                                                {
                                                                    trans.PaymentType = "";
                                                                }
                                                                if (trans.CustomerType == null)
                                                                {
                                                                    trans.CustomerType = "";

                                                                }
                                                                DatabaseHandler dh = new DatabaseHandler();

                                                                resp.TransactionID = dp.PostUmemeTransaction(trans, "TUCKSEE");
                                                                resp.ErrorCode = "0";
                                                                resp.ErrorDescription = "SUCCESS";


                                                            }
                                                            else
                                                            {
                                                                //resp.ReceiptNumber = "";
                                                                resp.TransactionID = "";
                                                                resp.ErrorCode = "29";
                                                                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            //resp.ReceiptNumber = "";
                                                            resp.TransactionID = "";
                                                            resp.ErrorCode = "29";
                                                            resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        //     resp.ReceiptNumber = "";
                                                        resp.TransactionID = "";
                                                        resp.ErrorCode = "26";
                                                        resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                                    }
                                                }
                                                else
                                                {
                                                    //      resp.ReceiptNumber = "";
                                                    resp.TransactionID = "";
                                                    resp.ErrorCode = "24";
                                                    resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                                }

                                            }
                                            else
                                            {
                                                //    resp.ReceiptNumber = "";
                                                resp.TransactionID = "";
                                                resp.ErrorCode = "21";
                                                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                            }
                                        }
                                        else
                                        {
                                            //  resp.ReceiptNumber = "";
                                            resp.TransactionID = "";
                                            resp.ErrorCode = "20";
                                            resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                        }
                                    }
                                    else
                                    {
                                        //resp.ReceiptNumber = "";
                                        resp.TransactionID = "";
                                        resp.ErrorCode = "12";
                                        resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                    }
                                }
                                else
                                {
                                    /// resp.ReceiptNumber = "";
                                    resp.TransactionID = "";
                                    resp.ErrorCode = "18";
                                    resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                                }
                            }
                            else
                            {
                                //resp.ReceiptNumber = "";
                                resp.TransactionID = "";
                                resp.ErrorCode = "11";
                                resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                            }
                        }
                        else
                        {
                            //   resp.ReceiptNumber = "";
                            resp.TransactionID = "";
                            resp.ErrorCode = "2";
                            resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                        }
                    }
                    else
                    {
                        // resp.ReceiptNumber = "";
                        resp.TransactionID = "";
                        resp.ErrorCode = "4";
                        resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                    }
                }
                else
                {
                    //resp.ReceiptNumber = "";
                    resp.TransactionID = "";
                    resp.ErrorCode = "3";
                    resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
                }
            }
            if (resp.ErrorCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.TransactionID, "UNABLE TO CONNECT TO UMEME");
                ///resp.ReceiptNumber = "";
                resp.TransactionID = "";
                resp.ErrorCode = "30";
                resp.ErrorDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.ErrorCode = "0";
                resp.ErrorDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        catch (SqlException sqlex)
        {
            //resp.ReceiptNumber = "";
            resp.ErrorCode = "31";
            resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            dp.deleteTransaction(resp.TransactionID, resp.ErrorDescription);
            resp.TransactionID = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "KCCA");

        }
        catch (Exception ex)
        {
            //resp.ReceiptNumber = "";
            resp.ErrorCode = "32";
            resp.ErrorDescription = dp.GetStatusDescr(resp.ErrorCode);
            dp.deleteTransaction(resp.TransactionID, resp.ErrorDescription);
            resp.TransactionID = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }

    [WebMethod]
    public PostResponse PostGenericTransaction(Transaction trans)
    {
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //log incoming Details
        //dp.logKCCAPostHit(trans);
        try
        {
            if (string.IsNullOrEmpty(trans.UtilityCode))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "133";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                return resp;
            }
            dp.SaveRequestlog(trans.VendorCode, trans.UtilityCode, "POSTING", trans.CustRef, trans.Password);

            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (string.IsNullOrEmpty(trans.TransactionType))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

            else if (string.IsNullOrEmpty(trans.VendorTransactionRef))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.Teller))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (string.IsNullOrEmpty(trans.DigitalSignature))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (!IsValidCustType(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "28";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds(trans.UtilityCode, trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                //post in pegpay
                                                                if (trans.PaymentType == null)
                                                                {
                                                                    trans.PaymentType = "";
                                                                }
                                                                if (trans.CustomerType == null)
                                                                {
                                                                    trans.CustomerType = "";

                                                                }
                                                                DatabaseHandler dh = new DatabaseHandler();

                                                                resp.PegPayPostId = dp.PostUmemeTransaction(trans, trans.UtilityCode);
                                                                resp.StatusCode = "0";
                                                                resp.StatusDescription = "SUCCESS";


                                                            }
                                                            else
                                                            {
                                                                //resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            //resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        //     resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    //      resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                //    resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            //  resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        //resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    /// resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                //resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            //   resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        // resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    //resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                ///resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, trans.UtilityCode);
        }
        catch (SqlException sqlex)
        {
            //resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "KCCA");

        }
        catch (Exception ex)
        {
            //resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }

    [WebMethod]
    public TransactionResponse MakeSolarPayment(Transaction trans)
    {
        TransactionResponse resp = new TransactionResponse();
        try
        {
            string transtatus = ValidateTransactions.ValidateTransactionObject(trans);
            if (transtatus == "OK")
            {
                SolarHandler shandler = new SolarHandler();
                resp = shandler.PostSolarPayment(trans);
                if (resp.ErrorCode == "0")
                {
                    resp.ErrorDescription = "SUCCESS";
                }
            }
            else
            {
                resp.ErrorCode = "100";
                resp.ErrorDescription = transtatus;
            }
        }
        catch (TimeoutException ee)
        {
            resp.ErrorCode = "101";
            resp.ErrorDescription = "Transaction Timeout";
            // get transactio id
        }
        catch (Exception ee)
        {
            resp.ErrorCode = "100";
            resp.ErrorDescription = "" + ee.Message;
        }
        return resp;
    }

    [WebMethod]
    public KCCAPostResponse NewMakeKCCAPayment(KCCATransaction trans)
    {
        KCCAPostResponse resp = new KCCAPostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;
        //log incoming Details
        //dp.logKCCAPostHit(trans);
        try
        {
            dp.SaveRequestlog(trans.VendorCode, "MAK", "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (trans.CustName.Trim().Equals(""))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "13";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (trans.PaymentType.Trim().Equals(""))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "15";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (!IsValidPayCode(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "27";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            //else if (!IsValidCustType(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "28";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                if (isSignatureValid(trans))
                                {
                                    if (pv.PhoneNumbersOk(trans.CustomerTel))
                                    {
                                        if (!IsduplicateVendorRef(trans))
                                        {
                                            if (!IsduplicateCustPayment(trans))
                                            {
                                                trans.Reversal = GetReversalState(trans);
                                                if (HasOriginalEntry(trans))
                                                {
                                                    if (ReverseAmountsMatch(trans))
                                                    {
                                                        if (!IsChequeBlacklisted(trans))
                                                        {
                                                            UtilityCredentials creds = dp.GetUtilityCreds("KCCA", trans.VendorCode);
                                                            if (!creds.UtilityCode.Equals(""))
                                                            {
                                                                resp.PegPayPostId = dp.PostUmemeTransaction(trans, "KCCA");
                                                                resp.ReceiptNumber = resp.PegPayPostId;
                                                                resp.StatusCode = "0";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                //System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidation;
                                                                //UtilityReferences.KCCA.EPayment kccaapi = new UtilityReferences.KCCA.EPayment();
                                                                //UtilityReferences.KCCA.Transaction kccaTrans = GetKCCATrans(trans, creds);
                                                                //UtilityReferences.KCCA.Response kccaResp = kccaapi.PostKccaPayment(kccaTrans);

                                                                //    if (!resp.PegPayPostId.Equals("0"))
                                                                //    {
                                                                //        //dp.UpdateSentTransaction(resp.PegPayPostId, kccaResp.ReceiptNumber);
                                                                //        resp.ReceiptNumber = resp.PegPayPostId;
                                                                //        resp.StatusCode = "0";
                                                                //        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                                //    }
                                                                //    else
                                                                //    {
                                                                //        //dp.deleteTransaction(resp.PegPayPostId, kccaResp.StatusDescription + " AT KCCA");
                                                                //        resp.ReceiptNumber = "";
                                                                //        resp.PegPayPostId = "";
                                                                //        resp.StatusCode = "32";
                                                                //        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode); //kccaResp.StatusDescription + " AT KCCA";
                                                                //    }
                                                            }
                                                            else
                                                            {
                                                                resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "29";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "26";
                                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "24";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }

                                            }
                                            else
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "21";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }
                                        }
                                        else
                                        {
                                            resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "20";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "12";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "18";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            else
                            {
                                resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        catch (SqlException sqlex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "KCCA");

        }
        catch (Exception ex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }

    [WebMethod]
    public SchoolsPostResponse MakeSchoolFeesPayment(schoolsTransaction trans)
    {
        SchoolsPostResponse resp = new SchoolsPostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        string vendorCode = trans.VendorCode;

        try
        {
            dp.SaveRequestlog(trans.VendorCode, trans.UtilityCode, "POSTING", trans.CustRef, trans.Password);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "13";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "14";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.PaymentType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "15";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "16";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "17";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.UtilityCode == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "36";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.UtilityCode.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "36";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "19";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (!IsValidReversalStatus(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "25";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.TranIdToReverse.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "22";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else if (trans.Reversal == "1" && trans.Narration.Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "23";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            //else if (!IsValidPayCode(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "27";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            //else if (!IsValidCustType(trans))
            //{
            //    resp.PegPayPostId = "";
            //    resp.StatusCode = "28";
            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            //}
            else
            {
                if (bll.IsNumeric(trans.TransactionAmount))
                {
                    if (bll.IsValidDate(trans.PaymentDate))
                    {
                        DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                        if (isValidVendorCredentials2(trans.VendorCode, trans.Password, vendaData))
                        {
                            if (isActiveVendor(trans.VendorCode, vendaData))
                            {
                                //if (isSignatureValid(trans))
                                //{
                                if (pv.PhoneNumbersOk(trans.CustomerTel))
                                {
                                    if (!IsduplicateVendorRef(trans))
                                    {
                                        if (!IsduplicateCustPayment(trans))
                                        {
                                            trans.Reversal = GetReversalState(trans);
                                            if (HasOriginalEntry(trans))
                                            {
                                                if (ReverseAmountsMatch(trans))
                                                {
                                                    if (!IsChequeBlacklisted(trans))
                                                    {
                                                        UtilityCredentials creds = dp.GetUtilityCreds(trans.UtilityCode, trans.VendorCode);
                                                        if (!creds.UtilityCode.Equals(""))
                                                        {
                                                            resp.PegPayPostId = dp.PostSchoolTransaction(trans, trans.UtilityCode);
                                                            if (bll.IsNumeric(resp.PegPayPostId))
                                                            {


                                                                //dp.UpdateSentTransaction(resp.PegPayPostId, resp.PegPayPostId, "SUCCESS");
                                                                resp.ReceiptNumber = resp.PegPayPostId;
                                                                resp.StatusCode = "0";
                                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                            }
                                                            else
                                                            {
                                                                dp.deleteTransaction(resp.PegPayPostId, "ERROR SAVING TRANSACTION AT PEGPAY");
                                                                resp.ReceiptNumber = "";
                                                                resp.PegPayPostId = "";
                                                                resp.StatusCode = "100";
                                                                resp.StatusDescription = "ERROR POSTING TRANSACTION AT PEGPAY";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            resp.ReceiptNumber = "";
                                                            resp.PegPayPostId = "";
                                                            resp.StatusCode = "29";
                                                            resp.StatusDescription = "ERROR FROM HERE 1"; //dp.GetStatusDescr(resp.StatusCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        resp.ReceiptNumber = "";
                                                        resp.PegPayPostId = "";
                                                        resp.StatusCode = "29";
                                                        resp.StatusDescription = "ERROR FROM HERE 2";// dp.GetStatusDescr(resp.StatusCode);
                                                    }
                                                }
                                                else
                                                {
                                                    resp.ReceiptNumber = "";
                                                    resp.PegPayPostId = "";
                                                    resp.StatusCode = "26";
                                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                                }
                                            }
                                            else
                                            {
                                                resp.ReceiptNumber = "";
                                                resp.PegPayPostId = "";
                                                resp.StatusCode = "24";
                                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                            }

                                        }
                                        else
                                        {
                                            resp.ReceiptNumber = "";
                                            resp.PegPayPostId = "";
                                            resp.StatusCode = "21";
                                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                        }
                                    }
                                    else
                                    {
                                        resp.ReceiptNumber = "";
                                        resp.PegPayPostId = "";
                                        resp.StatusCode = "20";
                                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    }
                                }
                                else
                                {
                                    resp.ReceiptNumber = "";
                                    resp.PegPayPostId = "";
                                    resp.StatusCode = "12";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                            }
                            //else
                            //{
                            //    resp.ReceiptNumber = "";
                            //    resp.PegPayPostId = "";
                            //    resp.StatusCode = "18";
                            //    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            //}
                            // }
                            else
                            {
                                resp.ReceiptNumber = "";
                                resp.PegPayPostId = "";
                                resp.StatusCode = "11";
                                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            }
                        }
                        else
                        {
                            resp.ReceiptNumber = "";
                            resp.PegPayPostId = "";
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        }
                    }
                    else
                    {
                        resp.ReceiptNumber = "";
                        resp.PegPayPostId = "";
                        resp.StatusCode = "4";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                }
                else
                {
                    resp.ReceiptNumber = "";
                    resp.PegPayPostId = "";
                    resp.StatusCode = "3";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            if (resp.StatusCode.Equals("2"))
            {
                DataTable dt = dp.GetVendorDetails(vendorCode);
                if (dt.Rows.Count != 0)
                {
                    string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                    string strLoginCount = dt.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }
                }
            }
        }
        catch (System.Net.WebException wex)
        {
            if (trans.CustomerType.ToUpper().Equals("PREPAID"))
            {
                dp.deleteTransaction(resp.PegPayPostId, "UNABLE TO CONNECT TO UMEME");
                resp.ReceiptNumber = "";
                resp.PegPayPostId = "";
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO UMEME";
            }
            else
            {
                resp.StatusCode = "0";
                resp.StatusDescription = "SUCCESS";
            }
            dp.LogError(wex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        catch (SqlException sqlex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(sqlex.Message, trans.VendorCode, DateTime.Now, "KCCA");

        }
        catch (Exception ex)
        {
            resp.ReceiptNumber = "";
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "KCCA");
        }
        return resp;
    }




    private SchoolsPostResponse MakeUMUSchoolFeesPayment(schoolsTransaction trans)
    {
        SchoolsPostResponse resp = new SchoolsPostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {

            creds = dp.GetUtilityCreds(trans.UtilityCode, trans.VendorCode);
            if (!creds.UtilityCode.Equals(""))
            {
                //code to post transaction 
                System.Net.ServicePointManager.Expect100Continue = false;
                string myUrl2 = "http://eis.umu.ac.ug:84/test/ebank?";
                string urlParams2 = "act = POST & cur = UGX & acc = " + trans.Teller + "& dt =" + trans.PaymentDate + "& stno =" + trans.CustRef + "& chqno =" + trans.ChequeNumber + " &dr =" + trans.Reversal + " &cr =" + trans.PaymentType + " & bank =" + creds.BankCode + " & username =" + creds.Utility + "& password =" + creds.UtilityPassword + "& phone =" + trans.Telephone + " & yrofstudy =" + "" + "& sem =" + "" + "& bankRef =" + trans.VendorTransactionRef + " & naration =" + trans.Narration;
                myUrl2 = myUrl2 + urlParams2;
                HttpWebRequest r2 = (HttpWebRequest)System.Net.WebRequest.Create(myUrl2);
                r2.Headers.Clear();
                r2.AllowAutoRedirect = true;
                r2.PreAuthenticate = true;
                r2.ContentType = "application / x - www - form - urlencoded";
                r2.Credentials = CredentialCache.DefaultCredentials;
                r2.UserAgent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
                r2.Timeout = 150000;
                Encoding byteArray2 = Encoding.GetEncoding("utf-8");
                Stream dataStream2;
                WebResponse response2 = (HttpWebResponse)r2.GetResponse();
                Console.WriteLine(((HttpWebResponse)response2).StatusDescription);
                dataStream2 = response2.GetResponseStream();
                StreamReader rdr2 = new StreamReader(dataStream2);
                string feedback2 = rdr2.ReadToEnd();

                string[] array = feedback2.Split(',');
                if (array.Length == 9)
                {
                    string errorCode = array[0].ToString().Replace(",", "");
                    string Ref = GetDetail(array[1].ToString());
                    resp.StatusCode = errorCode.Replace("\n", "");
                    //resp.Serial = Ref;
                    resp.ReceiptNumber = Ref;
                }
                else
                {
                    string errorCode = array[0].ToString().Replace(",", "");
                    string errorMessage = array[1].ToString().Replace(",", "");
                    resp.StatusDescription = errorMessage;
                    resp.StatusCode = errorCode;
                }
            }
            else
            {
                resp.StatusCode = "29";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return resp;
    }
    private SchoolsPostResponse MakeMUBSSchoolFeesPayment(schoolsTransaction trans)
    {
        SchoolsPostResponse resp = new SchoolsPostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        UtilityCredentials creds;
        try
        {

            creds = dp.GetUtilityCreds(trans.UtilityCode, trans.VendorCode);
            if (!creds.UtilityCode.Equals(""))
            {
                //code to post transaction 
                System.Net.ServicePointManager.Expect100Continue = false;
                string myUrl2 = "http://eis.mubs.ac.ug:84/test/ebank?";
                string urlParams2 = "act = POST & cur = UGX & acc = " + trans.Teller + "& dt =" + trans.PaymentDate + "& stno =" + trans.CustRef + "& chqno =" + trans.ChequeNumber + " &dr =" + trans.Reversal + " &cr =" + trans.PaymentType + " & bank =" + creds.BankCode + " & username =" + creds.Utility + "& password =" + creds.UtilityPassword + "& phone =" + trans.Telephone + " & yrofstudy =" + "" + "& sem =" + "" + "& bankRef =" + trans.VendorTransactionRef + " & naration =" + trans.Narration;
                myUrl2 = myUrl2 + urlParams2;
                HttpWebRequest r2 = (HttpWebRequest)System.Net.WebRequest.Create(myUrl2);
                r2.Headers.Clear();
                r2.AllowAutoRedirect = true;
                r2.PreAuthenticate = true;
                r2.ContentType = "application / x - www - form - urlencoded";
                r2.Credentials = CredentialCache.DefaultCredentials;
                r2.UserAgent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
                r2.Timeout = 150000;
                Encoding byteArray2 = Encoding.GetEncoding("utf-8");
                Stream dataStream2;
                WebResponse response2 = (HttpWebResponse)r2.GetResponse();
                Console.WriteLine(((HttpWebResponse)response2).StatusDescription);
                dataStream2 = response2.GetResponseStream();
                StreamReader rdr2 = new StreamReader(dataStream2);
                string feedback2 = rdr2.ReadToEnd();

                string[] array = feedback2.Split(',');
                if (array.Length == 9)
                {
                    string errorCode = array[0].ToString().Replace(",", "");
                    string Ref = GetDetail(array[1].ToString());
                    resp.StatusCode = errorCode.Replace("\n", "");
                    //resp.Serial = Ref;
                    resp.ReceiptNumber = Ref;
                }
                else
                {
                    string errorCode = array[0].ToString().Replace(",", "");
                    string errorMessage = array[1].ToString().Replace(",", "");
                    resp.StatusDescription = errorMessage;
                    resp.StatusCode = errorCode;
                }

            }
            else
            {
                resp.StatusCode = "29";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return resp;
    }

    [WebMethod]
    public QueryResponse GetTransactionDetails(string vendorTranID, string vendorCode, string password)
    {
        QueryResponse resp = new QueryResponse();

        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            dp.SaveRequestlog(vendorCode, "", "GETTRANDETAILS", "", password);
            BusinessLogic bll = new BusinessLogic();
            string strLoginCount = "";
            int loginCount = 0;
            string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (vendorData.Rows.Count != 0)
            {
                string vendor = vendorData.Rows[0]["VendorCode"].ToString();
                string encVendorPassword = vendorData.Rows[0]["VendorPassword"].ToString();
                string vendorPassword = bll.DecryptString(encVendorPassword);
                strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                string VendoType = vendorData.Rows[0]["VendorType"].ToString();
                loginCount = int.Parse(strLoginCount);
                bool activeVendor = bool.Parse(vendorData.Rows[0]["Active"].ToString());
                if (password == vendorPassword)
                {
                    if (activeVendor)
                    {
                        if (loginCount > 0)
                        {
                            dp.UpdateVendorInvalidLoginCount(vendorCode, 0, ipAddress);
                        }
                        if (vendor.Trim().Equals(vendorCode.Trim()) && vendorPassword.Trim().Equals(password.Trim()))
                        {
                            if (!(VendoType.Equals("PREPAID")))
                            {
                                DataTable dt = dp.GetTransactionDetails(vendorTranID, vendorCode);
                                if (dt.Rows.Count != 0)
                                {
                                    if (dt.Rows[0]["CustomerType"].ToString().Trim().Equals("PREPAID"))
                                    {
                                        resp.PegPayQueryId = dt.Rows[0]["UtilityTranRef"].ToString();
                                    }
                                    else
                                    {
                                        resp.PegPayQueryId = dt.Rows[0]["TransNo"].ToString();
                                    }

                                    resp.StatusCode = "0";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                }
                                else
                                {
                                    resp.StatusCode = "33";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    resp.PegPayQueryId = "";
                                }
                            }
                            else
                            {

                                DataTable dt = dp.GetPrepaidTransactionDetails(vendorTranID, vendorCode);
                                if (dt.Rows.Count != 0)
                                {
                                    string status = dt.Rows[0]["Status"].ToString().ToUpper().Trim();
                                    //its pending
                                    if (status.Equals("PENDING"))
                                    {
                                        resp.StatusCode = "1000";
                                        resp.StatusDescription = status;
                                    }
                                    //its successfull
                                    else if (status.Equals("SUCCESS"))
                                    {
                                        resp.StatusCode = "0";
                                        resp.StatusDescription = status;
                                        resp.PegPayQueryId = dt.Rows[0]["UtilityTranRef"].ToString();
                                        resp.CustomerReference = dt.Rows[0]["VendorToken"].ToString();
                                    }
                                    else if (status.Equals("REVERSAL"))
                                    {
                                        resp.StatusCode = "0";
                                        resp.StatusDescription = "REVERSED";
                                        resp.PegPayQueryId = dt.Rows[0]["VendorToken"].ToString();
                                        resp.CustomerReference = dt.Rows[0]["BankReversalRef"].ToString();
                                    }
                                    //it has failed
                                    else if (status.Equals("FAILED"))
                                    {
                                        resp.StatusCode = "100";
                                        resp.StatusDescription = dt.Rows[0]["Reason"].ToString();
                                        resp.PegPayQueryId = "";
                                        resp.CustomerReference = "";
                                    }
                                    //unknown status
                                    else
                                    {
                                        resp.StatusCode = "1000";
                                        resp.StatusDescription = status;
                                    }
                                }
                                else
                                {
                                    resp.StatusCode = "33";
                                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                                    resp.PegPayQueryId = "";
                                }
                            }
                        }
                        else
                        {
                            resp.StatusCode = "2";
                            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                            resp.PegPayQueryId = "";
                        }
                    }
                    else
                    {
                        resp.StatusCode = "11";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        resp.PegPayQueryId = "";
                    }
                }
                else
                {
                    strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    loginCount = int.Parse(strLoginCount);
                    loginCount = loginCount + 1;
                    if (loginCount == 3)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                        dp.DeactivateVendor(vendorCode, ipAddress);
                    }
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    }

                    resp.StatusCode = "2";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    resp.PegPayQueryId = "";
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                resp.PegPayQueryId = "";
            }
        }
        catch (Exception ex)
        {
            try
            {
                DatabaseHandler dp = new DatabaseHandler();
                resp.StatusCode = "10";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                resp.PegPayQueryId = "";
                //LogGeneralError(ex.Message, vendorCode);
            }
            catch (Exception exx)
            {
                //LogGeneralError(exx.Message, vendorCode);
            }
        }
        return resp;
    }

    [WebMethod]
    public QueryResponse GetTransactionStatus(string vendorTranID, string vendorCode, string password)
    {
        QueryResponse resp = new QueryResponse();

        try
        {
            resp = ValidateParameters(vendorTranID, vendorCode, password);
            //validation is ok
            if (resp.StatusCode.Equals("0"))
            {
                resp = GetTheStatusOfTheTransaction(vendorTranID, vendorCode);
            }
            //error in validationg
            else
            {
                return resp;
            }
        }
        //let vendor another get status request because something has gone wrong
        catch (Exception ex)
        {
            resp.StatusCode = "1000";
            resp.StatusDescription = "PENDING";
            resp.PegPayQueryId = "";
        }
        return resp;
    }

    private QueryResponse GetTheStatusOfTheTransaction(string vendorTranID, string vendorCode)
    {
        QueryResponse resp = new QueryResponse();
        DatabaseHandler dh = new DatabaseHandler();
        DataTable results = dh.GetTranStatus(vendorTranID, vendorCode);
        if (results.Rows.Count > 0)
        {
            string status = results.Rows[0]["Status"].ToString();
            if (status.Equals("SUCCESS"))
            {
                resp.StatusCode = "0";
                resp.StatusDescription = status;
            }
            //it failed
            else
            {
                resp.StatusCode = "42";
                resp.StatusDescription = status;
            }
        }
        //transaction not found
        else
        {
            resp.StatusCode = "33";
            resp.StatusDescription = dh.GetStatusDescr(resp.StatusCode);
        }
        return resp;
    }

    private QueryResponse ValidateParameters(string vendorTranID, string vendorCode, string password)
    {
        QueryResponse resp = new QueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        dp.SaveRequestlog(vendorCode, "", "GETTRANDETAILS", "", password);
        BusinessLogic bll = new BusinessLogic();
        string strLoginCount = "";
        int loginCount = 0;
        string ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        DataTable vendorData = dp.GetVendorDetails(vendorCode);
        if (vendorData.Rows.Count != 0)
        {
            string vendor = vendorData.Rows[0]["VendorCode"].ToString();
            string encVendorPassword = vendorData.Rows[0]["VendorPassword"].ToString();
            string vendorPassword = bll.DecryptString(encVendorPassword);
            strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
            loginCount = int.Parse(strLoginCount);
            bool activeVendor = bool.Parse(vendorData.Rows[0]["Active"].ToString());
            if (password == vendorPassword)
            {
                if (activeVendor)
                {
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0, ipAddress);
                    }
                    if (vendor.Trim().Equals(vendorCode.Trim()) && vendorPassword.Trim().Equals(password.Trim()))
                    {
                        resp.StatusCode = "0";
                        resp.StatusDescription = "SUCCESS";
                        resp.PegPayQueryId = "";
                    }
                    else
                    {
                        resp.StatusCode = "2";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                        resp.PegPayQueryId = "";
                    }
                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    resp.PegPayQueryId = "";
                }
            }
            else
            {
                strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                loginCount = int.Parse(strLoginCount);
                loginCount = loginCount + 1;
                if (loginCount == 3)
                {
                    dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                    dp.DeactivateVendor(vendorCode, ipAddress);
                }
                {
                    dp.UpdateVendorInvalidLoginCount(vendorCode, loginCount, ipAddress);
                }

                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                resp.PegPayQueryId = "";
            }
        }
        else
        {
            resp.StatusCode = "2";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            resp.PegPayQueryId = "";
        }
        return resp;

    }

    private UtilityReferences.URA.TransactionEntity GetUraTrans(URATransaction trans, UtilityCredentials creds)
    {
        BusinessLogic bll = new BusinessLogic();
        TransactionEntity uraTrans = new TransactionEntity();
        uraTrans.Amount = bll.EncryptUraParameter(trans.TransactionAmount);
        uraTrans.Prn = bll.EncryptUraParameter(trans.CustRef);
        uraTrans.Tin = bll.EncryptUraParameter(trans.TIN);
        uraTrans.Bank_branch_cd = creds.BankCode;
        uraTrans.Bank_cd = creds.UtilityCode;
        uraTrans.Bank_tr_no = trans.VendorTransactionRef;
        uraTrans.Chq_no = trans.ChequeNumber;
        uraTrans.Paid_dt = DateTime.Now.ToString("dd/MM/yyyy"); //DateTime.Parse(trans.PaymentDate).ToString("dd/MM/yyyy");
        uraTrans.Reason = trans.Narration;
        uraTrans.Status = trans.Status;
        uraTrans.Value_dt = DateTime.Now.ToString("dd/MM/yyyy");
        string dataToSign = uraTrans.Bank_cd + uraTrans.Prn + uraTrans.Tin + uraTrans.Amount + uraTrans.Paid_dt
                           + uraTrans.Value_dt + uraTrans.Status + uraTrans.Bank_branch_cd + uraTrans.Bank_tr_no + uraTrans.Chq_no
                           + uraTrans.Reason;
        uraTrans.Signature = GetSignature(dataToSign, trans.VendorCode);
        //-- the other properties don't require encryption but should be filled and the order below maintained

        //string digitalSignature = GetDigitalSignature(dataToSign, trans.VendorCode);
        //uraTrans.Signature = Convert.FromBase64String(digitalSignature);
        return uraTrans;
    }

    private byte[] GetSignatureURA(string Tosign, string VendorCode)
    {
        string certificate = @"E:\\Certificates\\" + VendorCode + "\\" + VendorCode + ".pfx";
        X509Certificate2 cert = new X509Certificate2(certificate, "", X509KeyStorageFlags.UserKeySet);

        RSACryptoServiceProvider RSAcp = (RSACryptoServiceProvider)cert.PrivateKey;

        if (RSAcp == null)
        {
            throw new Exception("VALID CERTIFICATE NOT FOUND");
        }

        byte[] data = new UnicodeEncoding().GetBytes(Tosign);
        byte[] hash = new SHA1Managed().ComputeHash(data);

        // Sign the hash
        return RSAcp.SignHash(hash, CryptoConfig.MapNameToOID("SHA1"));
    }

    private string[] makePaymentUra(URATransaction transaction, UtilityCredentials creds)
    {
        try
        {
            BusinessLogic bll = new BusinessLogic();
            TransactionEntity av = new TransactionEntity();
            string username = creds.UtilityCode;
            string Passwd = bll.DecryptString(creds.UtilityPassword);
            string CryptPass = bll.EncryptUraParameter(Passwd);
            //-- one single payment transaction entity
            string Amount = Convert.ToString(int.Parse(transaction.TransactionAmount));
            av.Amount = bll.EncryptUraParameter(Amount);
            av.Prn = bll.EncryptUraParameter(transaction.CustRef);
            av.Tin = bll.EncryptUraParameter(transaction.TIN);
            av.Reason = transaction.TransactionType;
            av.Bank_branch_cd = creds.BankCode;
            av.Bank_cd = creds.UtilityCode;
            av.Bank_tr_no = transaction.VendorTransactionRef;
            av.Chq_no = transaction.ChequeNumber;
            av.Paid_dt = DateTime.Now.ToString("dd/MM/yyyy");
            av.Status = transaction.Status;  // c

            av.Value_dt = DateTime.Now.ToString("dd/MM/yyyy");
            string dataToSign = av.Bank_cd + av.Prn + av.Tin + av.Amount + av.Paid_dt + av.Value_dt + av.Status +
                           av.Bank_branch_cd + av.Bank_tr_no + av.Chq_no + av.Reason;
            av.Signature = GetSignatureURA(dataToSign, transaction.VendorCode);

            TransactionEntity[] arr = { av };
            UraPmtService clt = new UraPmtService();
            string[] RetStr;
            try
            {
                RetStr = clt.NotifyUraPayment(username, CryptPass, arr);
            }
            catch (Exception exe)
            {
                string res = "000,OFFLINE";
                string[] arr_str = res.Split(',');
                RetStr = arr_str;
            }
            return RetStr;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private UtilityReferences.UMEME.Transaction GetUmemeTrans(UmemeTransaction trans, UtilityCredentials creds)
    {
        UtilityReferences.UMEME.Transaction umemeTrans = new UtilityReferences.UMEME.Transaction();
        umemeTrans.CustomerName = trans.CustName;
        umemeTrans.CustomerRef = trans.CustRef;
        umemeTrans.CustomerTel = trans.CustomerTel;
        umemeTrans.CustomerType = trans.CustomerType;
        umemeTrans.Offline = trans.Offline;
        umemeTrans.Password = creds.UtilityPassword;
        umemeTrans.PaymentDate = trans.PaymentDate;
        umemeTrans.PaymentType = trans.PaymentType;
        umemeTrans.Reversal = trans.Reversal;
        umemeTrans.StatusCode = "0";
        umemeTrans.StatusDescription = "SUCCESS";
        umemeTrans.Teller = trans.Teller;
        umemeTrans.TranAmount = trans.TransactionAmount;
        umemeTrans.TranIdToReverse = trans.TranIdToReverse;
        umemeTrans.TranNarration = trans.Narration;
        umemeTrans.TranType = trans.TransactionType;
        umemeTrans.VendorCode = creds.UtilityCode;
        umemeTrans.VendorTranId = trans.VendorTransactionRef;
        string dataToSign = umemeTrans.CustomerRef + umemeTrans.CustomerName + umemeTrans.CustomerTel + umemeTrans.CustomerType + umemeTrans.VendorTranId + umemeTrans.VendorCode + umemeTrans.Password + umemeTrans.PaymentDate + umemeTrans.PaymentType + umemeTrans.Teller + umemeTrans.TranAmount + umemeTrans.TranNarration + umemeTrans.TranType;
        umemeTrans.DigitalSignature = GetDigitalSignature(dataToSign, trans.VendorCode);
        return umemeTrans;
    }

    //private Transaction GetKCCATrans(KCCATransaction trans, UtilityCredentials creds)
    //{
    //    UtilityReferences.KCCA.Transaction kccaTrans = new UtilityReferences.KCCA.Transaction();
    //    kccaTrans.CustomerName = trans.CustName;
    //    kccaTrans.CustomerRef = trans.CustRef;
    //    kccaTrans.CustomerTel = trans.CustomerTel;
    //    kccaTrans.CustomerType = trans.CustomerType;
    //    kccaTrans.Offline = trans.Offline;
    //    kccaTrans.Password = creds.UtilityPassword;
    //    kccaTrans.PaymentDate = trans.PaymentDate;
    //    kccaTrans.PaymentType = trans.PaymentType;
    //    kccaTrans.Reversal = trans.Reversal;
    //    kccaTrans.StatusCode = "0";
    //    kccaTrans.StatusDescription = "SUCCESS";
    //    kccaTrans.Teller = trans.Teller;
    //    kccaTrans.TranAmount = trans.TransactionAmount;
    //    kccaTrans.TranIdToReverse = trans.TranIdToReverse;
    //    kccaTrans.TranNarration = trans.Narration;
    //    kccaTrans.TranType = trans.TransactionType;
    //    kccaTrans.VendorCode = creds.UtilityCode;
    //    kccaTrans.VendorTranId = trans.VendorTransactionRef;
    //    string dataToSign = kccaTrans.CustomerRef + kccaTrans.CustomerName + kccaTrans.CustomerTel + kccaTrans.CustomerType + kccaTrans.VendorTranId + kccaTrans.VendorCode + kccaTrans.Password + kccaTrans.PaymentDate + kccaTrans.PaymentType + kccaTrans.Teller + kccaTrans.TranAmount + kccaTrans.TranNarration + kccaTrans.TranType;
    //    kccaTrans.DigitalSignature = GetDigitalSignature(dataToSign, trans.VendorCode);
    //    return kccaTrans;
    //}

    private string GetDigitalSignature(string text, string vendorCode)
    {
        // retrieve private key||@"C:\PegPayCertificates1\Orange\41.202.229.3.cer"
        string certificate = "";
        if (vendorCode.ToUpper().Equals("EZEEMONEY"))
        {
            certificate = @"E:\\Certificates\\" + vendorCode + "Certs\\" + vendorCode + ".pfx";
        }
        else if (vendorCode.ToUpper().Equals("PEGPAY_COREBANKING"))
        {
            certificate = @"E:\Certificates\CELL\CELL.pfx";
        }
        else
        {
            certificate = @"E:\\Certificates\\" + vendorCode + "\\" + vendorCode + ".pfx";
        }

        //string certificate = @"C:\PegPayCertificates1\Ezee-Money\ezeemoney-ug_com.crt";
        X509Certificate2 cert = new X509Certificate2(certificate, "Tingate710", X509KeyStorageFlags.UserKeySet);
        RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cert.PrivateKey;

        // Hash the data
        SHA1Managed sha1 = new SHA1Managed();
        ASCIIEncoding encoding = new ASCIIEncoding();
        byte[] data = encoding.GetBytes(text);
        byte[] hash = sha1.ComputeHash(data);

        // Sign the hash
        byte[] digitalCert = rsa.SignHash(hash, CryptoConfig.MapNameToOID("SHA1"));
        string strDigCert = Convert.ToBase64String(digitalCert);
        return strDigCert;
    }

    private string GetDigitalSignature1(string text, string vendorCode)
    {
        try
        {
            // Open certificate store of current user
            //X509Store my = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            X509Store my = new X509Store(vendorCode, StoreLocation.LocalMachine);
            my.Open(OpenFlags.ReadOnly);

            // Look for the certificate with specific subject 
            RSACryptoServiceProvider csp = null;
            foreach (X509Certificate2 cert in my.Certificates)
            {
                //if (cert.Subject.Contains("CN=WINGROUP\\micwein"))
                if (cert.Subject.Contains(vendorCode))
                {
                    // retrieve private key
                    csp = (RSACryptoServiceProvider)cert.PrivateKey;
                }
            }
            if (csp == null)
            {
                throw new Exception("Valid certificate was not found");
            }

            // Hash the data
            SHA1Managed sha1 = new SHA1Managed();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] data = encoding.GetBytes(text);
            byte[] hash = sha1.ComputeHash(data);

            // Sign the hash

            return Convert.ToBase64String(csp.SignHash(hash, CryptoConfig.MapNameToOID("SHA1")));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private byte[] GetSignature(string Tosign, string vendorCode)
    {
        string certificate = @"E:\\Certificates\\" + vendorCode + "\\" + vendorCode + ".pfx"; ;
        X509Certificate2 cert = new X509Certificate2(certificate, "Tingate710", X509KeyStorageFlags.UserKeySet);

        RSACryptoServiceProvider RSAcp = (RSACryptoServiceProvider)cert.PrivateKey;

        if (RSAcp == null)
        {
            throw new Exception("VALID CERTIFICATE NOT FOUND");
        }

        byte[] data = new UnicodeEncoding().GetBytes(Tosign);
        byte[] hash = new SHA1Managed().ComputeHash(data);

        // Sign the hash
        return RSAcp.SignHash(hash, CryptoConfig.MapNameToOID("SHA1"));
    }

    private bool IsValidPayCode(UmemeTransaction trans)
    {
        if (trans.PaymentType != null)
        {
            DatabaseHandler dp = new DatabaseHandler();
            DataTable dt = dp.GetPaymentCode(trans.PaymentType);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    private bool IsValidCustType(UmemeTransaction trans)
    {
        if (trans.CustomerType != null)
        {
            string CustType = trans.CustomerType.ToString().ToUpper();
            CustType = CustType.Replace(" ", "");
            if (CustType.Equals("PREPAID") || CustType.Equals("POSTPAID"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    private Token GetToken(UtilityReferences.UMEME.Token token, string pegpayPostId)
    {
        Token t = new Token();
        t.DebtRecovery = token.DebtRecovery;
        t.Fuel = token.Fuel;
        t.Fx = token.Fx;
        t.Inflation = token.Inflation;
        t.MeterNumber = token.MeterNumber;
        t.PayAccount = token.PayAccount;
        t.PrepaidToken = token.PrepaidToken;
        t.ReceiptNumber = token.ReceiptNumber;
        t.Tax = token.Tax;
        t.TokenValue = token.TokenValue;
        t.TotalAmount = token.TotalAmount;
        t.Units = token.Units;
        t.PegPayPostId = pegpayPostId;
        return t;
    }

    private bool IsChequeBlacklisted(Transaction trans)
    {

        if (trans.TransactionType.ToUpper().Contains("CHEQUE"))
        {
            DatabaseHandler dp = new DatabaseHandler();
            DataTable dt = dp.CheckBlacklist(trans.CustRef);
            if (dt.Rows.Count > 0)
            {
                string status = dt.Rows[0]["ChequeBlackListed"].ToString();
                if (status.Equals("1"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    private bool ReverseAmountsMatch(Transaction trans)
    {
        DatabaseHandler dp = new DatabaseHandler();
        if (trans.Reversal.Equals("0"))
        {
            return true;
        }
        else
        {
            DataTable dt = dp.GetOriginalVendorRef(trans);
            if (dt.Rows.Count > 0)
            {
                double amount = double.Parse(trans.TransactionAmount);
                double amountToreverse = double.Parse(dt.Rows[0]["TranAmount"].ToString());
                double total = amountToreverse + amount;
                if (total.Equals(0))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }

    private bool HasOriginalEntry(Transaction trans)
    {
        DatabaseHandler dp = new DatabaseHandler();
        if (trans.Reversal.Equals("0"))
        {
            return true;
        }
        else
        {
            DataTable dt = dp.GetOriginalVendorRef(trans);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    private string GetReversalState(Transaction trans)
    {
        string res = "";
        if (trans.Reversal != null)
        {
            double amt = double.Parse(trans.TransactionAmount);
            string amountstr = amt.ToString();
            int amount = int.Parse(amountstr);
            if (amount > 0)
            {
                res = "0";
            }
            else
            {
                res = "1";
            }
        }
        return res;
    }

    private bool IsduplicateCustPayment(Transaction trans)
    {
        if (trans.VendorCode.Trim().ToUpper() == "MTN")
        {
            return false;
        }
        bool ret = false;
        DatabaseHandler dp = new DatabaseHandler();
        string custRef = trans.CustRef;
        double amount = double.Parse(trans.TransactionAmount);
        DateTime postDate = DateTime.Now;
        DataTable dt = dp.GetDuplicateCustPayment(trans.VendorCode, custRef, amount, postDate);
        if (dt.Rows.Count > 0)
        {
            DateTime Postdate = DateTime.Parse(dt.Rows[0]["RecordDate"].ToString());
            TimeSpan t = postDate.Subtract(Postdate);
            int tmdiff = t.Minutes;
            if (tmdiff < 10)
            {
                ret = true;
            }
            else
            {
                ret = false;
            }
        }
        else
        {
            ret = false;
        }
        return ret;
    }

    private bool IsduplicateVendorRef(Transaction trans)
    {
        bool ret = false;
        DatabaseHandler dp = new DatabaseHandler();
        DataTable dt = dp.GetDuplicateVendorRef(trans);
        if (dt.Rows.Count > 0)
        {
            ret = true;
        }
        else
        {
            ret = false;
        }
        return ret;
    }

    private bool IsduplicatePrepaidVendorRef(Transaction trans)
    {
        bool ret = false;
        DatabaseHandler dp = new DatabaseHandler();
        DataTable dt = dp.GetDuplicatePrepaidVendorRef(trans);
        if (dt.Rows.Count > 0)
        {
            ret = true;
        }
        else
        {
            ret = false;
        }
        return ret;
    }


    private bool isSignatureValid(Transaction trans)
    {
        bool valid = false;
        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            BusinessLogic bll = new BusinessLogic();
            if (trans.VendorCode.Equals("MTN"))
            {
                valid = true;
                return valid;
            }
            else if (trans.VendorCode.Equals("TEST") || trans.VendorCode.ToUpper().Equals("PEGPAY"))
            {
                valid = true;
                return valid;
            }

            else if (trans.VendorCode.Equals("SMART") || trans.VendorCode.Equals("SMS2BET"))
            {
                valid = true;
                return valid;
            }
            else if (trans.VendorCode.ToUpper().Equals("ISYS"))
            {
                string text = trans.CustRef + trans.CustName + trans.CustomerTel + trans.VendorTransactionRef + trans.VendorCode + trans.Password + trans.PaymentDate + trans.Teller + trans.TransactionAmount + trans.Narration + trans.TransactionType;

                string certPath = "C:\\PegPayCertificates1\\";
                string vendorCode = trans.VendorCode;
                certPath = certPath + "\\" + vendorCode + "\\";
                string[] fileEntries = Directory.GetFiles(certPath);
                string filePath = "";
                if (fileEntries.Length == 1)
                {
                    filePath = fileEntries[0].ToString();
                    X509Certificate2 cert = new X509Certificate2(filePath);
                    RSACryptoServiceProvider csp = (RSACryptoServiceProvider)cert.PublicKey.Key;
                    SHA1Managed sha1 = new SHA1Managed();
                    //UnicodeEncoding encoding = new UnicodeEncoding();
                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] data = encoding.GetBytes(text);
                    byte[] hash = sha1.ComputeHash(data);
                    byte[] sig = Convert.FromBase64String(trans.DigitalSignature);
                    valid = csp.VerifyHash(hash, CryptoConfig.MapNameToOID("SHA1"), sig);
                    return valid;
                    //return true;
                }
                else
                {
                    dp.LogError(" more than 1 certificate in folder", trans.VendorCode, DateTime.Now, "NONE");
                    //LogGeneralError(" more than 1 certificate in folder", trans.VendorCode);
                    return false;
                }
            }
            else if (trans.VendorCode.ToUpper().Equals("CELL"))
            {
                valid = true;
                return valid;
            }
            else if (trans.VendorCode.ToUpper().Equals("SMARTMONEY"))
            {
                valid = true;
                return valid;
            }
            else
            {

                string text = trans.CustRef + trans.CustName + trans.CustomerTel + trans.VendorTransactionRef + trans.VendorCode + trans.Password + trans.PaymentDate + trans.Teller + trans.TransactionAmount + trans.Narration + trans.TransactionType;

                DataTable dt2 = dp.GetSystemSettings("1", "6");
                string certPath = dt2.Rows[0]["ValueVarriable"].ToString();
                string vendorCode = trans.VendorCode;
                certPath = certPath + "\\" + vendorCode + "\\";
                string[] fileEntries = Directory.GetFiles(certPath);
                string filePath = "";
                if (fileEntries.Length == 1)
                {
                    filePath = fileEntries[0].ToString();
                    X509Certificate2 cert = new X509Certificate2(filePath);
                    RSACryptoServiceProvider csp = (RSACryptoServiceProvider)cert.PublicKey.Key;
                    SHA1Managed sha1 = new SHA1Managed();
                    //UnicodeEncoding encoding = new UnicodeEncoding();
                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] data = encoding.GetBytes(text);
                    byte[] hash = sha1.ComputeHash(data);
                    byte[] sig = Convert.FromBase64String(trans.DigitalSignature);
                    valid = csp.VerifyHash(hash, CryptoConfig.MapNameToOID("SHA1"), sig);
                    return valid;
                    //return true;
                }
                else
                {
                    dp.LogError(" more than 1 certificate in folder", trans.VendorCode, DateTime.Now, "NONE");
                    //LogGeneralError(" more than 1 certificate in folder", trans.VendorCode);
                    return false;
                }
            }
        }
        catch (Exception ex)
        {
            return false;
        }
        return false;
    }
    private bool isValidVendorCredentials2(string vendorCode, string password, DataTable vendorData)
    {
        bool valid = true;
        //try
        //{
        //    BusinessLogic bll = new BusinessLogic();
        //    if (vendorData.Rows.Count != 0)
        //    {
        //        string vendor = vendorData.Rows[0]["VendorCode"].ToString();
        //        string encVendorPassword = vendorData.Rows[0]["VendorPassword"].ToString();
        //        string vendorPassword = bll.DecryptString(encVendorPassword);
        //        if (vendor.Trim().Equals(vendorCode.Trim()) && vendorPassword.Trim().Equals(password.Trim()))
        //        {
        //            valid = true;
        //        }
        //        else
        //        {
        //            valid = false;
        //        }
        //    }
        //    else
        //    {
        //        valid = false;
        //    }
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        return valid;
    }

    private bool isValidVendorCredentials(string vendorCode, string password, DataTable vendorData)
    {
        bool valid = false;
        try
        {
            BusinessLogic bll = new BusinessLogic();
            if (vendorData.Rows.Count != 0)
            {
                string vendor = vendorData.Rows[0]["VendorCode"].ToString();
                string encVendorPassword = vendorData.Rows[0]["VendorPassword"].ToString();
                string vendorPassword = bll.DecryptString(encVendorPassword);
                if (vendor.Trim().Equals(vendorCode.Trim()) && vendorPassword.Trim().Equals(password.Trim()))
                {
                    valid = true;
                }
                else
                {
                    valid = false;
                }
            }
            else
            {
                valid = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return valid;
    }

    //private void LogGeneralError(string error, string vendor_code)
    //{
    //    DateTime now = DateTime.Now;
    //    try
    //    {
    //        DatabaseHandler dp = new DatabaseHandler();
    //        string res = dp.LogError(error, vendor_code, now);
    //        if (!res.Equals("YES"))
    //        {
    //            /// Now Write to Log File
    //            string str = vendor_code + "'s Error " + error + " at " + now.ToString("dd-MM-yyyy:HH:MM:ss");
    //            file_log(str);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        string str = vendor_code + "'s Error " + error + " at " + now.ToString("dd-MM-yyyy:HH:MM:ss");
    //        file_log(str);
    //    }
    //}
    internal void file_log(string log_string)
    {
        string header = "---------------------------- NEW ERROR LINE ----------------------------";
        StreamWriter log;
        string filepath = "F:\\sigtext\\";
        string filename = filepath + "logfile.txt";
        CheckPath(filename);
        if (!File.Exists(filename))
        {
            log = new StreamWriter(filename);
        }
        else
        {
            log = File.AppendText(filename);
        }

        // Write to the file:
        log.WriteLine(header);
        log.WriteLine(DateTime.Now);
        log.WriteLine(log_string);
        log.WriteLine();

        // Close the stream:
        log.Close();
    }
    private void CheckPath(string Path)
    {
        if (!File.Exists(Path))
        {
            File.Create(Path);
        }
    }

    private bool IsValidReversalStatus(Transaction trans)
    {
        if (trans.Reversal == null)
        {
            return false;
        }
        else
        {
            if (trans.Reversal.Equals("0") || trans.Reversal.Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    private bool isActiveVendor(string vendorCode, DataTable vendorData)
    {
        bool active = false;
        try
        {
            bool activeVendor = bool.Parse(vendorData.Rows[0]["Active"].ToString());
            if (activeVendor)
            {
                active = true;
            }
            else
            {
                active = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return active;
    }


    private void saveCustomerDetails(Customer cust)
    {
        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            dp.SaveCustomerDetailsKCCA(cust);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    private void saveUmemeCustomerDetails(Customer cust)
    {
        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            dp.SaveKCCACustomerDetails(cust);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    private void saveKCCACustomerDetails(Customer cust)
    {
        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            dp.SaveKCCACustomerDetails(cust);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    private static bool RemoteCertificateValidation(Object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        return true;
    }

    private static string GetDetail(string input)
    {
        string[] array = input.Split(':');
        string output = array[1].ToString().Trim();
        return output;
    }


    [WebMethod]
    public QueryResponse ReactivateSmartCard(string smartCardNumber, string vendorCode, string password)
    {
        QueryResponse resp = new QueryResponse();
        try
        {
            DatabaseHandler dh = new DatabaseHandler();
            int rows = dh.SaveReactivateRequest(smartCardNumber);
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
        }
        return resp;
    }

    [WebMethod]
    public PostResponse UploadEODReconciliationReport(List<EODTransaction> lstOftrans, string vendorCode, string password)
    {
        PostResponse resp = new PostResponse();
        try
        {
            SendToEodMsq(lstOftrans, vendorCode);
            resp.StatusCode = "0";
            resp.StatusDescription = "SUCCESS";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = "GENERAL ERROR AT PEGASUS";
        }
        return resp;
    }

    private void SendToEodMsq(EODTransaction trans)
    {
        MessageQueue queue;
        if (MessageQueue.Exists(EodReconciliationQueue))
        {
            queue = new MessageQueue(EodReconciliationQueue);
        }
        else
        {
            queue = MessageQueue.Create(EodReconciliationQueue);
        }
        Message msg = new Message();
        msg.Body = trans;
        msg.Label = trans.VendorTranId;
        msg.Recoverable = true;
        queue.Send(msg);
    }

    private void SendToEodMsq(List<EODTransaction> lstOftrans, string VendorCode)
    {
        MessageQueue queue;
        if (MessageQueue.Exists(EodReconciliationQueue))
        {
            queue = new MessageQueue(EodReconciliationQueue);
        }
        else
        {
            queue = MessageQueue.Create(EodReconciliationQueue);
        }
        Message msg = new Message();
        msg.Body = lstOftrans;
        msg.Label = VendorCode;
        msg.Recoverable = true;
        queue.Send(msg);
    }
    [WebMethod]
    public PostResponse SendSms(NWSCTransaction trans)//(string receipient, string receipientName, string message,string transactionId, string, string digitalSignature, string vendorCode, string password)
    {

        PostResponse resp = new PostResponse();
        try
        {
            DatabaseHandler dp = new DatabaseHandler();
            if (string.IsNullOrEmpty(trans.VendorCode))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A VENDOR CODE";
                return resp;
            }
            else if (string.IsNullOrEmpty(trans.utilityCompany))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A VENDOR CODE";
                return resp;
            }
            else if (trans.utilityCompany.ToUpper() != "SMS")
            {

                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "METHOD IS ONLY DESIGNED FOR SMS PROCESSING";
                return resp;

            }
            else if (string.IsNullOrEmpty(trans.CustomerTel))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE PROVIDE RECEIVER PHONE NUMBER";
                return resp;

            }
            else
            {
                PhoneValidator pv = new PhoneValidator();
                DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
                string phone = pv.FormatTelephone(trans.CustomerTel);
                
                if (!pv.PhoneNumbersOk(trans.CustomerTel))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID PHONE NUMBER";
                    return resp;
                }
                else if (string.IsNullOrEmpty(trans.VendorTransactionRef))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "PLEASE SUPPLY A VENDOR TRANSACTION REFERENCE";
                    return resp;
                }
                else if (string.IsNullOrEmpty(trans.Teller))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "PLEASE SUPPLY A TELLER";
                }
                else if (string.IsNullOrEmpty(trans.Narration))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "Please supply the message to be delivered".ToUpper();
                }
                else if (string.IsNullOrEmpty(trans.PaymentDate))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "PLEASE SUPPLY SMS SENDING DATE FORMAT";
                }
                else if (!bll.IsValidDate(trans.PaymentDate))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID DATE FORMAT: USE dd/MM/yyyy";
                }
                else if (!isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID VENDOR CREDENTIALS";
                }
                else if (!isSignatureValid(trans))
                {
                    resp.PegPayPostId = "";
                    resp.StatusCode = "100";
                    resp.StatusDescription = "INVALID DIGITAL SIGNATURE AT PEGPAY";
                }
                else
                {
                    trans.CustRef = trans.CustomerTel;
                    trans.CustomerType = "";
                    trans.TransactionType = "";
                    trans.CustomerType = "";
                    trans.CustName = "";
                    trans.Tin = "";
                    trans.PaymentType = "CASH";
                    trans.Reversal = "0";
                    trans.TransactionType = "2";
                    trans.CustomerType = "";
                    trans.Area = "";
                    trans.TransactionAmount = dp.GetSmsCharge(trans.VendorCode);
                    trans.TransactionAmount = GetAmount(trans.TransactionAmount);
                    // log details
                    resp.PegPayPostId = dp.PostUmemeTransactionPrepaidVendor(trans, trans.utilityCompany, trans.Area);
                    resp.StatusCode = "1000";
                    resp.StatusDescription = "PENDING";

                }
            }
        }
        catch (Exception ee)
        {

            resp.PegPayPostId = "";
            resp.StatusCode = "100";
            resp.StatusDescription = "PLEASE SUPPLY A VENDOR CODE";
            return resp;

        }

        return resp;
    }
    [WebMethod]
    public PostResponse MakeUtilityPaymentPrepaidVendor(NWSCTransaction trans)
    {
        PostResponse resp = new PostResponse();
        DatabaseHandler dp = new DatabaseHandler();
        BusinessLogic bll = new BusinessLogic();
        PhoneValidator pv = new PhoneValidator();
        PostResponse valResp = new PostResponse();

        if (trans.CustomerTel == null)
        {
            trans.CustomerTel = "";
        }
        if (trans.Reversal == null)
        {
            trans.Reversal = "";
        }
        if (trans.Email == null)
        {
            trans.Email = "";
        }
        if (trans.Area == null)
        {
            trans.Area = "";

        }

        if (string.IsNullOrEmpty(trans.CustRef))
        {
            resp.PegPayPostId = "";
            resp.StatusCode = "100";
            resp.StatusDescription = "PLEASE SUPPLY A CUSTOMER REFERENCE";
            return resp;
        }
        else if (string.IsNullOrEmpty(trans.VendorTransactionRef))
        {
            resp.PegPayPostId = "";
            resp.StatusCode = "100";
            resp.StatusDescription = "PLEASE SUPPLY A VENDOR TRANSACTION REFERENCE";
            return resp;
        }
        else if (string.IsNullOrEmpty(trans.CustomerTel))
        {
            resp.PegPayPostId = "";
            resp.StatusCode = "100";
            resp.StatusDescription = "PLEASE SUPPLY A CUSTOMER TEL";
            return resp;
        }
        string vendorCode = trans.VendorCode;
        try
        {
            dp.SaveRequestlog(trans.VendorCode, trans.utilityCompany, "POSTING", trans.CustRef, trans.Password);
            DataTable vendaData = dp.GetVendorDetails(trans.VendorCode);
            if (trans.CustName == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A CUSTOMER NAME";
            }
            else if (trans.CustName.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A CUSTOMER NAME";
            }
            else if (trans.Area.Trim().Equals("") && trans.utilityCompany.Equals("NWSC"))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY AN AREA FOR NWSC TRANSACTIONS";

            }
            else if (trans.Area.Trim().Equals("") && trans.utilityCompany.Equals("DSTV"))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SPECIFY A BOUQUET CODE FOR DSTV TRANSACTION";

            }
            else if (trans.TransactionType == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A TRANSACTION TYPE";
            }
            else if (trans.TransactionType.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A TRANSACTION TYPE";
            }
            else if (trans.VendorTransactionRef == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A VENDOR TRANSACTION REFERENCE";
            }
            else if (trans.VendorTransactionRef.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A VENDOR TRANSACTION REFERENCE"; ;
            }
            else if (trans.Teller == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A TELLER";
            }
            else if (trans.Teller.Trim().Equals(""))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A TELLER";
            }
            else if (trans.DigitalSignature == null)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A DIGITAL SIGNATURE";
            }
            else if (trans.DigitalSignature.Length == 0)
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PLEASE SUPPLY A DIGITAL SIGNATURE";
            }
            else if (!bll.IsNumeric(trans.TransactionAmount))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID TRANSACTION AMOUNT";
            }
            else if (!isCustumerReferenceValid(trans.CustRef, trans.utilityCompany))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID CUSTOMER REFERENCE"; ;
            }
            else if (!bll.IsValidDate(trans.PaymentDate))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID DATE FORMAT: USE dd/MM/yyyy";
            }
            else if (!isValidVendorCredentials(trans.VendorCode, trans.Password, vendaData))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID VENDOR CREDENTIALS";
            }
            else if (!isActiveVendor(trans.VendorCode, vendaData))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "PEGPAY VENDOR CREDENTIALS HAVE BEEN DEACTIVATED";
            }
            else if (!isSignatureValid(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID DIGITAL SIGNATURE AT PEGPAY";
            }
            else if (!pv.PhoneNumbersOk(trans.CustomerTel))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "INVALID PHONE NUMBER";
            }
            else if (IsduplicatePrepaidVendorRef(trans))
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "DUPLICATE VENDOR REFERENCE";
            }
            else if (IsduplicateCustPayment(trans) && trans.Reversal != "1")
            {
                resp.PegPayPostId = "";
                resp.StatusCode = "100";
                resp.StatusDescription = "FAILED: SUSPECTED DOUBLE POSTING AT PEGASUS";
            }
            else if (trans.Reversal == "1" && !IsValidReversal(trans, out valResp))
            {
                resp.PegPayPostId = valResp.PegPayPostId;
                resp.StatusCode = valResp.StatusCode;
                resp.StatusDescription = valResp.StatusDescription;
            }
            else
            {
                string vendorType = vendaData.Rows[0]["VendorType"].ToString();
                if (!(vendorType.Equals("PREPAID")))
                {
                    resp.StatusCode = "999";
                    resp.StatusDescription = "METHOD ONLY FOR PREPAID AGENTS";
                }
                else
                {

                    if (trans.Reversal == "1")
                    {
                        // log details
                        ReversalRequest req = GetReversalRequest(trans);
                        resp.PegPayPostId = dp.LogReversalRequest(req);
                        resp.StatusCode = "0";
                        resp.StatusDescription = "SUCCESS";
                    }
                    else
                    {
                        if (trans.utilityCompany.ToUpper() == "SMS")
                        {
                            trans.CustRef = trans.CustomerTel;
                            if (!pv.PhoneNumbersOk(trans.CustomerTel))
                            {
                                resp.PegPayPostId = "";
                                resp.StatusCode = "100";
                                resp.StatusDescription = "FAILED: PLEASE SPECIFY RECEIPEINT PHONE NUMBER";
                                return resp;
                            }
                            else if (string.IsNullOrEmpty(trans.Narration))
                            {
                                resp.PegPayPostId = "";
                                resp.StatusCode = "100";
                                resp.StatusDescription = "FAILED: MESSAGE NOT SUPPLIED";
                                return resp;
                            }
                            trans.CustomerType = "";
                            trans.Area = "";
                            trans.TransactionAmount = dp.GetSmsCharge(vendorCode);
                        }
                        trans.TransactionAmount = GetAmount(trans.TransactionAmount);
                        // log details
                        resp.PegPayPostId = dp.PostUmemeTransactionPrepaidVendor(trans, trans.utilityCompany, trans.Area);
                        resp.StatusCode = "1000";
                        resp.StatusDescription = "PENDING";
                    }
                }
            }
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.deleteTransaction(resp.PegPayPostId, resp.StatusDescription);
            resp.PegPayPostId = "";
            dp.LogError(ex.Message, trans.VendorCode, DateTime.Now, "NWSC");
        }
        return resp;
    }

    internal string GetAmount(string amount)
    {
        if (amount.Contains("-"))
        {
            return amount.Replace("-", "");
        }
        else
        {
            return amount;
        }
    }

    private ReversalRequest GetReversalRequest(NWSCTransaction trans)
    {
        ReversalRequest request = new ReversalRequest();
        request.OriginalTransactionId = trans.TranIdToReverse;
        request.ReversalTransactionId = trans.VendorTransactionRef;
        request.Reason = trans.Narration;
        request.VendorCode = trans.VendorCode;
        return request;
    }

    private bool IsValidReversal(NWSCTransaction trans, out PostResponse result)
    {
        DatabaseHandler dp = new DatabaseHandler();
        result = new PostResponse();
        PostResponse valResp = new PostResponse();
        if (string.IsNullOrEmpty(trans.VendorTransactionRef))
        {
            result.StatusCode = "50";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        if (trans.TranIdToReverse == trans.VendorTransactionRef)
        {
            result.StatusCode = "51";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        if (string.IsNullOrEmpty(trans.Narration))
        {
            result.StatusCode = "52";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        if (!bll.IsValidReversalAmount(trans))
        {
            result.StatusCode = "53";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        if (!bll.OriginalTransactionExistsAndAcceptsReversal(trans.VendorCode, trans.TranIdToReverse, out valResp))
        {
            result.PegPayPostId = valResp.PegPayPostId;
            result.StatusCode = valResp.StatusCode;
            result.StatusDescription = valResp.StatusDescription;
            return false;
        }
        if (!bll.IsValidOriginalTransaction(trans))
        {
            result.StatusCode = "60";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        if (!bll.IsValidAmountToReverse(trans))
        {
            result.StatusCode = "56";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        if (bll.IsAlreadyReversed(trans, out valResp))
        {
            result.PegPayPostId = valResp.PegPayPostId;
            result.StatusCode = valResp.StatusCode;
            result.StatusDescription = valResp.StatusDescription;
            return false;
        }
        if (bll.IsDuplicateReversalId(trans))
        {
            result.StatusCode = "57";
            result.StatusDescription = dp.GetStatusDescr(result.StatusCode);
            return false;
        }
        else
        {
            return true;
        }

    }


    private bool isCustumerReferenceValid(string custReference, string utilityCompany)
    {
        bool isValid = false;
        try
        {
            if (utilityCompany.Equals("NWSC") || utilityCompany.Equals("UMEME") || utilityCompany.Equals("DSTV"))
            {
                DatabaseHandler dh = new DatabaseHandler();
                string status = dh.checkCustomerDetails(custReference);
                if (status == "true")
                {
                    isValid = true;
                }
                else
                {
                    isValid = false;
                }
            }
            else
            {
                isValid = true;
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return isValid;
    }

    [WebMethod]
    public NWSCQueryResponse QueryCustomerDetailsPrepaidVendor(string utility, string customerReference, string area, string vendorCode, string password)
    {
        NWSCQueryResponse resp = new NWSCQueryResponse();
        DatabaseHandler dp = new DatabaseHandler();
        try
        {
            dp.SaveRequestlog(vendorCode, utility, "VERIFICATION", customerReference, password);
            DataTable vendorData = dp.GetVendorDetails(vendorCode);
            if (isValidVendorCredentials(vendorCode, password, vendorData))
            {
                if (isActiveVendor(vendorCode, vendorData))
                {
                    string strLoginCount = vendorData.Rows[0]["InvalidLoginCount"].ToString();
                    int loginCount = int.Parse(strLoginCount);
                    if (loginCount > 0)
                    {
                        dp.UpdateVendorInvalidLoginCount(vendorCode, 0);
                    }

                    Customer cust = dp.GetCustomerDetails(customerReference, area, utility);
                    if (cust.StatusCode.Equals("0"))
                    {
                        resp.Area = cust.Area;
                        resp.CustomerName = cust.CustomerName;
                        resp.CustomerReference = cust.CustomerRef;
                        resp.OutstandingBalance = cust.Balance;
                        resp.CustType = cust.TIN;
                        resp.StatusCode = "0";
                        resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                    }
                    else
                    {
                        resp.StatusCode = "100";
                        resp.StatusDescription = "MATCH NOT FOUND";
                        resp.Area = "";
                        resp.CustomerName = "";
                        resp.CustomerReference = "";
                        resp.OutstandingBalance = "";
                        resp.CustType = "";
                    }

                    //   resp = queryCustomerAtPostBank(utility, customerReference, area, "PEGPAY", "543210iPegPay012345");


                }
                else
                {
                    resp.StatusCode = "11";
                    resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
                }
            }
            else
            {
                resp.StatusCode = "2";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
        }
        catch (System.Net.WebException wex)
        {
            Customer cust = dp.GetCustomerDetails(customerReference, area, utility);
            if (cust.StatusCode.Equals("0"))
            {
                resp.Area = cust.Area;
                resp.CustomerName = cust.CustomerName;
                resp.CustomerReference = cust.CustomerRef;
                resp.OutstandingBalance = "0";
                resp.StatusCode = "0";
                resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            }
            else
            {
                resp.StatusCode = "30";
                resp.StatusDescription = "UNABLE TO CONNECT TO " + utility;
            }
            dp.LogError(wex.Message, vendorCode, DateTime.Now, utility);
        }
        catch (SqlException sqlex)
        {
            resp.StatusCode = "31";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
        }
        catch (Exception ex)
        {
            resp.StatusCode = "32";
            resp.StatusDescription = dp.GetStatusDescr(resp.StatusCode);
            dp.LogError(ex.Message, vendorCode, DateTime.Now, utility);
        }
        return resp;
    }
    [WebMethod]
    public NWSCQueryResponse queryCustomerAtPostBank(string utility, string customerReference, string area, string vendorCode, string password)
    {
        NWSCQueryResponse customer = new NWSCQueryResponse();
        try
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = RemoteCertValidation;
            UtilityReferences.PBU.CardlessMoMoApi cardless = new UtilityReferences.PBU.CardlessMoMoApi();
            UtilityReferences.PBU.Customer Cust = new UtilityReferences.PBU.Customer();
            Cust = cardless.InquireUtilityCustomer(utility, customerReference, area, vendorCode, password);
            customer.Area = Cust.Area;
            customer.CustomerName = Cust.CustName;
            customer.CustType = Cust.CustomerType;
            customer.CustomerReference = Cust.CustRef;
            customer.OutstandingBalance = Cust.OutStandingBal;
            customer.StatusCode = Cust.StatusCode;
            customer.StatusDescription = Cust.StatusDescription;

        }
        catch (Exception ex)
        {
            customer.CustomerReference = customerReference;
            customer.StatusDescription = "UNABLE TO INQUIRE STARTIMES AT THE MOMENT.";

        }

        return customer;
    }


    private static bool RemoteCertValidation(Object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        return true;
    }

}
