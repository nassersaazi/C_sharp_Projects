using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for KCCAQueryResponse
/// </summary>
public class SchoolsQueryResponse:UmemeQueryResponse
{
    string level, amount, school, accountNumber;

    public string AccountNumber
    {
        get { return accountNumber; }
        set { accountNumber = value; }
    }

    public string School
    {
        get { return school; }
        set { school = value; }
    }

    public string Level
    {
        get { return level; }
        set { level = value; }
    }

    public string Amount
    {
        get { return amount; }
        set { amount = value; }
    }
    public SchoolsQueryResponse()
    {
        
        //
        // TODO: Add constructor logic here
        //
    }
}
