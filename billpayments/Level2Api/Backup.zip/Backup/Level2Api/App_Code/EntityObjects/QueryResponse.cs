using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Response
/// </summary>
public class QueryResponse:Response
{
    private string customerReference, pegpayQueryId, customerName, customerBalance;
    public string CustomerBalance
    {
        get { return customerBalance; }
        set { customerBalance = value; }
    }
    public string CustomerName
    {
        get { return customerName; }
        set { customerName = value; }
    }

    public string PegPayQueryId
    {
        get
        {
            return pegpayQueryId;
        }
        set
        {
            pegpayQueryId = value;
        }
    }
    public string CustomerReference
    {
        get
        {
            return customerReference;
        }
        set
        {
            customerReference = value;
        }
    }
}
