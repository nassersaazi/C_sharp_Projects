using System;
using System.Collections.Generic;
using System.Text;


    public class AirtimeObj
    {
        private string username, password, method, msisdn, transaction, msisdn2, network, amount, requestId;
        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }
        public string Method
        {
            get
            {
                return method;
            }
            set
            {
                method = value;
            }
        }
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }
        public string Msisdn
        {
            get
            {
                return msisdn;
            }
            set
            {
                msisdn = value;
            }
        }
        public string Msisdn2
        {
            get
            {
                return msisdn2;
            }
            set
            {
                msisdn2 = value;
            }
        }
        public string Transaction
        {
            get
            {
                return transaction;
            }
            set
            {
                transaction = value;
            }
        }
        public string Network
        {
            get
            {
                return network;
            }
            set
            {
                network = value;
            }
        }
        public string Amount
        {
            get
            {
                return amount;
            }
            set
            {
                amount = value;
            }
        }
    }

